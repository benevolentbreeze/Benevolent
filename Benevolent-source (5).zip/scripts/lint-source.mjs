/**
 * Project-specific static checks that the type checker doesn't cover.
 * Fails (exit 1) on patterns that are unsafe for a finance app.
 */
import { readdirSync, readFileSync, statSync } from "node:fs";
import { join, relative } from "node:path";

const root = new URL("..", import.meta.url).pathname;
const files = [];
(function walk(dir) {
  for (const name of readdirSync(dir)) {
    const path = join(dir, name);
    if (statSync(path).isDirectory()) walk(path);
    else if (/\.(ts|tsx)$/.test(name)) files.push(path);
  }
})(join(root, "src"));

const rules = [
  { pattern: /\bconsole\.(log|debug|info|warn|error|trace)\b/, message: "no console output (financial data must never be logged)" },
  { pattern: /@ts-(ignore|nocheck|expect-error)/, message: "no TypeScript suppressions" },
  { pattern: /eslint-disable/, message: "no lint suppressions" },
  { pattern: /:\s*any\b|<any>|\bas any\b/, message: "no `any`" },
  { pattern: /dangerouslySetInnerHTML|\.innerHTML\s*=|insertAdjacentHTML|document\.write/, message: "no raw HTML injection" },
  { pattern: /\beval\(|new Function\(/, message: "no dynamic code" },
  { pattern: /window\.localStorage|\blocalStorage\./, message: "storage access belongs in services/storageService.ts", allow: ["src/services/storageService.ts"] },
  { pattern: /parseFloat\(|toFixed\(\d\)\s*\*/, message: "money is whole đồng; avoid float parsing in money paths", allow: ["src/utils/money.ts"] },
];

let failures = 0;
for (const file of files) {
  const rel = relative(root, file);
  const lines = readFileSync(file, "utf8").split("\n");
  lines.forEach((line, index) => {
    for (const rule of rules) {
      if (rule.allow?.includes(rel)) continue;
      if (rule.pattern.test(line)) {
        failures += 1;
        console.error(`${rel}:${index + 1}  ${rule.message}\n    ${line.trim()}`);
      }
    }
  });
}
if (failures) {
  console.error(`\n${failures} problem(s).`);
  process.exit(1);
}
console.log(`lint-source: ${files.length} files clean.`);
