import { useId, useRef, useState, type ReactNode } from "react";
import Icon from "../components/Icon";
import { useReducedMotion } from "../hooks/useReducedMotion";
import { MAX_BACKUP_BYTES, parseBackup, serializeBackup } from "../services/storageService";
import { transactionsToCsv } from "../services/transactionService";
import { useFinance } from "../state/FinanceStore";
import { useUI } from "../state/UIStore";
import type { WorkspaceId } from "../types/state";
import { toDateKey } from "../utils/date";
import { downloadFile, readFileAsText } from "../utils/download";

function Switch({ checked, onChange, label, description }: { checked: boolean; onChange: (next: boolean) => void; label: string; description: ReactNode }) {
  const id = useId();
  return (
    <div className="setting-row">
      <div>
        <strong id={`${id}-label`}>{label}</strong>
        <small id={`${id}-description`}>{description}</small>
      </div>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        aria-labelledby={`${id}-label`}
        aria-describedby={`${id}-description`}
        className={`button switch ${checked ? "switch--on" : ""}`}
        onClick={() => onChange(!checked)}
      >
        <i />
      </button>
    </div>
  );
}

function ActionRow({ icon, label, description, onClick, tone }: { icon: Parameters<typeof Icon>[0]["name"]; label: string; description?: string; onClick: () => void; tone?: "danger" }) {
  return (
    <button type="button" className={`button setting-link ${tone === "danger" ? "setting-link--danger" : ""}`} onClick={onClick}>
      <Icon name={icon} size={18} />
      <span>
        <strong>{label}</strong>
        {description && <small>{description}</small>}
      </span>
      <Icon name="chevron" size={16} />
    </button>
  );
}

export default function Settings() {
  const { settings, actions, workspace, persisted, data } = useFinance();
  const ui = useUI();
  const reducedNow = useReducedMotion();
  const fileInput = useRef<HTMLInputElement>(null);
  const [confirmClear, setConfirmClear] = useState(false);
  const [name, setName] = useState(settings.displayName);
  const stamp = toDateKey(new Date());
  const systemReduces = reducedNow && settings.motion === "system";

  const switchTo = (next: WorkspaceId) => {
    if (next === workspace) return;
    actions.switchWorkspace(next);
    ui.toast(next === "demo" ? "Đang xem dữ liệu mẫu" : "Đang xem dữ liệu của bạn", "success");
  };

  const exportCsv = () => {
    if (!data.transactions.length) {
      ui.toast("Chưa có giao dịch nào để xuất", "warning");
      return;
    }
    try {
      downloadFile(`benevolent-giao-dich-${workspace === "demo" ? "mau-" : ""}${stamp}.csv`, transactionsToCsv(data.transactions, data.goals), "text/csv;charset=utf-8");
      ui.toast("Đã xuất tệp CSV", "success");
    } catch {
      ui.toast("Không tạo được tệp CSV trên trình duyệt này.", "warning");
    }
  };

  const backup = () => {
    try {
      downloadFile(`benevolent-sao-luu-${stamp}.json`, serializeBackup(persisted), "application/json");
      ui.toast("Đã tạo bản sao lưu", "success");
    } catch {
      ui.toast("Không tạo được bản sao lưu trên trình duyệt này.", "warning");
    }
  };

  const restore = async (file: File) => {
    if (file.size > MAX_BACKUP_BYTES) {
      ui.toast("Tệp quá lớn để là bản sao lưu của Benevolent.", "warning");
      return;
    }
    try {
      const result = parseBackup(await readFileAsText(file));
      if (!result.ok) {
        ui.toast(result.reason, "warning");
        return;
      }
      const previous = persisted;
      actions.replaceAll({ ...result.state, settings: { ...result.state.settings, introSeen: true } });
      setName(result.state.settings.displayName);
      ui.toast(result.dropped ? `Đã khôi phục (bỏ qua ${result.dropped} bản ghi lỗi)` : "Đã khôi phục bản sao lưu", "success", {
        label: "Hoàn tác",
        run: () => actions.replaceAll(previous),
      });
    } catch {
      ui.toast("Không đọc được tệp này", "warning");
    }
  };

  const clearPersonal = () => {
    if (!confirmClear) {
      setConfirmClear(true);
      return;
    }
    actions.resetWorkspace("personal");
    setConfirmClear(false);
    ui.toast("Đã xoá toàn bộ dữ liệu của bạn trên thiết bị này", "neutral");
  };

  const initials = name.trim() ? name.trim().split(/\s+/).map((part) => part[0]).slice(-2).join("").toUpperCase() : "";

  return (
    <main className="view inner-view settings-view" id="main">
      <div className="page-title">
        <span className="eyebrow">Cá nhân hoá</span>
        <h1>Cài đặt</h1>
        <p>Benevolent làm việc theo cách của bạn.</p>
      </div>

      <section className="profile-block" aria-label="Hồ sơ">
        <span aria-hidden="true">{initials || <Icon name="settings" size={20} />}</span>
        <label>
          <small>Tên hiển thị</small>
          <input
            value={name}
            maxLength={40}
            placeholder="Thêm tên của bạn"
            onChange={(event) => {
              setName(event.target.value);
              actions.updateSettings({ displayName: event.target.value.trim() });
            }}
            onKeyDown={(event) => event.key === "Enter" && (event.target as HTMLInputElement).blur()}
          />
        </label>
      </section>

      <section className="settings-group" aria-labelledby="workspace-title">
        <span className="eyebrow" id="workspace-title">
          Dữ liệu đang xem
        </span>
        <div className="workspace-choice" role="group" aria-label="Dữ liệu đang xem">
          {(
            [
              { id: "personal", title: "Dữ liệu của tôi", body: "Chỉ những gì bạn tự ghi lại." },
              { id: "demo", title: "Dữ liệu mẫu", body: "Một sinh viên giả định — để khám phá an toàn." },
            ] as const
          ).map((option) => (
            <button
              key={option.id}
              type="button"
              aria-pressed={workspace === option.id}
              className={`button workspace-option ${workspace === option.id ? "workspace-option--active" : ""}`}
              onClick={() => switchTo(option.id)}
            >
              <i aria-hidden="true" />
              <span>
                <strong>{option.title}</strong>
                <small>{option.body}</small>
              </span>
            </button>
          ))}
        </div>
        {workspace === "demo" && (
          <ActionRow
            icon="history"
            label="Làm mới dữ liệu mẫu"
            description="Tạo lại dữ liệu mẫu theo ngày hôm nay"
            onClick={() => {
              actions.resetWorkspace("demo");
              ui.toast("Đã làm mới dữ liệu mẫu", "success");
            }}
          />
        )}
      </section>

      <section className="settings-group" aria-labelledby="experience-title">
        <span className="eyebrow" id="experience-title">
          Trải nghiệm
        </span>
        <Switch
          label="Ẩn số tiền"
          description="Che số dư, tổng chi và số tiền mục tiêu trên mọi màn hình"
          checked={settings.hideAmounts}
          onChange={(next) => actions.updateSettings({ hideAmounts: next })}
        />
        <Switch
          label="Nhắc nhẹ trong ứng dụng"
          description="Báo khi chi tiêu hôm nay vượt mức gợi ý. Không gửi thông báo đẩy."
          checked={settings.nudges}
          onChange={(next) => actions.updateSettings({ nudges: next })}
        />
        <Switch
          label="Giảm chuyển động"
          description={systemReduces ? "Đang bật theo cài đặt của thiết bị" : "Tắt hiệu ứng di chuyển, giữ phản hồi cần thiết"}
          checked={settings.motion === "reduce" || systemReduces}
          onChange={(next) => actions.updateSettings({ motion: next ? "reduce" : "system" })}
        />
        <ActionRow icon="spark" label="Xem lại phần mở đầu" onClick={ui.replayIntro} />
      </section>

      <section className="settings-group" aria-labelledby="data-title">
        <span className="eyebrow" id="data-title">
          Dữ liệu
        </span>
        <ActionRow icon="download" label="Xuất giao dịch (CSV)" description="Mở được bằng Excel, Google Sheets" onClick={exportCsv} />
        <ActionRow icon="shield" label="Sao lưu" description="Tải về một tệp chứa toàn bộ dữ liệu và cài đặt" onClick={backup} />
        <ActionRow icon="upload" label="Khôi phục từ bản sao lưu" description="Thay dữ liệu hiện tại bằng tệp đã lưu" onClick={() => fileInput.current?.click()} />
        <input
          ref={fileInput}
          type="file"
          accept="application/json,.json"
          hidden
          onChange={(event) => {
            const file = event.target.files?.[0];
            if (file) void restore(file);
            event.target.value = "";
          }}
        />
        <ActionRow
          icon="trash"
          tone="danger"
          label={confirmClear ? "Chạm lần nữa để xoá vĩnh viễn" : "Xoá dữ liệu của tôi"}
          description="Xoá mọi giao dịch và mục tiêu bạn đã ghi trên thiết bị này"
          onClick={clearPersonal}
        />
      </section>

      <section className="privacy-note" aria-label="Quyền riêng tư">
        <Icon name="shield" />
        <p>
          Dữ liệu của bạn chỉ nằm trên thiết bị này. Benevolent chưa có tài khoản hay đồng bộ đám mây — hãy sao lưu định kỳ nếu bạn đổi máy hoặc xoá dữ liệu trình duyệt.
        </p>
      </section>

      <div className="version">Benevolent 2.1 · Được thiết kế tại Việt Nam</div>
    </main>
  );
}
