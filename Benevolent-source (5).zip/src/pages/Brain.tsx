import { useCallback, useEffect, useRef, useState } from "react";
import BrainVisualization, { type BrainPhase } from "../components/BrainVisualization";
import FactText, { FactValue } from "../components/FactText";
import Icon from "../components/Icon";
import { useFinancialSummary } from "../hooks/useFinancialSummary";
import { useReducedMotion } from "../hooks/useReducedMotion";
import {
  answerLocally,
  askBrain,
  isRemoteBrainConfigured,
  parseQuestion,
  SUGGESTED_QUESTIONS,
  type BrainAnswer,
  type ParsedQuestion,
} from "../services/brainService";
import { useFinance } from "../state/FinanceStore";

const MIN_THINK_MS = 1150;
const SLOW_MS = 2600;

const STEPS: { label: string; phases: BrainPhase[] }[] = [
  { label: "Dữ liệu", phases: ["activating", "relating", "focusing", "resolved"] },
  { label: "Quan hệ", phases: ["relating", "focusing", "resolved"] },
  { label: "Nhận định", phases: ["resolved"] },
];

export default function Brain() {
  const { workspace } = useFinance();
  const { summary, goals, brain } = useFinancialSummary();
  const reduced = useReducedMotion();
  const [parsed, setParsed] = useState<ParsedQuestion>(() => parseQuestion(SUGGESTED_QUESTIONS[0]));
  const [answer, setAnswer] = useState<BrainAnswer | null>(null);
  const [phase, setPhase] = useState<BrainPhase>("dormant");
  const [slow, setSlow] = useState(false);
  const [draft, setDraft] = useState("");
  const sequence = useRef(0);
  const cancelPrevious = useRef<() => void>(() => undefined);
  const latest = useRef({ summary, goals, brain });
  latest.current = { summary, goals, brain };

  const ask = useCallback(
    (question: string) => {
      cancelPrevious.current();
      const next = parseQuestion(question);
      sequence.current += 1;
      const id = sequence.current;
      const controller = new AbortController();
      const timers: number[] = [];
      const later = (fn: () => void, ms: number) => timers.push(window.setTimeout(() => sequence.current === id && fn(), ms));
      setParsed(next);
      setSlow(false);

      const { summary: s, goals: g, brain: b } = latest.current;
      if (reduced) {
        setPhase("relating");
        askBrain(next, b, s, g, controller.signal)
          .then((result) => {
            if (sequence.current !== id) return;
            setAnswer(result);
            setPhase("resolved");
          })
          .catch(() => undefined);
        cancelPrevious.current = () => controller.abort();
        return cancelPrevious.current;
      }

      setPhase("dormant");
      later(() => setPhase("activating"), 60);
      later(() => setPhase("relating"), 520);
      later(() => setSlow(true), SLOW_MS);
      const started = performance.now();
      askBrain(next, b, s, g, controller.signal)
        .then((result) => {
          const wait = Math.max(0, MIN_THINK_MS - (performance.now() - started));
          later(() => {
            setAnswer(result);
            setSlow(false);
            setPhase("focusing");
          }, wait);
          later(() => setPhase("resolved"), wait + 420);
        })
        .catch(() => undefined);
      cancelPrevious.current = () => {
        controller.abort();
        timers.forEach((timer) => window.clearTimeout(timer));
      };
      return cancelPrevious.current;
    },
    [reduced],
  );

  // Wake up once on arrival.
  useEffect(() => ask(SUGGESTED_QUESTIONS[0]), [ask]);

  // When the underlying data changes, keep a local answer in sync with the new facts.
  useEffect(() => {
    setAnswer((current) => (current && current.source === "local" ? answerLocally(parseQuestion(current.question), brain, summary, goals) : current));
  }, [brain, summary, goals]);

  const facts = { ...brain.facts, ...(answer?.facts ?? {}) };
  const resolved = phase === "resolved" && answer;
  const nodeIds = [
    "balance",
    "todayExpense",
    "last7Total",
    "dailyAllowance",
    ...summary.categories.filter((c) => c.amount > 0).slice(0, 3).map((c) => `cat:${c.id}`),
    "goal:percent",
  ].filter((id) => id in brain.facts);
  const focusFacts = (answer?.focus ?? []).filter((id) => facts[id] && facts[id].kind !== "text").slice(0, 3);

  const status =
    phase === "resolved"
      ? `Đã phân tích ${brain.transactionCount} giao dịch${workspace === "demo" ? " mẫu" : ""}`
      : slow
        ? "Brain đang suy nghĩ lâu hơn bình thường…"
        : phase === "relating" || phase === "focusing"
          ? "Đang nối các dữ kiện…"
          : "Đang đọc dữ liệu…";

  return (
    <main className="view brain-view" id="main">
      <div className="page-title">
        <span className="eyebrow">Benevolent Intelligence{workspace === "demo" && " · Dữ liệu mẫu"}</span>
        <h1>Brain</h1>
        <p>Không phán xét. Chỉ giúp bạn nhìn rõ hơn.</p>
      </div>

      <section className={`intelligence-surface intelligence-surface--${phase}`} aria-busy={!resolved} data-camera-stop="brain">
        <div className="brain-status">
          <span className="pulse-dot" aria-hidden="true" />
          {status}
        </div>

        <BrainVisualization facts={facts} nodeIds={nodeIds} focus={answer?.focus ?? []} phase={phase} />

        <div className="brain-answer" aria-live="polite">
          <p className="answer-kicker">{parsed.text || SUGGESTED_QUESTIONS[0]}</p>
          {resolved ? (
            <>
              <div className="answer-main">
                <strong>
                  <FactText template={answer.lead} facts={facts} />
                </strong>
                {answer.stat && facts[answer.stat] && (
                  <span>
                    <FactValue fact={facts[answer.stat]} compact />
                  </span>
                )}
              </div>
              <p className="answer-detail">
                <FactText template={answer.detail} facts={facts} />
              </p>
              {answer.notice && (
                <p className="answer-notice">
                  <Icon name="alert" size={14} /> {answer.notice}
                </p>
              )}
            </>
          ) : (
            <div className="answer-pending" aria-hidden="true">
              <i />
              <i />
            </div>
          )}
        </div>

        <ol className="reasoning-line" aria-label="Cách Brain trả lời">
          {STEPS.map((step) => (
            <li key={step.label} className={step.phases.includes(phase) ? "reasoning-line--on" : ""}>
              <i aria-hidden="true" />
              {step.label}
            </li>
          ))}
        </ol>

        {resolved && focusFacts.length > 0 && (
          <dl className="brain-facts">
            {focusFacts.map((id) => (
              <div key={id}>
                <dt>{facts[id].label}</dt>
                <dd>
                  <FactValue fact={facts[id]} />
                </dd>
              </div>
            ))}
          </dl>
        )}
      </section>

      <form
        className="brain-ask"
        onSubmit={(event) => {
          event.preventDefault();
          if (!draft.trim()) return;
          ask(draft);
          setDraft("");
        }}
      >
        <label htmlFor="brain-question" className="sr-only">
          Hỏi Brain về tiền của bạn
        </label>
        <input
          id="brain-question"
          value={draft}
          onChange={(event) => setDraft(event.target.value)}
          placeholder="Hỏi Brain — ví dụ: mua giày 450k được không?"
          maxLength={120}
          enterKeyHint="send"
          autoComplete="off"
        />
        <button type="submit" className="button" aria-label="Gửi câu hỏi" disabled={!draft.trim()}>
          <Icon name="arrow" />
        </button>
      </form>

      <section className="prompts" aria-labelledby="prompts-title">
        <span className="eyebrow" id="prompts-title">
          Hỏi từ dữ liệu của bạn
        </span>
        {SUGGESTED_QUESTIONS.map((prompt) => (
          <button
            key={prompt}
            type="button"
            className={`button ${parsed.text === prompt ? "prompt--active" : ""}`}
            aria-pressed={parsed.text === prompt}
            onClick={() => ask(prompt)}
          >
            <span>{prompt}</span>
            <Icon name="arrow" />
          </button>
        ))}
      </section>

      <p className="brain-disclaimer">
        {isRemoteBrainConfigured
          ? "Brain tính mọi con số trên thiết bị, rồi chỉ gửi các dữ kiện cần thiết (không gửi ghi chú hay danh sách giao dịch) để diễn đạt câu trả lời."
          : "Brain phân tích hoàn toàn trên thiết bị của bạn — không gửi dữ liệu ra ngoài."}{" "}
        Thông tin chỉ mang tính tham khảo, không phải tư vấn tài chính.
      </p>
    </main>
  );
}
