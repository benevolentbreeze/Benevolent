import { useState } from "react";
import BalanceHero from "../components/BalanceHero";
import Brand from "../components/Brand";
import CategoryEcosystem from "../components/CategoryEcosystem";
import FactText from "../components/FactText";
import Icon from "../components/Icon";
import { Money } from "../components/MoneyDisplay";
import StatusBanner from "../components/StatusBanner";
import TransactionRow from "../components/TransactionRow";
import { useFinancialSummary } from "../hooks/useFinancialSummary";
import { answerLocally } from "../services/brainService";
import { useFinance } from "../state/FinanceStore";
import { useUI } from "../state/UIStore";
import { formatLongDate, formatMonth } from "../utils/date";
import { formatPercent } from "../utils/money";

function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return "";
  return (parts.length > 1 ? parts[0][0] + parts[parts.length - 1][0] : parts[0].slice(0, 2)).toUpperCase();
}

export default function Home() {
  const { data, settings, workspace } = useFinance();
  const { summary, goals, brain } = useFinancialSummary();
  const ui = useUI();
  const [storyImageFailed, setStoryImageFailed] = useState(false);
  const insight = answerLocally({ text: "", intent: "highlights" }, brain, summary, goals);
  const primary = goals[0];
  const recent = data.transactions.slice(0, 4);
  const lastFive = summary.last7.slice(2);
  const lastFiveMax = Math.max(1, ...lastFive.map((p) => p.expense));
  const avatar = initials(settings.displayName);

  return (
    <main className="view home-view" id="main">
      <header className="mobile-header">
        <Brand />
        <button type="button" className="button avatar" aria-label="Mở hồ sơ và cài đặt" onClick={() => ui.navigate("settings")}>
          {avatar || <Icon name="settings" size={18} />}
        </button>
      </header>

      <div className="eyebrow-row">
        <span className="eyebrow">{formatLongDate(summary.now)}</span>
        {workspace === "demo" && <span className="demo-pill">Dữ liệu mẫu</span>}
      </div>
      <StatusBanner />

      <BalanceHero />

      <section className="metric-strip" aria-label="Tóm tắt chi tiêu">
        <div>
          <span>Hôm nay</span>
          <strong>
            <Money value={summary.todayExpense} />
          </strong>
          <small>{summary.todayCount ? `${summary.todayCount} khoản chi` : "Chưa chi gì"}</small>
        </div>
        <div>
          <span>{formatMonth(summary.now)}</span>
          <strong>
            <Money value={summary.monthExpense} />
          </strong>
          <small>{summary.spendingRatio !== null ? `${formatPercent(summary.spendingRatio)} thu nhập` : "Chưa có khoản thu"}</small>
        </div>
        <div className="mini-bars" aria-hidden="true">
          {lastFive.map((point, index) => (
            <i
              key={point.key}
              className={index === lastFive.length - 1 ? "mini-bars--today" : ""}
              style={{ transform: `scaleY(${Math.max(0.06, point.expense / lastFiveMax)})` }}
            />
          ))}
        </div>
      </section>

      <CategoryEcosystem />

      <button type="button" className="button brain-teaser" onClick={() => ui.navigate("brain")} data-camera-stop="brain">
        <span className="brain-signal" aria-hidden="true">
          <span />
          <span />
          <span />
          <span />
        </span>
        <span className="brain-copy">
          <span className="eyebrow">Benevolent Brain</span>
          <strong>
            <FactText template={insight.lead} facts={{ ...brain.facts, ...insight.facts }} />
          </strong>
          <span className="brain-copy-detail">
            <FactText template={insight.detail} facts={{ ...brain.facts, ...insight.facts }} />
          </span>
        </span>
        <Icon name="arrow" />
      </button>

      <section className={`story-frame ${storyImageFailed ? "story-frame--no-image" : ""}`} aria-label="Benevolent trong nhịp sống thành phố">
        {!storyImageFailed && (
          <img
            src="https://images.unsplash.com/photo-1748596161492-0ebbc90489a5?auto=format&fit=crop&w=1100&q=78"
            srcSet="https://images.unsplash.com/photo-1748596161492-0ebbc90489a5?auto=format&fit=crop&w=640&q=76 640w, https://images.unsplash.com/photo-1748596161492-0ebbc90489a5?auto=format&fit=crop&w=1100&q=78 1100w"
            sizes="(max-width: 767px) 100vw, 660px"
            loading="lazy"
            referrerPolicy="no-referrer"
            decoding="async"
            alt="Nhịp chuyển động của một con phố Việt Nam về đêm"
            data-camera-parallax
            onError={() => setStoryImageFailed(true)}
          />
        )}
        <div className="story-shutter" aria-hidden="true" />
        <div className="story-copy">
          <span>Thành phố chuyển động.</span>
          <strong>
            Tiền của bạn
            <br />
            cũng vậy.
          </strong>
          {!storyImageFailed && <small>Ảnh: Hanna Lazar / Unsplash</small>}
        </div>
      </section>

      <section className="section-block" aria-labelledby="recent-title">
        <div className="section-heading">
          <div>
            <span className="eyebrow">Dòng tiền</span>
            <h2 id="recent-title">Gần đây</h2>
          </div>
          {recent.length > 0 && (
            <button type="button" className="button text-link" onClick={() => ui.navigate("history")}>
              Xem tất cả
            </button>
          )}
        </div>
        <div className="transaction-list" data-transfer-target="ledger">
          {recent.length ? (
            recent.map((tx) => <TransactionRow key={tx.id} tx={tx} goals={data.goals} onOpen={(item) => ui.openEntry({ mode: "edit", tx: item })} />)
          ) : (
            <div className="empty-state">
              <strong>Chưa có giao dịch nào.</strong>
              <p>Bắt đầu bằng số dư hiện có, rồi ghi từng khoản chi — mọi con số trong Benevolent sẽ tính từ đây.</p>
              <div className="empty-actions">
                <button type="button" className="button pill-button" onClick={() => ui.openEntry({ mode: "create", type: "income" })}>
                  <Icon name="plus" size={16} /> Ghi số dư hoặc khoản thu
                </button>
              </div>
            </div>
          )}
        </div>
      </section>

      {primary ? (
        <button type="button" className="button goal-teaser" onClick={() => ui.navigate("goals")} data-camera-stop="goals">
          <span className="goal-meta">
            <span className="eyebrow">Mục tiêu tiếp theo</span>
            <span>{formatPercent(primary.percent / 100, 1)}</span>
          </span>
          <span className="goal-teaser-name">{primary.goal.name}</span>
          <span className="goal-track" aria-hidden="true">
            <span style={{ width: `${primary.percent}%` }} />
          </span>
          <span className="goal-bottom">
            <strong>
              <Money value={primary.savedAmount} />
            </strong>
            <span>
              trên <Money value={primary.goal.targetAmount} />
            </span>
          </span>
        </button>
      ) : (
        <button type="button" className="button goal-teaser goal-teaser--empty" onClick={() => ui.navigate("goals")} data-camera-stop="goals">
          <span className="eyebrow">Mục tiêu</span>
          <span className="goal-teaser-name">Đặt mục tiêu đầu tiên</span>
          <span className="goal-bottom">Benevolent sẽ tính số cần để dành mỗi tháng.</span>
        </button>
      )}

      <button type="button" className="button add-button" onClick={() => ui.openEntry()} aria-label="Thêm khoản chi">
        <Icon name="plus" />
        <span aria-hidden="true">Thêm khoản chi</span>
      </button>
    </main>
  );
}
