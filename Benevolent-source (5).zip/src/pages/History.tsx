import { useMemo, useState } from "react";
import Icon from "../components/Icon";
import { Money } from "../components/MoneyDisplay";
import TransactionRow from "../components/TransactionRow";
import { EXPENSE_CATEGORIES } from "../data/categories";
import { useFinancialSummary } from "../hooks/useFinancialSummary";
import { computeMonth } from "../services/financialEngine";
import { useFinance } from "../state/FinanceStore";
import { useUI } from "../state/UIStore";
import type { CategoryId } from "../types/category";
import type { Transaction } from "../types/transaction";
import { addMonths, formatDayHeading, formatMonth, parseLocal, startOfMonth, toMonthKey } from "../utils/date";

type Filter = "all" | CategoryId;

const FILTERS: { id: Filter; label: string }[] = [
  { id: "all", label: "Tất cả" },
  ...EXPENSE_CATEGORIES.map((category) => ({ id: category.id as Filter, label: category.label })),
  { id: "income", label: "Khoản thu" },
  { id: "saving", label: "Tiết kiệm" },
];

export default function History() {
  const { data, workspace } = useFinance();
  const { now } = useFinancialSummary();
  const ui = useUI();
  const [month, setMonth] = useState(() => startOfMonth(now));
  const [filter, setFilter] = useState<Filter>("all");

  const monthKey = toMonthKey(month);
  const isCurrentMonth = monthKey === toMonthKey(now);
  const oldest = data.transactions[data.transactions.length - 1];
  const canGoBack = oldest ? oldest.date.slice(0, 7) < monthKey : false;

  const totals = useMemo(() => computeMonth(data, month, now), [data, month, now]);
  const maxDay = Math.max(1, ...totals.days.map((day) => day.expense));

  const groups = useMemo(() => {
    const map = new Map<string, Transaction[]>();
    for (const tx of data.transactions) {
      if (!tx.date.startsWith(monthKey)) continue;
      if (filter !== "all" && tx.category !== filter) continue;
      const key = tx.date.slice(0, 10);
      map.set(key, [...(map.get(key) ?? []), tx]);
    }
    return [...map.entries()];
  }, [data.transactions, monthKey, filter]);

  const open = (tx: Transaction) => ui.openEntry({ mode: "edit", tx });

  return (
    <main className="view inner-view history-view" id="main">
      <div className="page-title">
        <span className="eyebrow">
          {formatMonth(month, now)}
          {workspace === "demo" && " · Dữ liệu mẫu"}
        </span>
        <h1>Lịch sử</h1>
        <p>Mỗi khoản chi, một dấu vết.</p>
      </div>

      <div className="month-switcher">
        <button type="button" className="button icon-button" onClick={() => setMonth(addMonths(month, -1))} disabled={!canGoBack} aria-label="Tháng trước">
          <Icon name="chevronLeft" />
        </button>
        <strong aria-live="polite">{formatMonth(month, now)}</strong>
        <button type="button" className="button icon-button" onClick={() => setMonth(addMonths(month, 1))} disabled={isCurrentMonth} aria-label="Tháng sau">
          <Icon name="chevron" />
        </button>
      </div>

      <section className="history-summary" data-transfer-target="ledger" aria-label={`Tổng kết ${formatMonth(month, now)}`}>
        <div>
          <span>Đã chi {isCurrentMonth ? "tháng này" : formatMonth(month, now).toLowerCase()}</span>
          <strong>
            <Money value={totals.expense} />
          </strong>
        </div>
        <dl className="history-totals">
          <div>
            <dt>Thu</dt>
            <dd>
              <Money value={totals.income} />
            </dd>
          </div>
          <div>
            <dt>Tiết kiệm</dt>
            <dd>
              <Money value={totals.saved} />
            </dd>
          </div>
        </dl>
        <div className="history-line" aria-hidden="true">
          {totals.days.map((day, index) => (
            <i
              key={day.key}
              className={isCurrentMonth && index === totals.days.length - 1 ? "history-line--today" : ""}
              style={{ transform: `scaleY(${Math.max(0.03, day.expense / maxDay)})` }}
            />
          ))}
        </div>
      </section>

      <div className="filter-row" role="group" aria-label="Lọc giao dịch">
        {FILTERS.map((item) => (
          <button
            key={item.id}
            type="button"
            className={`button filter-chip ${filter === item.id ? "filter-chip--active" : ""}`}
            aria-pressed={filter === item.id}
            onClick={() => setFilter(item.id)}
          >
            {item.label}
          </button>
        ))}
      </div>

      {groups.length === 0 ? (
        <div className="empty-state">
          <strong>{filter === "all" ? "Chưa có giao dịch trong tháng này." : "Không có giao dịch phù hợp."}</strong>
          <p>{filter === "all" ? "Các khoản bạn ghi lại sẽ xuất hiện ở đây theo từng ngày." : "Thử chọn bộ lọc khác."}</p>
        </div>
      ) : (
        groups.map(([day, items]) => {
          const date = parseLocal(day) ?? now;
          const spent = items.filter((tx) => tx.type === "expense").reduce((sum, tx) => sum + tx.amount, 0);
          return (
            <section className="timeline-group" key={day} aria-label={formatDayHeading(date, now)}>
              <div className="timeline-date">
                <h2>{formatDayHeading(date, now)}</h2>
                {spent > 0 && <Money value={spent} negative />}
              </div>
              {items.map((tx) => (
                <TransactionRow key={tx.id} tx={tx} goals={data.goals} onOpen={open} />
              ))}
            </section>
          );
        })
      )}

      <button type="button" className="button add-button" onClick={() => ui.openEntry()} aria-label="Thêm khoản chi">
        <Icon name="plus" />
        <span aria-hidden="true">Thêm khoản chi</span>
      </button>
    </main>
  );
}
