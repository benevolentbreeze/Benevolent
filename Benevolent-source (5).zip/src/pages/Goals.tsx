import { useEffect, useRef, useState } from "react";
import ContributeSheet from "../components/ContributeSheet";
import GoalSheet from "../components/GoalSheet";
import GoalVisualization, { type JourneyPhase } from "../components/GoalVisualization";
import Icon from "../components/Icon";
import { AnimatedMoney, Money } from "../components/MoneyDisplay";
import { useFinancialSummary } from "../hooks/useFinancialSummary";
import { useReducedMotion } from "../hooks/useReducedMotion";
import { buildTransaction } from "../services/transactionService";
import { useFinance } from "../state/FinanceStore";
import { useUI } from "../state/UIStore";
import type { GoalProgress } from "../types/goal";
import { formatMonthYear, formatNumericDate, parseLocal, toLocalDateTime } from "../utils/date";
import { formatMoney, formatPercent, HIDDEN_MONEY } from "../utils/money";

const ENTER_MS = 620;
const ADVANCE_MS = 1250;
const CAMERA_MS = 520;

function GoalInsight({ progress }: { progress: GoalProgress }) {
  const { settings } = useFinance();
  const money = (value: number) => (settings.hideAmounts ? HIDDEN_MONEY : formatMoney(Math.ceil(value / 1000) * 1000));
  const deadline = parseLocal(progress.goal.deadline);
  let title: string;
  let body: string;
  if (progress.isComplete) {
    title = "Bạn đã tới đích.";
    body = `Đã tiết kiệm đủ ${money(progress.goal.targetAmount)}.`;
  } else if (progress.isOverdue) {
    title = "Mục tiêu đã quá hạn.";
    body = `Còn thiếu ${money(progress.remaining)}. Chọn hạn mới để Benevolent tính lại nhịp góp.`;
  } else if (progress.paceSource === "none") {
    title = "Chọn một nhịp góp.";
    body = `Để kịp hạn ${deadline ? formatNumericDate(deadline) : ""}, bạn cần khoảng ${money(progress.requiredMonthly)} mỗi tháng.`;
  } else if (progress.onTrack) {
    title = "Đều đặn sẽ tới nơi.";
    body = `Với ${money(progress.pace)} mỗi tháng${progress.paceSource === "history" ? " (nhịp góp thực tế 90 ngày qua)" : ""}, bạn sẽ đạt mục tiêu vào ${progress.estimatedCompletion ? formatMonthYear(progress.estimatedCompletion) : "—"}, trước hạn.`;
  } else {
    title = "Nhịp hiện tại chưa đủ.";
    body = `Với ${money(progress.pace)} mỗi tháng, đến hạn bạn còn thiếu khoảng ${money(Math.abs(progress.projectedGap))}. Cần khoảng ${money(progress.requiredMonthly)} mỗi tháng để kịp.`;
  }
  return (
    <section className="goal-note" aria-live="polite">
      <Icon name="spark" />
      <div>
        <strong>{title}</strong>
        <p>{body}</p>
      </div>
    </section>
  );
}

export default function Goals() {
  const { actions, settings, workspace } = useFinance();
  const { goals, now } = useFinancialSummary();
  const ui = useUI();
  const reduced = useReducedMotion();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [sheet, setSheet] = useState<"create" | "edit" | "contribute" | null>(null);
  const [phase, setPhase] = useState<JourneyPhase>("idle");
  const [incoming, setIncoming] = useState(0);
  const [previousPercent, setPreviousPercent] = useState(0);
  const timers = useRef<number[]>([]);
  const journeyRef = useRef<HTMLElement>(null);

  const pendingCommits = useRef<(() => void)[]>([]);
  // Leaving the page mid-animation must not drop the contribution: apply it now.
  useEffect(
    () => () => {
      timers.current.forEach((timer) => window.clearTimeout(timer));
      pendingCommits.current.forEach((commit) => commit());
    },
    [],
  );

  const selected = goals.find((item) => item.goal.id === selectedId) ?? goals[0] ?? null;
  const selectedIndex = selected ? goals.indexOf(selected) : -1;

  const contribute = (amount: number) => {
    if (!selected) return;
    const goal = selected.goal;
    const tx = buildTransaction({ amount, type: "saving", category: "saving", note: "", date: toLocalDateTime(new Date()), goalId: goal.id });
    setPreviousPercent(selected.percent);
    const done = () => ui.toast(`Đã góp ${settings.hideAmounts ? "" : formatMoney(amount) + " "}vào ${goal.name}`, "success");
    if (reduced) {
      actions.addTransaction(tx, workspace);
      done();
      return;
    }
    // Camera: bring the journey into view first, then let the contribution travel along it.
    const horizon = journeyRef.current?.querySelector(".goal-horizon");
    const rect = horizon?.getBoundingClientRect();
    const needsCamera = rect ? rect.top < 0 || rect.bottom > window.innerHeight * 0.7 : false;
    if (needsCamera) horizon?.scrollIntoView({ behavior: "smooth", block: "center" });
    const lead = needsCamera ? CAMERA_MS : 0;
    setIncoming(amount);
    const commit = ui.deferCommit(() => {
      actions.addTransaction(tx, workspace);
      done();
    });
    pendingCommits.current.push(commit);
    timers.current.push(
      window.setTimeout(() => setPhase("entering"), lead),
      window.setTimeout(() => {
        commit();
        setPhase("advancing");
      }, lead + ENTER_MS),
      window.setTimeout(() => setPhase("idle"), lead + ENTER_MS + ADVANCE_MS),
    );
  };

  return (
    <main className="view goals-view" id="main">
      <div className="page-title">
        <span className="eyebrow">Hành trình của bạn{workspace === "demo" && " · Dữ liệu mẫu"}</span>
        <h1>Mục tiêu</h1>
        <p>{selected && !selected.isComplete ? "Khoảng cách đang ngắn lại." : "Đặt một điểm đến, Benevolent vẽ đường đi."}</p>
      </div>

      {goals.length > 1 && (
        <div className="filter-row goal-switcher" role="group" aria-label="Chọn mục tiêu">
          {goals.map((item, index) => (
            <button
              key={item.goal.id}
              type="button"
              aria-pressed={item === selected}
              className={`button filter-chip ${item === selected ? "filter-chip--active" : ""}`}
              onClick={() => setSelectedId(item.goal.id)}
            >
              {item.goal.name}
              {index === 0 && <span className="chip-badge">Chính</span>}
            </button>
          ))}
        </div>
      )}

      {!selected ? (
        <section className="goal-cinematic goal-cinematic--empty">
          <div className="goal-horizon goal-horizon--dormant" aria-hidden="true">
            <div className="horizon-line" />
            <div className="milestone milestone--start">
              <i />
              <span>Bây giờ</span>
            </div>
            <div className="milestone milestone--end">
              <i />
              <span>?</span>
            </div>
          </div>
          <div className="empty-state">
            <strong>Chưa có mục tiêu nào.</strong>
            <p>Một chiếc laptop, chuyến đi cuối kỳ hay quỹ dự phòng — đặt số tiền và hạn, Benevolent sẽ tính nhịp góp mỗi tháng và ngày bạn tới nơi.</p>
            <div className="empty-actions">
              <button type="button" className="button contribute" onClick={() => setSheet("create")}>
                <Icon name="plus" /> Tạo mục tiêu
              </button>
            </div>
          </div>
        </section>
      ) : (
        <>
          <section
            ref={journeyRef}
            style={{ "--progress": `${selected.percent}%` } as React.CSSProperties}
            className={`goal-cinematic goal-cinematic--${phase}`} aria-labelledby="goal-name" data-camera-stop="goals">
            <GoalVisualization progress={selected} phase={phase} previousPercent={previousPercent} />
            {phase === "entering" && (
              <span className="contribution-chip" aria-hidden="true">
                +{settings.hideAmounts ? HIDDEN_MONEY : formatMoney(incoming)}
              </span>
            )}
            <div className="goal-title">
              <div>
                <span className="eyebrow">{selectedIndex === 0 ? "Mục tiêu chính" : "Mục tiêu"}</span>
                <h2 id="goal-name">{selected.goal.name}</h2>
              </div>
              <button type="button" className="button icon-button" onClick={() => setSheet("edit")} aria-label={`Sửa mục tiêu ${selected.goal.name}`}>
                <Icon name="edit" size={18} />
              </button>
            </div>
            <div className="goal-amount">
              <strong>
                <AnimatedMoney value={selected.savedAmount} />
              </strong>
              <span>
                trên <Money value={selected.goal.targetAmount} />
              </span>
            </div>
            <div className="goal-progress-copy">
              <strong>{formatPercent(selected.percent / 100, 1)}</strong>
              <span>
                {selected.isComplete ? (
                  "Hoàn thành"
                ) : (
                  <>
                    Còn <Money value={selected.remaining} />
                  </>
                )}
              </span>
            </div>
            <dl className="goal-stats">
              <div>
                <dt>Cần mỗi tháng</dt>
                <dd>{selected.isComplete ? "—" : <Money value={Math.ceil(selected.requiredMonthly / 1000) * 1000} compact />}</dd>
              </div>
              <div>
                <dt>{selected.paceSource === "history" ? "Nhịp thực tế" : "Nhịp đã đặt"}</dt>
                <dd>{selected.pace > 0 ? <Money value={selected.pace} compact /> : "Chưa có"}</dd>
              </div>
              <div>
                <dt>Dự kiến xong</dt>
                <dd>{selected.estimatedCompletion ? formatMonthYear(selected.estimatedCompletion) : "—"}</dd>
              </div>
              <div>
                <dt>Hạn</dt>
                <dd>{formatNumericDate(parseLocal(selected.goal.deadline) ?? now)}</dd>
              </div>
            </dl>
            {!selected.isComplete && (
              <button type="button" className="button contribute" onClick={() => setSheet("contribute")} disabled={phase !== "idle"}>
                <Icon name={phase === "idle" ? "plus" : "arrow"} />
                {phase === "idle" ? "Góp vào mục tiêu" : "Đang tiến gần hơn…"}
              </button>
            )}
          </section>
          <GoalInsight progress={selected} />
          <button type="button" className="button text-link add-goal" onClick={() => setSheet("create")}>
            <Icon name="plus" size={16} /> Thêm mục tiêu khác
          </button>
        </>
      )}

      {(sheet === "create" || (sheet === "edit" && selected)) && (
        <GoalSheet
          progress={sheet === "edit" ? selected : null}
          isPrimary={selectedIndex === 0}
          onClose={() => setSheet(null)}
          onSaved={(id) => setSelectedId(id)}
        />
      )}
      {sheet === "contribute" && selected && <ContributeSheet progress={selected} onClose={() => setSheet(null)} onConfirm={contribute} />}
    </main>
  );
}
