import type { CategoryDefinition, CategoryId, ExpenseCategoryId } from "../types/category";

export const EXPENSE_CATEGORIES: (CategoryDefinition & { id: ExpenseCategoryId })[] = [
  { id: "food", label: "Ăn uống", icon: "food" },
  { id: "transport", label: "Di chuyển", icon: "transport" },
  { id: "study", label: "Học tập", icon: "study" },
  { id: "entertainment", label: "Giải trí", icon: "entertainment" },
  { id: "shopping", label: "Mua sắm", icon: "shopping" },
  { id: "other", label: "Khác", icon: "other" },
];

const SYSTEM_CATEGORIES: CategoryDefinition[] = [
  { id: "income", label: "Thu nhập", icon: "income" },
  { id: "saving", label: "Tiết kiệm", icon: "goal" },
];

const ALL = new Map<CategoryId, CategoryDefinition>(
  [...EXPENSE_CATEGORIES, ...SYSTEM_CATEGORIES].map((category) => [category.id, category]),
);

export function getCategory(id: CategoryId): CategoryDefinition {
  return ALL.get(id) ?? EXPENSE_CATEGORIES[EXPENSE_CATEGORIES.length - 1];
}

export function isCategoryId(value: unknown): value is CategoryId {
  return typeof value === "string" && ALL.has(value as CategoryId);
}

export function isExpenseCategory(value: unknown): value is ExpenseCategoryId {
  return EXPENSE_CATEGORIES.some((category) => category.id === value);
}
