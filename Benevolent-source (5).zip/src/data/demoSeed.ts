/**
 * Demo seed data. Lives in its own workspace ("demo") and is never mixed with
 * the user's personal workspace. Generated relative to the day it is created,
 * then persisted, so the numbers stay stable while the user explores.
 */
import type { Goal } from "../types/goal";
import type { Transaction } from "../types/transaction";
import type { ExpenseCategoryId } from "../types/category";
import type { WorkspaceData } from "../types/state";
import { sortTransactions } from "../services/transactionService";
import { addDays, addMonths, toDateKey, toLocalDateTime } from "../utils/date";

type Pattern = {
  category: ExpenseCategoryId;
  chance: number;
  min: number;
  max: number;
  hours: [number, number];
  notes: string[];
};

const DAILY_PATTERNS: Pattern[] = [
  { category: "food", chance: 0.6, min: 15, max: 35, hours: [6, 8], notes: ["Bánh mì", "Xôi gà", "Phở bò", "Bánh cuốn"] },
  { category: "food", chance: 0.9, min: 30, max: 55, hours: [11, 13], notes: ["Cơm tấm", "Bún bò Huế", "Cơm văn phòng", "Mì Quảng", "Ăn trưa với Minh"] },
  { category: "food", chance: 0.4, min: 25, max: 45, hours: [14, 16], notes: ["Highlands Coffee", "Trà sữa", "Cà phê muối — học nhóm"] },
  { category: "food", chance: 0.35, min: 35, max: 65, hours: [18, 20], notes: ["Bún chả", "Cơm nhà trọ", "Bánh xèo"] },
  { category: "transport", chance: 0.55, min: 15, max: 35, hours: [7, 9], notes: ["GrabBike đến trường", "Xăng xe", "Gửi xe"] },
  { category: "entertainment", chance: 0.1, min: 60, max: 150, hours: [19, 21], notes: ["CGV Cinema", "Karaoke với lớp", "Vé bóng đá"] },
  { category: "shopping", chance: 0.09, min: 70, max: 320, hours: [17, 21], notes: ["Circle K", "Áo khoác", "Đồ dùng phòng trọ"] },
  { category: "study", chance: 0.08, min: 30, max: 180, hours: [9, 16], notes: ["Photo tài liệu", "Giáo trình Kinh tế vi mô", "Bút & vở"] },
  { category: "other", chance: 0.03, min: 30, max: 100, hours: [10, 18], notes: ["Quà sinh nhật bạn", "Cắt tóc"] },
];

function createRandom(seed: number) {
  let state = seed >>> 0;
  return () => {
    state = (state + 0x6d2b79f5) >>> 0;
    let t = state;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const roundThousand = (value: number) => Math.round(value) * 1000;

export function createDemoWorkspace(now: Date = new Date()): WorkspaceData {
  const random = createRandom(20251008);
  const pick = <T,>(items: T[]) => items[Math.floor(random() * items.length)];
  const transactions: Transaction[] = [];
  let counter = 0;

  const nowStamp = toLocalDateTime(now);
  const push = (tx: Omit<Transaction, "id" | "createdAt">) => {
    if (tx.date > nowStamp) return;
    counter += 1;
    transactions.push({ ...tx, id: `demo_${counter}`, createdAt: new Date(`${tx.date}:00`).toISOString() });
  };

  const start = addDays(now, -62);
  const macbookId = "demo_goal_macbook";
  const reserveId = "demo_goal_reserve";

  push({ type: "income", category: "income", amount: 2_000_000, note: "Số dư chuyển sang", date: `${toDateKey(start)}T08:00` });

  for (let offset = 0; offset <= 62; offset += 1) {
    const day = addDays(start, offset);
    const dayKey = toDateKey(day);

    if (day.getDate() === 1) {
      push({ type: "income", category: "income", amount: 4_500_000, note: `Bố mẹ gửi tiền tháng ${day.getMonth() + 1}`, date: `${dayKey}T09:00` });
    }
    if (day.getDate() === 15) {
      push({ type: "income", category: "income", amount: 1_200_000, note: "Gia sư Toán lớp 9", date: `${dayKey}T20:00` });
    }
    if (day.getDate() === 2) {
      push({ type: "saving", category: "saving", amount: 500_000, note: "", date: `${dayKey}T10:00`, goalId: macbookId });
    }
    if (day.getDate() === 3) {
      push({ type: "saving", category: "saving", amount: 300_000, note: "", date: `${dayKey}T10:00`, goalId: reserveId });
    }

    for (const pattern of DAILY_PATTERNS) {
      if (random() > pattern.chance) continue;
      const hour = pattern.hours[0] + Math.floor(random() * (pattern.hours[1] - pattern.hours[0] + 1));
      const minute = Math.floor(random() * 60);
      const at = new Date(day.getFullYear(), day.getMonth(), day.getDate(), hour, minute);
      push({
        type: "expense",
        category: pattern.category,
        amount: roundThousand(pattern.min + random() * (pattern.max - pattern.min)),
        note: pick(pattern.notes),
        date: toLocalDateTime(at),
      });
    }
  }

  // Money the student had already set aside before the demo period: an opening balance
  // moved straight into each goal, so balance + goal savings stays consistent.
  const openingFor = (goalId: string, amount: number, daysAgo: number) => {
    const date = `${toDateKey(addDays(now, -daysAgo))}T08:00`;
    push({ type: "income", category: "income", amount, note: "Tiền tiết kiệm từ trước", date, opening: true });
    push({ type: "saving", category: "saving", amount, note: "", date, goalId, opening: true });
  };
  openingFor(macbookId, 7_450_000, 120);
  openingFor(reserveId, 1_500_000, 90);

  const deadline = addMonths(now, 8);
  deadline.setDate(15);
  const reserveDeadline = addMonths(now, 5);
  reserveDeadline.setDate(28);

  const goals: Goal[] = [
    {
      id: macbookId,
      name: "MacBook Air",
      targetAmount: 25_000_000,
      deadline: toDateKey(deadline),
      monthlyContribution: 1_000_000,
      createdAt: addDays(now, -120).toISOString(),
    },
    {
      id: reserveId,
      name: "Quỹ dự phòng",
      targetAmount: 6_000_000,
      deadline: toDateKey(reserveDeadline),
      monthlyContribution: 300_000,
      createdAt: addDays(now, -90).toISOString(),
    },
  ];

  return { transactions: sortTransactions(transactions), goals };
}

export function createEmptyWorkspace(): WorkspaceData {
  return { transactions: [], goals: [] };
}
