/**
 * Benevolent Brain
 *
 *   user data → financial engine → structured facts → Brain → explanation
 *
 * The engine calculates. Brain only explains. Answers are templates that
 * reference facts by id ("{balance}"); the UI resolves them from the facts,
 * so neither the local composer nor a remote model can invent a number.
 */
import { EXPENSE_CATEGORIES } from "../data/categories";
import type { ExpenseCategoryId } from "../types/category";
import type { FinancialSummary } from "../types/financialSummary";
import type { GoalProgress } from "../types/goal";
import { formatMonthYear, formatNumericDate, parseLocal } from "../utils/date";
import { simulatePurchase } from "./financialEngine";

export type FactKind = "money" | "percent" | "trend" | "count" | "days" | "text";

export interface Fact {
  id: string;
  label: string;
  kind: FactKind;
  value: number;
  text?: string;
}

export type FactMap = Record<string, Fact>;

export interface BrainContext {
  facts: FactMap;
  transactionCount: number;
  hasSpending: boolean;
  isDemo: boolean;
}

export type BrainIntent = "highlights" | "allowance" | "afford" | "goal" | "category" | "unknown";

export interface ParsedQuestion {
  text: string;
  intent: BrainIntent;
  amount?: number;
  categoryId?: ExpenseCategoryId;
}

export interface BrainAnswer {
  question: string;
  intent: BrainIntent;
  lead: string;
  detail: string;
  /** Fact shown as the large figure next to the answer. */
  stat?: string;
  /** Facts the answer is built on — emphasised in the visualization. */
  focus: string[];
  /** Question-specific facts (e.g. a simulated purchase). */
  facts: FactMap;
  source: "local" | "remote";
  notice?: string;
}

/* ------------------------------------------------------------------ */
/* Context                                                              */
/* ------------------------------------------------------------------ */

const roundUpThousand = (value: number) => Math.ceil(value / 1000) * 1000;

function fact(id: string, label: string, kind: FactKind, value: number, text?: string): Fact {
  return { id, label, kind, value, ...(text !== undefined ? { text } : {}) };
}

/** Facts about one goal, under the "goal:*" ids. Projections are rounded up to the thousand: estimates, not false precision. */
function goalFacts(progress: GoalProgress): Fact[] {
  const deadline = parseLocal(progress.goal.deadline);
  const list = [
    fact("goal:name", "Mục tiêu", "text", 0, progress.goal.name),
    fact("goal:percent", "Tiến độ", "percent", progress.percent / 100),
    fact("goal:saved", "Đã tiết kiệm", "money", progress.savedAmount),
    fact("goal:remaining", "Còn thiếu", "money", progress.remaining),
    fact("goal:required", "Cần mỗi tháng", "money", roundUpThousand(progress.requiredMonthly)),
    fact("goal:pace", "Nhịp hiện tại", "money", roundUpThousand(progress.pace)),
    fact("goal:gap", "Chênh lệch dự kiến", "money", roundUpThousand(Math.abs(progress.projectedGap))),
  ];
  if (deadline) list.push(fact("goal:deadline", "Hạn", "text", 0, formatNumericDate(deadline)));
  if (progress.estimatedCompletion) list.push(fact("goal:eta", "Dự kiến", "text", 0, formatMonthYear(progress.estimatedCompletion)));
  return list;
}

export function buildContext(summary: FinancialSummary, goals: GoalProgress[], isDemo: boolean): BrainContext {
  const list: Fact[] = [
    fact("balance", "Số dư", "money", summary.balance),
    fact("dailyAllowance", "Mỗi ngày", "money", summary.dailyAllowance),
    fact("safeToSpend", "Có thể chi", "money", summary.safeToSpend),
    fact("goalCommitment", "Dành cho mục tiêu", "money", summary.goalCommitmentRemaining),
    fact("daysLeft", "Ngày còn lại", "days", summary.daysLeftInMonth),
    fact("todayExpense", "Hôm nay", "money", summary.todayExpense),
    fact("monthExpense", "Đã chi tháng này", "money", summary.monthExpense),
    fact("monthIncome", "Thu tháng này", "money", summary.monthIncome),
    fact("last7Total", "7 ngày", "money", summary.last7Total),
    fact("prev7Total", "7 ngày trước", "money", summary.prev7Total),
    fact("weekDiff", "Chênh lệch tuần", "money", Math.abs(summary.last7Total - summary.prev7Total)),
  ];
  if (summary.weekChange !== null) {
    list.push(fact("weekChange", "So với tuần trước", "percent", Math.abs(summary.weekChange)));
    list.push(fact("weekTrend", "Xu hướng 7 ngày", "trend", summary.weekChange));
  }
  if (summary.spendingRatio !== null) list.push(fact("spendingRatio", "Tỷ lệ chi/thu", "percent", summary.spendingRatio));

  for (const category of summary.categories) {
    list.push(fact(`cat:${category.id}`, category.label, "money", category.amount));
    list.push(fact(`cat:${category.id}:share`, `${category.label} (tỷ trọng)`, "percent", category.share));
    list.push(fact(`cat:${category.id}:lastMonth`, `${category.label} tháng trước`, "money", category.lastMonthAmount));
    list.push(fact(`cat:${category.id}:name`, "Nhóm", "text", 0, category.label));
  }
  if (summary.topCategory) list.push(fact("topCategory", "Nhóm lớn nhất", "text", 0, summary.topCategory.label));

  const rising = summary.categories
    .map((category) => ({ category, diff: category.last7 - category.prev7 }))
    .filter((item) => item.diff > 0)
    .sort((a, b) => b.diff - a.diff)[0];
  if (rising) {
    list.push(fact("risingCategory", "Nhóm tăng", "text", 0, rising.category.label));
    list.push(fact("risingDiff", "Mức tăng", "money", rising.diff));
  }

  if (goals[0]) list.push(...goalFacts(goals[0]));

  return {
    facts: Object.fromEntries(list.map((item) => [item.id, item])),
    transactionCount: summary.transactionCount,
    hasSpending: summary.monthExpense > 0 || summary.last7Total > 0,
    isDemo,
  };
}

/* ------------------------------------------------------------------ */
/* Question parsing                                                     */
/* ------------------------------------------------------------------ */

export const normalize = (text: string) =>
  text
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/đ/g, "d")
    .replace(/\s+/g, " ")
    .trim();

/** Keywords are matched as whole words, so "xe" never matches "xem". */
const CATEGORY_KEYWORDS: Record<ExpenseCategoryId, string[]> = {
  food: ["an uong", "an", "an trua", "an sang", "an toi", "do an", "cafe", "ca phe", "tra sua", "com", "bun", "pho"],
  transport: ["di chuyen", "grab", "xang", "xe", "gui xe", "bus", "xe buyt"],
  study: ["hoc tap", "sach", "hoc phi", "tai lieu", "giao trinh"],
  entertainment: ["giai tri", "phim", "cgv", "karaoke", "game", "netflix"],
  shopping: ["mua sam", "shopee", "quan ao", "ao", "lazada"],
  other: ["khac"],
};

const hasWord = (haystack: string, phrase: string) => ` ${haystack} `.includes(` ${phrase} `);

const MILLION_UNIT = "(?:trieu|tr|cu|m)";
const THOUSAND_UNIT = "(?:nghin|ngan|ng|k)";
const NUMBER = "(\\d+(?:[.,]\\d+)?)";

/** "1,5" / "1.5" with a unit → 1.5. A dot/comma followed by exactly three digits is a thousands separator. */
function unitNumber(raw: string): number {
  if (/^\d{1,3}([.,]\d{3})+$/.test(raw)) return Number(raw.replace(/[.,]/g, ""));
  return Number(raw.replace(",", "."));
}

/**
 * Reads an amount of money from Vietnamese text, in đồng.
 *   300k · 300 nghìn · 300.000 · 1tr · 1 triệu · 1,5 triệu · 1.5tr · 1tr5 · 2tr2 · 2 triệu rưỡi · 500 ngàn
 * Returns undefined when there is no amount, rather than guessing.
 * Small bare numbers and numbers after "ngày/tháng/năm/tuần" are not treated as money.
 */
export function extractAmount(text: string): number | undefined {
  const q = normalize(text);

  // 1tr5 · 1tr 5 · 2tr2 · 2 trieu 2 → whole millions + the digits as a fraction of a million.
  // 1 trieu 50 nghin → whole millions + thousands.
  let match = new RegExp(
    `(?:^|[^\\d.,])(\\d+)\\s*${MILLION_UNIT}\\s*(\\d{1,3})(?![\\d.,])(\\s*${THOUSAND_UNIT}(?![a-z]))?`,
  ).exec(q);
  if (match) {
    const millions = Number(match[1]) * 1_000_000;
    return finite(match[3] ? millions + Number(match[2]) * 1_000 : millions + Number(`0.${match[2]}`) * 1_000_000);
  }

  // 1,5 trieu · 2 trieu ruoi · 3tr
  match = new RegExp(`${NUMBER}\\s*${MILLION_UNIT}(?![a-z])(\\s*ruoi)?`).exec(q);
  if (match) return finite((unitNumber(match[1]) + (match[2] ? 0.5 : 0)) * 1_000_000);

  // 300k · 500 nghin · 5 nghin ruoi
  match = new RegExp(`${NUMBER}\\s*${THOUSAND_UNIT}(?![a-z])(\\s*ruoi)?`).exec(q);
  if (match) return finite((unitNumber(match[1]) + (match[2] ? 0.5 : 0)) * 1_000);

  // Plain amounts: 300.000 · 450000 — at least ₫1.000, and not a date or a count.
  const plain = /(?:^|[^\d.,])(\d{1,3}(?:[.,]\d{3})+|\d{4,})(?![\d.,])/g;
  for (const candidate of q.matchAll(plain)) {
    const before = q.slice(0, candidate.index).trimEnd();
    if (/(ngay|thang|nam|tuan|lop)$/.test(before)) continue;
    const value = Number(candidate[1].replace(/[.,]/g, ""));
    if (value >= 1_000) return finite(value);
  }
  return undefined;
}

/** A usable amount of money, or undefined (zero, negative, non-finite or beyond exact integer range). */
function finite(value: number): number | undefined {
  if (!Number.isFinite(value) || value <= 0 || value > Number.MAX_SAFE_INTEGER) return undefined;
  return Math.round(value);
}

const AFFORD_WORDS = /\b(mua|duoc khong|co nen|du tien|du khong|co du|qua nhieu|dat khong|chi .*duoc|tieu .*duoc)\b/;
const GOAL_WORDS = /\b(muc tieu|tiet kiem|de danh|kip|bao lau|quy)\b/;
const ALLOWANCE_WORDS = /\b(tieu duoc|chi duoc|con bao nhieu|moi ngay|con lai|ngan sach|con tien)\b/;
const HIGHLIGHT_WORDS = /\b(chu y|the nao|tong quan|tuan|nhip|on khong|ra sao|tieu bao nhieu|chi bao nhieu)\b/;

/** Longest question accepted; longer input is cut, never sent anywhere in full. */
export const QUESTION_MAX_LENGTH = 160;

export function parseQuestion(text: string): ParsedQuestion {
  const question = text.trim().slice(0, QUESTION_MAX_LENGTH);
  const q = normalize(question);
  const amount = extractAmount(question);
  const categoryId = (Object.keys(CATEGORY_KEYWORDS) as ExpenseCategoryId[]).find((id) =>
    CATEGORY_KEYWORDS[id].some((keyword) => hasWord(q, keyword)),
  );

  if (!question) return { text: question, intent: "highlights" };
  if (amount && AFFORD_WORDS.test(q)) return { text: question, intent: "afford", amount };
  if (GOAL_WORDS.test(q)) return { text: question, intent: "goal" };
  if (ALLOWANCE_WORDS.test(q)) return { text: question, intent: "allowance" };
  if (categoryId && !(AFFORD_WORDS.test(q) && !hasWord(q, "mua sam"))) return { text: question, intent: "category", categoryId };
  if (HIGHLIGHT_WORDS.test(q)) return { text: question, intent: "highlights" };
  if (amount) return { text: question, intent: "afford", amount };
  if (AFFORD_WORDS.test(q)) return { text: question, intent: "afford" };
  return { text: question, intent: "unknown" };
}

/* ------------------------------------------------------------------ */
/* Local, deterministic composer                                        */
/* ------------------------------------------------------------------ */

type Draft = Omit<BrainAnswer, "question" | "intent" | "source">;

function highlights(ctx: BrainContext, summary: FinancialSummary): Draft {
  const { facts } = ctx;
  if (!ctx.hasSpending) {
    return {
      lead: "Chưa đủ dữ liệu để nhận ra nhịp chi tiêu.",
      detail: "Ghi vài khoản chi trong tuần này — Brain sẽ bắt đầu so sánh và chỉ ra điều đáng chú ý.",
      focus: ["balance"],
      facts: {},
    };
  }
  const focus = ["last7Total", "prev7Total"];
  let lead: string;
  let detail: string;
  const change = summary.weekChange;
  if (change === null) {
    lead = "Bạn vừa bắt đầu một nhịp mới.";
    detail = "7 ngày qua bạn đã chi {last7Total}. Chưa có tuần trước để so sánh.";
  } else if (change <= -0.05) {
    lead = "Bạn đang đi đúng nhịp.";
    detail = "7 ngày qua bạn chi {last7Total}, ít hơn {weekDiff} so với 7 ngày trước đó.";
  } else if (change >= 0.1) {
    lead = "Chi tiêu tuần này đang tăng.";
    detail = "7 ngày qua bạn chi {last7Total}, nhiều hơn {weekDiff} so với 7 ngày trước đó.";
  } else {
    lead = "Nhịp chi tiêu khá ổn định.";
    detail = "7 ngày qua bạn chi {last7Total}, gần bằng 7 ngày trước đó ({prev7Total}).";
  }
  if (facts.risingCategory && change !== null && change > -0.05) {
    detail += " {risingCategory} là nhóm tăng nhiều nhất, thêm {risingDiff}.";
    focus.push(`cat:${summary.categories.find((c) => c.label === facts.risingCategory.text)?.id ?? ""}`);
  } else if (facts.topCategory && summary.topCategory) {
    detail += " {topCategory} vẫn là nhóm lớn nhất tháng này với {cat:" + summary.topCategory.id + "}.";
    focus.push(`cat:${summary.topCategory.id}`);
  }
  return { lead, detail, stat: facts.weekTrend ? "weekTrend" : "last7Total", focus, facts: {} };
}

function allowance(summary: FinancialSummary): Draft {
  if (summary.balance <= 0) {
    return {
      lead: "Số dư hiện chưa đủ để chi thêm.",
      detail: "Số dư của bạn là {balance}. Ghi lại khoản thu tiếp theo để Brain tính lại nhịp chi tiêu.",
      stat: "balance",
      focus: ["balance"],
      facts: {},
    };
  }
  if (summary.safeToSpend <= 0) {
    return {
      lead: "Phần còn lại đã dành cho mục tiêu.",
      detail: "Số dư {balance} đang được giữ cho kế hoạch tiết kiệm tháng này ({goalCommitment}). Chi thêm sẽ làm chậm mục tiêu.",
      stat: "goalCommitment",
      focus: ["balance", "goalCommitment"],
      facts: {},
    };
  }
  const reserve = summary.goalCommitmentRemaining > 0;
  return {
    lead: "Khoảng {dailyAllowance} mỗi ngày.",
    detail: reserve
      ? "Từ số dư {balance}, Brain giữ lại {goalCommitment} cho mục tiêu tháng này, phần còn lại chia đều cho {daysLeft} đến hết tháng."
      : "Số dư {balance} chia đều cho {daysLeft} còn lại của tháng.",
    stat: "dailyAllowance",
    focus: reserve ? ["balance", "goalCommitment", "dailyAllowance"] : ["balance", "dailyAllowance"],
    facts: {},
  };
}

function afford(summary: FinancialSummary, amount: number | undefined): Draft {
  if (amount === undefined) {
    if (summary.balance <= 0) return allowance(summary);
    return {
      lead: "Bạn định chi bao nhiêu?",
      detail:
        "Hiện bạn có thể chi khoảng {safeToSpend} đến hết tháng mà không chạm vào tiền dành cho mục tiêu. Hỏi kèm số tiền, ví dụ “mua 300k được không?”.",
      stat: "safeToSpend",
      focus: ["balance", "safeToSpend"],
      facts: {},
    };
  }
  const sim = simulatePurchase(summary, amount);
  const facts: FactMap = {
    purchase: fact("purchase", "Khoản dự định", "money", amount),
    balanceAfter: fact("balanceAfter", "Số dư sau đó", "money", sim.balanceAfter),
    dailyAfter: fact("dailyAfter", "Mỗi ngày sau đó", "money", sim.dailyAfter),
  };
  const focus = ["balance", "dailyAllowance", "purchase"];
  if (sim.exceedsBalance) {
    return {
      lead: "Chưa nên — số dư không đủ.",
      detail: "Khoản {purchase} lớn hơn số dư hiện có ({balance}).",
      stat: "purchase",
      focus,
      facts,
    };
  }
  if (sim.touchesGoals) {
    return {
      lead: "Được, nhưng sẽ chạm vào tiền mục tiêu.",
      detail: "Sau khoản {purchase}, số dư còn {balanceAfter} — thấp hơn phần đang giữ cho mục tiêu tháng này ({goalCommitment}).",
      stat: "purchase",
      focus: [...focus, "goalCommitment"],
      facts,
    };
  }
  const tight = sim.dailyAfter < summary.dailyAllowance * 0.75;
  return {
    lead: tight ? "Có thể, nhưng nên cân nhắc." : "Được, vẫn trong nhịp.",
    detail: tight
      ? "Nếu chi {purchase} hôm nay, mức chi gợi ý giảm từ {dailyAllowance} xuống {dailyAfter} mỗi ngày cho {daysLeft} còn lại."
      : "Sau khoản {purchase}, bạn vẫn còn khoảng {dailyAfter} mỗi ngày cho {daysLeft} còn lại.",
    stat: "purchase",
    focus,
    facts,
  };
}

function goalAnswer(goals: GoalProgress[], question: string): Draft {
  // A goal named in the question ("quỹ dự phòng còn bao lâu?") wins over the primary goal.
  const q = normalize(question);
  const named = goals.find((item) => {
    const name = normalize(item.goal.name);
    return name.length > 1 && hasWord(q, name);
  });
  const primary = named ?? goals[0];
  const facts: FactMap = primary && named && named !== goals[0] ? Object.fromEntries(goalFacts(primary).map((item) => [item.id, item])) : {};
  if (!primary) {
    return {
      lead: "Bạn chưa đặt mục tiêu nào.",
      detail: "Tạo một mục tiêu trong tab Mục tiêu — Brain sẽ tính số cần để dành mỗi tháng và ngày dự kiến hoàn thành.",
      focus: ["balance"],
      facts: {},
    };
  }
  const focus = ["goal:percent", "goal:remaining", "goal:pace"];
  const withFacts = (draft: Draft): Draft => ({ ...draft, facts });
  if (primary.isComplete) {
    return withFacts({ lead: "{goal:name} đã hoàn thành.", detail: "Bạn đã tiết kiệm đủ {goal:saved}.", stat: "goal:percent", focus, facts: {} });
  }
  if (primary.isOverdue) {
    return withFacts({
      lead: "{goal:name} đã quá hạn.",
      detail: "Còn thiếu {goal:remaining}. Hãy chọn hạn mới để Brain tính lại nhịp tiết kiệm.",
      stat: "goal:percent",
      focus,
      facts: {},
    });
  }
  if (primary.paceSource === "none") {
    return withFacts({
      lead: "Chưa có nhịp tiết kiệm cho {goal:name}.",
      detail: "Còn thiếu {goal:remaining}. Để kịp hạn {goal:deadline}, bạn cần khoảng {goal:required} mỗi tháng.",
      stat: "goal:percent",
      focus: [...focus, "goal:required"],
      facts: {},
    });
  }
  return withFacts(
    primary.onTrack
      ? {
        lead: "Bạn đang kịp tiến độ.",
        detail:
          "Với {goal:pace} mỗi tháng, {goal:name} dự kiến hoàn thành vào {goal:eta}, trước hạn {goal:deadline}. Bạn đã đi được {goal:percent}.",
        stat: "goal:percent",
        focus,
        facts: {},
      }
    : {
        lead: "Nhịp hiện tại chưa đủ để kịp hạn.",
        detail:
          "Với {goal:pace} mỗi tháng, đến hạn {goal:deadline} bạn sẽ còn thiếu khoảng {goal:gap}. Cần khoảng {goal:required} mỗi tháng để kịp.",
        stat: "goal:percent",
        focus: [...focus, "goal:required"],
        facts: {},
      },
  );
}

function categoryAnswer(summary: FinancialSummary, id: ExpenseCategoryId): Draft {
  const category = summary.categories.find((item) => item.id === id);
  const key = `cat:${id}`;
  if (!category || category.amount === 0) {
    return {
      lead: `Chưa có khoản ${EXPENSE_CATEGORIES.find((c) => c.id === id)?.label.toLowerCase()} nào tháng này.`,
      detail: "Khi bạn ghi lại, Brain sẽ so sánh với tháng trước và tỷ trọng trong tổng chi tiêu.",
      focus: [key],
      facts: {},
    };
  }
  const trend =
    category.lastMonthAmount > 0
      ? category.amount > category.lastMonthAmount
        ? " Đã vượt cả tháng trước ({" + key + ":lastMonth})."
        : " Tháng trước nhóm này là {" + key + ":lastMonth}."
      : "";
  return {
    lead: "{" + key + ":name} tháng này: {" + key + "}.",
    detail: "Chiếm {" + key + ":share} tổng chi tiêu tháng này." + trend,
    stat: `${key}:share`,
    focus: [key, "monthExpense"],
    facts: {},
  };
}

export function answerLocally(
  parsed: ParsedQuestion,
  ctx: BrainContext,
  summary: FinancialSummary,
  goals: GoalProgress[],
): BrainAnswer {
  let draft: Draft;
  switch (parsed.intent) {
    case "allowance":
      draft = allowance(summary);
      break;
    case "afford":
      draft = afford(summary, parsed.amount);
      break;
    case "goal":
      draft = goalAnswer(goals, parsed.text);
      break;
    case "category":
      draft = categoryAnswer(summary, parsed.categoryId ?? "food");
      break;
    case "unknown":
      draft = {
        lead: "Brain chưa hiểu câu hỏi này.",
        detail: "Thử hỏi về số tiền còn tiêu được, một khoản định mua (ví dụ “mua 300k được không?”), một nhóm chi tiêu hoặc mục tiêu của bạn.",
        focus: [],
        facts: {},
      };
      break;
    default:
      draft = highlights(ctx, summary);
  }
  return { ...draft, focus: draft.focus.filter((id) => id in ctx.facts || id in draft.facts), question: parsed.text, intent: parsed.intent, source: "local" };
}

/* ------------------------------------------------------------------ */
/* Optional remote language layer                                       */
/* ------------------------------------------------------------------ */

/**
 * Only an https URL or a same-origin path is accepted: an http endpoint would send
 * financial facts in clear text. Anything else leaves Brain fully local.
 */
export function readEndpoint(value: unknown): string | undefined {
  if (typeof value !== "string") return undefined;
  const trimmed = value.trim();
  return /^https:\/\/[^\s]+$/.test(trimmed) || /^\/[^\s/][^\s]*$/.test(trimmed) ? trimmed : undefined;
}

// `?.` keeps the module usable outside Vite (unit tests), where import.meta.env is absent.
const ENDPOINT = readEndpoint(import.meta.env?.VITE_BRAIN_ENDPOINT);
const REMOTE_TIMEOUT_MS = 9000;
const MAX_RESPONSE_CHARS = 16_000;
/** Client-side brake on remote calls (the server must still rate-limit on its own). */
const REMOTE_LIMIT = { calls: 8, windowMs: 60_000 };

export const isRemoteBrainConfigured = Boolean(ENDPOINT);

export interface RemoteOptions {
  endpoint?: string;
  fetchImpl?: typeof fetch;
  timeoutMs?: number;
  /** Timestamps of recent remote calls, shared across questions. */
  recentCalls?: number[];
  now?: () => number;
}

const sharedRecentCalls: number[] = [];

/** A remote answer is accepted only if every number in it is a fact reference. */
export function isSafeRemoteText(text: unknown, allowed: FactMap): text is string {
  if (typeof text !== "string" || !text.trim() || text.length > 420) return false;
  const tokens = [...text.matchAll(/\{([\w:.-]+)\}/g)].map((match) => match[1]);
  if (tokens.some((token) => !(token in allowed))) return false;
  const free = text.replace(/\{[\w:.-]+\}/g, "");
  // Any numeric character in any script (¹⁰⁰, １００, ٣, Ⅻ…), not just ASCII digits.
  if (/\p{N}/u.test(free)) return false;
  // Amounts spelled out ("một trăm triệu", "two million"). Rejecting sends the user to the
  // deterministic local answer, so a false positive costs only wording, never accuracy.
  return !SPELLED_MAGNITUDE.test(` ${normalize(free).replace(/[^a-z\s]/g, " ")} `);
}

const SPELLED_MAGNITUDE = / (tram|chuc|muoi|nghin|ngan|trieu|ty|ti|phan tram|hundred|thousand|million|billion|percent|k|tr) /;

/**
 * Asks Brain. Without a configured endpoint this is fully local and offline.
 * With one, only the facts the answer needs are sent (no notes, no transaction list),
 * and any failure falls back to the deterministic answer.
 */
export async function askBrain(
  parsed: ParsedQuestion,
  ctx: BrainContext,
  summary: FinancialSummary,
  goals: GoalProgress[],
  signal?: AbortSignal,
  options: RemoteOptions = {},
): Promise<BrainAnswer> {
  const local = answerLocally(parsed, ctx, summary, goals);
  const endpoint = options.endpoint === undefined ? ENDPOINT : readEndpoint(options.endpoint);
  const fetchImpl = options.fetchImpl ?? globalThis.fetch;
  if (!endpoint || !fetchImpl || parsed.intent === "unknown") return local;

  // Rapid tapping can't turn into a flood of requests: past the limit, answer locally.
  const clock = options.now ?? Date.now;
  const recent = options.recentCalls ?? sharedRecentCalls;
  const windowStart = clock() - REMOTE_LIMIT.windowMs;
  while (recent.length && recent[0] < windowStart) recent.shift();
  if (recent.length >= REMOTE_LIMIT.calls) return local;
  recent.push(clock());

  // Only the facts this answer needs; question-specific facts win over general ones.
  const shared: FactMap = {};
  for (const id of new Set([...local.focus, "balance", "dailyAllowance", "daysLeft"])) {
    if (ctx.facts[id]) shared[id] = ctx.facts[id];
  }
  Object.assign(shared, local.facts);

  if (signal?.aborted) throw new DOMException("aborted", "AbortError");
  const controller = new AbortController();
  const timer = globalThis.setTimeout(() => controller.abort(), options.timeoutMs ?? REMOTE_TIMEOUT_MS);
  const forwardAbort = () => controller.abort();
  signal?.addEventListener("abort", forwardAbort, { once: true });
  try {
    const response = await fetchImpl(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ question: parsed.text, intent: parsed.intent, facts: Object.values(shared), locale: "vi-VN" }),
      signal: controller.signal,
    });
    if (!response.ok) throw new Error("Brain endpoint error");
    const raw = await response.text();
    if (raw.length > MAX_RESPONSE_CHARS) throw new Error("Brain response too large");
    const body: unknown = JSON.parse(raw);
    const lead = (body as { lead?: unknown })?.lead;
    const detail = (body as { detail?: unknown })?.detail;
    if (isSafeRemoteText(lead, shared) && isSafeRemoteText(detail, shared)) {
      return { ...local, lead, detail, source: "remote" };
    }
    return { ...local, notice: "Câu trả lời trực tuyến chứa số liệu không kiểm chứng được — Brain dùng phân tích cục bộ." };
  } catch {
    if (signal?.aborted) throw new DOMException("aborted", "AbortError");
    return { ...local, notice: "Không kết nối được Brain trực tuyến — đang dùng phân tích cục bộ trên máy bạn." };
  } finally {
    globalThis.clearTimeout(timer);
    signal?.removeEventListener("abort", forwardAbort);
  }
}

export const SUGGESTED_QUESTIONS = [
  "Có gì đáng chú ý?",
  "Còn tiêu được bao nhiêu?",
  "Mua 300k được không?",
  "Mục tiêu có kịp không?",
];
