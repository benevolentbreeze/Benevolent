import { getCategory, isExpenseCategory } from "../data/categories";
import type { Goal } from "../types/goal";
import type { Transaction, TransactionDraft } from "../types/transaction";
import { isAfterToday, parseLocal, toLocalDateTime } from "../utils/date";
import { createId } from "../utils/id";
import { MAX_AMOUNT } from "../utils/money";
import { NOTE_MAX_LENGTH } from "./validation";

export { NOTE_MAX_LENGTH };

export type DraftErrors = Partial<Record<"amount" | "category" | "date", string>>;

export interface DraftLimits {
  /** Money that can be moved into a goal (balance, plus the amount being edited). */
  available?: number;
  /** What the goal still needs (plus the amount being edited). */
  goalRemaining?: number;
}

export function validateDraft(draft: TransactionDraft, now: Date, limits: DraftLimits = {}): DraftErrors {
  const errors: DraftErrors = {};
  if (!Number.isInteger(draft.amount) || draft.amount <= 0) errors.amount = "Nhập số tiền lớn hơn ₫0";
  else if (draft.amount > MAX_AMOUNT) errors.amount = "Số tiền vượt quá giới hạn ₫1.000.000.000";
  else if (limits.available !== undefined && draft.amount > limits.available) {
    errors.amount = "Số dư hiện tại không đủ cho khoản này";
  } else if (limits.goalRemaining !== undefined && draft.amount > limits.goalRemaining) {
    errors.amount = "Số này vượt phần còn thiếu của mục tiêu";
  }
  if (draft.type === "saving" && !draft.goalId) errors.amount = errors.amount ?? "Khoản tiết kiệm cần gắn với một mục tiêu";

  if (draft.type === "expense" && !isExpenseCategory(draft.category)) errors.category = "Chọn một nhóm chi tiêu";

  const date = parseLocal(draft.date);
  if (!date) errors.date = "Ngày không hợp lệ";
  else if (isAfterToday(date, now)) errors.date = "Không thể ghi cho ngày trong tương lai";
  return errors;
}

export function hasErrors(errors: object): boolean {
  return Object.keys(errors).length > 0;
}

/** Builds a transaction from a validated draft. The note is kept exactly as typed (only outer whitespace trimmed). */
export function buildTransaction(draft: TransactionDraft, existing?: Transaction): Transaction {
  const category = draft.type === "income" ? "income" : draft.type === "saving" ? "saving" : draft.category ?? "other";
  return {
    id: existing?.id ?? createId("tx"),
    createdAt: existing?.createdAt ?? new Date().toISOString(),
    amount: Math.round(draft.amount),
    type: draft.type,
    category,
    note: draft.note.trim().slice(0, NOTE_MAX_LENGTH),
    date: draft.date,
    ...(draft.type === "saving" && draft.goalId ? { goalId: draft.goalId } : {}),
    // An opening entry stays an opening entry as long as its type doesn't change.
    ...(existing?.opening && existing.type === draft.type ? { opening: true as const } : {}),
  };
}

/** Newest first; ties broken by creation time. */
export function sortTransactions(transactions: Transaction[]): Transaction[] {
  return [...transactions].sort((a, b) => {
    if (a.date !== b.date) return a.date < b.date ? 1 : -1;
    return a.createdAt < b.createdAt ? 1 : a.createdAt > b.createdAt ? -1 : 0;
  });
}

/** Combines a chosen day with the current time (or keeps the original time when editing). */
export function combineDayAndTime(dayKey: string, timeSource: Date | string): string {
  const time = typeof timeSource === "string" ? timeSource.slice(11, 16) : toLocalDateTime(timeSource).slice(11, 16);
  return `${dayKey}T${time || "12:00"}`;
}

export function describeTransaction(tx: Transaction, goals: Goal[]): { title: string; subtitle: string } {
  const category = getCategory(tx.category);
  if (tx.type === "saving") {
    const goal = goals.find((item) => item.id === tx.goalId);
    const kind = tx.opening ? "Đã tiết kiệm" : "Tiết kiệm";
    return { title: tx.note || `Góp vào ${goal?.name ?? "mục tiêu"}`, subtitle: tx.note && goal ? `${kind} · ${goal.name}` : kind };
  }
  if (tx.type === "income" && tx.opening) return { title: tx.note || "Số dư ban đầu", subtitle: "Số dư ban đầu" };
  return { title: tx.note || category.label, subtitle: tx.note ? category.label : tx.type === "income" ? "Khoản thu" : "" };
}

/**
 * RFC 4180 cell. Text that a spreadsheet would treat as a formula (= + - @, tab, CR)
 * is prefixed with an apostrophe so an exported note can never execute (CSV injection).
 * Numbers are written as plain integers.
 */
function csvCell(value: string | number): string {
  if (typeof value === "number") return Number.isFinite(value) ? String(Math.round(value)) : "";
  const text = /^[=+\-@\t\r]/.test(value) ? `'${value}` : value;
  return /[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

const TYPE_LABEL: Record<Transaction["type"], string> = { expense: "Chi", income: "Thu", saving: "Tiết kiệm" };

export function transactionsToCsv(transactions: Transaction[], goals: Goal[]): string {
  const header = ["Ngày", "Giờ", "Loại", "Nhóm", "Mục tiêu", "Ghi chú", "Số tiền (VND)"];
  const goalNames = new Map(goals.map((goal) => [goal.id, goal.name]));
  const rows = sortTransactions(transactions).map((tx) => {
    const signed = tx.type === "income" ? tx.amount : -tx.amount;
    const goalName = tx.goalId ? goalNames.get(tx.goalId) ?? "" : "";
    return [tx.date.slice(0, 10), tx.date.slice(11, 16), TYPE_LABEL[tx.type], getCategory(tx.category).label, goalName, tx.note, signed];
  });
  // BOM + CRLF so Excel opens Vietnamese text and line breaks correctly.
  return "\uFEFF" + [header, ...rows].map((row) => row.map(csvCell).join(",")).join("\r\n");
}
