/**
 * The financial engine: the single place where numbers are calculated.
 * Every figure the UI shows (and every fact Brain explains) comes from here.
 */
import { EXPENSE_CATEGORIES, isExpenseCategory } from "../data/categories";
import type { ExpenseCategoryId } from "../types/category";
import type { CategorySpend, DailyPoint, FinancialSummary } from "../types/financialSummary";
import type { GoalProgress } from "../types/goal";
import type { WorkspaceData } from "../types/state";
import {
  addDays,
  addMonths,
  daysInMonth,
  startOfDay,
  startOfMonth,
  toDateKey,
  toMonthKey,
} from "../utils/date";
import { computeGoalProgress } from "./goalService";

function dailySeries(start: Date, length: number): DailyPoint[] {
  return Array.from({ length }, (_, index) => {
    const date = addDays(start, index);
    return { key: toDateKey(date), date, expense: 0, income: 0 };
  });
}

export function computeAllGoalProgress(data: WorkspaceData, now: Date): GoalProgress[] {
  return data.goals.map((goal) => computeGoalProgress(goal, data.transactions, now));
}

export function computeSummary(data: WorkspaceData, now: Date, goals: GoalProgress[]): FinancialSummary {
  const today = startOfDay(now);
  const todayKey = toDateKey(today);
  const monthKey = toMonthKey(today);
  const lastMonthKey = toMonthKey(addMonths(startOfMonth(today), -1));

  const last14 = dailySeries(addDays(today, -13), 14);
  const byDay = new Map(last14.map((point) => [point.key, point]));
  const monthDays = dailySeries(startOfMonth(today), today.getDate());
  const monthByDay = new Map(monthDays.map((point) => [point.key, point]));

  const categoryMap = new Map<ExpenseCategoryId, CategorySpend>(
    EXPENSE_CATEGORIES.map((category) => [
      category.id,
      { id: category.id, label: category.label, amount: 0, share: 0, count: 0, lastMonthAmount: 0, last7: 0, prev7: 0 },
    ]),
  );
  const last7Start = last14[7].key;
  const last7Index = new Map(last14.slice(7).map((point, index) => [point.key, index]));
  const categoryLast7 = Object.fromEntries(EXPENSE_CATEGORIES.map((c) => [c.id, [0, 0, 0, 0, 0, 0, 0]])) as Record<ExpenseCategoryId, number[]>;

  let totalIncome = 0;
  let totalExpense = 0;
  let totalSaved = 0;
  let todayExpense = 0;
  let todayCount = 0;
  let monthIncome = 0;
  let monthExpense = 0;
  let monthSaved = 0;
  let monthCount = 0;

  for (const tx of data.transactions) {
    const dayKey = tx.date.slice(0, 10);
    const txMonth = tx.date.slice(0, 7);
    const inMonth = txMonth === monthKey;
    if (inMonth && !tx.opening) monthCount += 1;

    if (tx.type === "income") {
      totalIncome += tx.amount;
      // Opening balances are money the user already had, not income: balance only.
      if (tx.opening) continue;
      if (inMonth) monthIncome += tx.amount;
      const point = byDay.get(dayKey);
      if (point) point.income += tx.amount;
      const monthPoint = monthByDay.get(dayKey);
      if (monthPoint) monthPoint.income += tx.amount;
      continue;
    }

    if (tx.type === "saving") {
      totalSaved += tx.amount;
      if (inMonth) monthSaved += tx.amount;
      continue;
    }

    totalExpense += tx.amount;
    if (dayKey === todayKey) {
      todayExpense += tx.amount;
      todayCount += 1;
    }
    if (inMonth) monthExpense += tx.amount;
    const point = byDay.get(dayKey);
    if (point) point.expense += tx.amount;
    const monthPoint = monthByDay.get(dayKey);
    if (monthPoint) monthPoint.expense += tx.amount;

    if (!isExpenseCategory(tx.category)) continue;
    const category = categoryMap.get(tx.category);
    if (!category) continue;
    if (inMonth) {
      category.amount += tx.amount;
      category.count += 1;
    } else if (txMonth === lastMonthKey) {
      category.lastMonthAmount += tx.amount;
    }
    if (point) {
      if (dayKey >= last7Start) {
        category.last7 += tx.amount;
        categoryLast7[tx.category][last7Index.get(dayKey) ?? 0] += tx.amount;
      } else {
        category.prev7 += tx.amount;
      }
    }
  }

  const categories = [...categoryMap.values()]
    .map((category) => ({ ...category, share: monthExpense > 0 ? category.amount / monthExpense : 0 }))
    .sort((a, b) => b.amount - a.amount);

  const last7 = last14.slice(7);
  const last7Total = last7.reduce((sum, point) => sum + point.expense, 0);
  const prev7Total = last14.slice(0, 7).reduce((sum, point) => sum + point.expense, 0);

  // Integer đồng throughout; the engine never stores a balance, it always re-derives it.
  const balance = totalIncome - totalExpense - totalSaved;
  const daysLeftInMonth = daysInMonth(today) - today.getDate() + 1;
  const goalCommitmentRemaining = goals.reduce((sum, goal) => sum + goal.commitmentRemainingThisMonth, 0);
  const safeToSpend = Math.max(0, balance - goalCommitmentRemaining);

  return {
    now,
    // Opening entries are bookkeeping, not activity the user recorded.
    transactionCount: data.transactions.reduce((count, tx) => count + (tx.opening ? 0 : 1), 0),
    balance,
    totalIncome,
    totalExpense,
    totalSaved,
    todayExpense,
    todayCount,
    monthIncome,
    monthExpense,
    monthSaved,
    monthCount,
    spendingRatio: monthIncome > 0 ? monthExpense / monthIncome : null,
    savingsRate: monthIncome > 0 ? (monthIncome - monthExpense) / monthIncome : null,
    daysLeftInMonth,
    goalCommitmentRemaining,
    safeToSpend,
    dailyAllowance: Math.floor(safeToSpend / daysLeftInMonth / 1000) * 1000,
    last7,
    last7Total,
    prev7Total,
    weekChange: prev7Total > 0 ? (last7Total - prev7Total) / prev7Total : null,
    categoryLast7,
    monthDays,
    categories,
    topCategory: categories[0] && categories[0].amount > 0 ? categories[0] : null,
  };
}

/** What a purchase would do to the user's month — used by Brain, never guessed by it. */
export function simulatePurchase(summary: FinancialSummary, amount: number) {
  const safeAfter = summary.safeToSpend - amount;
  return {
    amount,
    balanceAfter: summary.balance - amount,
    safeAfter,
    dailyAfter: Math.max(0, Math.floor(safeAfter / summary.daysLeftInMonth / 1000) * 1000),
    exceedsBalance: amount > summary.balance,
    touchesGoals: amount > summary.safeToSpend && amount <= summary.balance,
  };
}

export interface MonthSummary {
  expense: number;
  income: number;
  saved: number;
  days: DailyPoint[];
}

/** Totals for any calendar month (History). Same rules as computeSummary. */
export function computeMonth(data: WorkspaceData, month: Date, now: Date): MonthSummary {
  const start = startOfMonth(month);
  const isCurrent = toMonthKey(start) === toMonthKey(now);
  const length = isCurrent ? now.getDate() : daysInMonth(start);
  const days = dailySeries(start, length);
  const byDay = new Map(days.map((point) => [point.key, point]));
  const key = toMonthKey(start);
  let expense = 0;
  let income = 0;
  let saved = 0;
  for (const tx of data.transactions) {
    if (!tx.date.startsWith(key)) continue;
    const point = byDay.get(tx.date.slice(0, 10));
    if (tx.type === "expense") {
      expense += tx.amount;
      if (point) point.expense += tx.amount;
    } else if (tx.type === "income") {
      if (tx.opening) continue;
      income += tx.amount;
      if (point) point.income += tx.amount;
    } else {
      saved += tx.amount;
    }
  }
  return { expense, income, saved, days };
}
