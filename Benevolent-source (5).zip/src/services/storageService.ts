/**
 * Persistence behind a small async adapter interface. Today it is localStorage;
 * a Supabase (or any remote) adapter can implement the same interface later
 * without touching the UI.
 *
 * Everything read back — from storage or from a backup file — goes through the same
 * validator: it normalises what it can, drops what it can't trust, counts what it
 * dropped, and never lets an invalid record into the app.
 */
import { createEmptyWorkspace } from "../data/demoSeed";
import type { Goal } from "../types/goal";
import { STATE_VERSION, type PersistedState, type WorkspaceData } from "../types/state";
import type { Transaction } from "../types/transaction";
import { toLocalDateTime } from "../utils/date";
import { sortTransactions } from "./transactionService";
import {
  DEFAULT_SETTINGS,
  MAX_ID_LENGTH,
  MAX_RECORDS,
  isAmount,
  isRecord,
  readGoal,
  readSettings,
  readTransaction,
  workspaceIsConsistent,
} from "./validation";

export type LoadResult =
  | { status: "empty" }
  | { status: "ok"; state: PersistedState; dropped: number }
  | { status: "corrupted"; preservedKey: string | null }
  | { status: "unavailable" };

export interface StorageAdapter {
  load(): Promise<LoadResult>;
  save(state: PersistedState): Promise<void>;
  /** Notifies when another tab/device changed the stored state. Returns an unsubscribe function. */
  subscribe?(listener: (state: PersistedState) => void): () => void;
}

const STATE_KEY = "benevolent:state:v1";
/** Hard ceiling so a hostile or broken file can't exhaust memory. */
export const MAX_BACKUP_BYTES = 5 * 1024 * 1024;

export { DEFAULT_SETTINGS } from "./validation";

export function createDefaultState(): PersistedState {
  return {
    version: STATE_VERSION,
    activeWorkspace: "demo",
    workspaces: { demo: null, personal: createEmptyWorkspace() },
    settings: { ...DEFAULT_SETTINGS },
  };
}

/* ------------------------------------------------------------------ */
/* Validation (record readers live in ./validation)                     */
/* ------------------------------------------------------------------ */

/** Keeps the first record for each id; later duplicates are dropped. */
function uniqueById<T extends { id: string }>(items: T[]): T[] {
  const seen = new Set<string>();
  return items.filter((item) => (seen.has(item.id) ? false : (seen.add(item.id), true)));
}

/**
 * Version 1 stored money that was "already saved" on the goal itself (startingAmount),
 * outside the balance. Version 2 records it as an opening balance moved into the goal,
 * which leaves the visible balance and goal progress exactly as they were.
 */
function migrateV1Goal(raw: Record<string, unknown>, goal: Goal, taken: Set<string>): Transaction[] {
  const starting = raw.startingAmount;
  if (!isAmount(starting)) return [];
  // Ids must be valid and unused, or the pair would be half-dropped (now or on the next load).
  const stem = goal.id.slice(0, MAX_ID_LENGTH - 12);
  const freeId = (suffix: string) => {
    let id = `${stem}_${suffix}`;
    for (let n = 2; taken.has(id); n += 1) id = `${stem}_${suffix}${n}`;
    return id;
  };
  const base = { amount: starting, note: "", date: toLocalDateTime(new Date(goal.createdAt)), createdAt: goal.createdAt, opening: true };
  const income = readTransaction({ ...base, id: freeId("open_in"), type: "income", category: "income" });
  const saving = income && readTransaction({ ...base, id: freeId("open"), type: "saving", category: "saving", goalId: goal.id });
  // All or nothing: an income half without its saving half would add money to the balance.
  if (!income || !saving || income.id === saving.id) return [];
  taken.add(income.id);
  taken.add(saving.id);
  return [income, saving];
}

function readWorkspace(value: unknown, version: number): { data: WorkspaceData; dropped: number } | null {
  if (!isRecord(value) || !Array.isArray(value.transactions) || !Array.isArray(value.goals)) return null;
  if (value.transactions.length > MAX_RECORDS || value.goals.length > MAX_RECORDS) return null;

  const rawGoals = value.goals;
  const goals = uniqueById(rawGoals.map(readGoal).filter((goal): goal is Goal => goal !== null));
  const goalIds = new Set(goals.map((goal) => goal.id));

  const parsed = value.transactions.map(readTransaction);
  const valid = uniqueById(parsed.filter((tx): tx is Transaction => tx !== null));
  // A saving that points at a goal that no longer exists would silently remove money: drop it.
  const linked = valid.filter((tx) => tx.type !== "saving" || goalIds.has(tx.goalId ?? ""));
  // At most one opening entry per goal.
  const openings = new Set<string>();
  const consistent = linked.filter((tx) => {
    if (tx.type !== "saving" || !tx.opening) return true;
    if (openings.has(tx.goalId ?? "")) return false;
    openings.add(tx.goalId ?? "");
    return true;
  });

  // v1 → v2. Each goal is migrated once (first record wins, like every duplicate), and never
  // when it already has an opening entry (a file that was partly migrated before).
  const migrated: Transaction[] = [];
  if (version === 1) {
    const taken = new Set(consistent.map((tx) => tx.id));
    const seen = new Set<string>();
    for (const raw of rawGoals) {
      if (!isRecord(raw) || typeof raw.id !== "string" || seen.has(raw.id) || !goalIds.has(raw.id) || openings.has(raw.id)) continue;
      seen.add(raw.id);
      const goal = goals.find((item) => item.id === raw.id);
      if (goal) migrated.push(...migrateV1Goal(raw, goal, taken));
    }
  }

  const data = { transactions: sortTransactions([...consistent, ...migrated]), goals };
  // Belt and braces: storage must never hand the app a state the domain calls impossible.
  if (!workspaceIsConsistent(data)) return null;
  const dropped = value.transactions.length - consistent.length + (value.goals.length - goals.length);
  return { data, dropped: Math.max(0, dropped) };
}

export type ReadResult =
  | { ok: true; state: PersistedState; dropped: number }
  | { ok: false; reason: "invalid" | "newer-version" };

export function readPersistedState(value: unknown): ReadResult {
  if (!isRecord(value) || typeof value.version !== "number") return { ok: false, reason: "invalid" };
  if (value.version > STATE_VERSION) return { ok: false, reason: "newer-version" };
  if (value.version < 1 || !Number.isInteger(value.version) || !isRecord(value.workspaces)) return { ok: false, reason: "invalid" };
  const personal = readWorkspace(value.workspaces.personal, value.version);
  if (!personal) return { ok: false, reason: "invalid" };
  const demo = value.workspaces.demo === null || value.workspaces.demo === undefined ? null : readWorkspace(value.workspaces.demo, value.version);
  return {
    ok: true,
    state: {
      version: STATE_VERSION,
      activeWorkspace: value.activeWorkspace === "personal" ? "personal" : "demo",
      workspaces: { personal: personal.data, demo: demo?.data ?? null },
      settings: readSettings(value.settings),
    },
    dropped: personal.dropped + (demo?.dropped ?? 0),
  };
}

/** Parses a JSON string into state. Never throws. */
export function parseStoredState(raw: string): ReadResult {
  if (raw.length > MAX_BACKUP_BYTES * 2) return { ok: false, reason: "invalid" };
  try {
    return readPersistedState(JSON.parse(raw));
  } catch {
    return { ok: false, reason: "invalid" };
  }
}

/* ------------------------------------------------------------------ */
/* localStorage adapter                                                 */
/* ------------------------------------------------------------------ */

export const localStorageAdapter: StorageAdapter = {
  async load() {
    let raw: string | null;
    try {
      raw = window.localStorage.getItem(STATE_KEY);
    } catch {
      return { status: "unavailable" };
    }
    if (raw === null) return { status: "empty" };

    const result = parseStoredState(raw);
    if (result.ok) return { status: "ok", state: result.state, dropped: result.dropped };

    // Keep the unreadable copy (or one written by a newer version) instead of destroying it.
    const preservedKey = `benevolent:${result.reason === "newer-version" ? "newer" : "corrupted"}:${Date.now()}`;
    try {
      window.localStorage.setItem(preservedKey, raw);
      window.localStorage.removeItem(STATE_KEY);
      return { status: "corrupted", preservedKey };
    } catch {
      return { status: "corrupted", preservedKey: null };
    }
  },
  async save(state) {
    window.localStorage.setItem(STATE_KEY, JSON.stringify(state));
  },
  subscribe(listener) {
    const onStorage = (event: StorageEvent) => {
      if (event.key !== STATE_KEY || event.newValue === null) return;
      const result = parseStoredState(event.newValue);
      if (result.ok) listener(result.state);
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  },
};

/* ------------------------------------------------------------------ */
/* Backup files                                                         */
/* ------------------------------------------------------------------ */

export function serializeBackup(state: PersistedState): string {
  return JSON.stringify({ app: "benevolent", kind: "backup", exportedAt: new Date().toISOString(), state }, null, 2);
}

export function parseBackup(text: string): { ok: true; state: PersistedState; dropped: number } | { ok: false; reason: string } {
  if (text.length > MAX_BACKUP_BYTES) return { ok: false, reason: "Tệp quá lớn để là bản sao lưu của Benevolent." };
  let parsed: unknown;
  try {
    parsed = JSON.parse(text);
  } catch {
    return { ok: false, reason: "Tệp không phải bản sao lưu hợp lệ." };
  }
  if (!isRecord(parsed) || parsed.app !== "benevolent" || parsed.kind !== "backup") {
    return { ok: false, reason: "Tệp này không phải bản sao lưu của Benevolent." };
  }
  const result = readPersistedState(parsed.state);
  if (!result.ok) {
    return {
      ok: false,
      reason: result.reason === "newer-version" ? "Bản sao lưu từ phiên bản Benevolent mới hơn. Hãy cập nhật ứng dụng." : "Bản sao lưu bị hỏng hoặc từ phiên bản không hỗ trợ.",
    };
  }
  return result;
}
