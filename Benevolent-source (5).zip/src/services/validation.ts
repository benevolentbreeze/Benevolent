/**
 * Domain validators shared by every trust boundary: stored state, backup files,
 * cross-tab updates and every reducer action. Nothing that reaches the financial
 * state is trusted just because it came from our own UI.
 *
 * Readers normalise what is safe to normalise (over-long text is shortened) and
 * return null for anything that cannot be trusted. They never throw.
 */
import { isCategoryId, isExpenseCategory } from "../data/categories";
import type { Goal } from "../types/goal";
import type { Settings, WorkspaceData } from "../types/state";
import type { Transaction } from "../types/transaction";
import { isAfterToday, isValidTimestamp, parseLocal } from "../utils/date";
import { MAX_AMOUNT } from "../utils/money";

/** Hard ceiling per workspace, per collection. Storage refuses more, so the reducer must too. */
export const MAX_RECORDS = 50_000;
export const MAX_ID_LENGTH = 80;
export const NOTE_MAX_LENGTH = 140;
export const GOAL_NAME_MAX_LENGTH = 40;
export const DISPLAY_NAME_MAX_LENGTH = 40;
const ID_PATTERN = /^[A-Za-z0-9_-]+$/;

export const DEFAULT_SETTINGS: Settings = {
  displayName: "",
  hideAmounts: false,
  nudges: true,
  motion: "system",
  introSeen: false,
};

export const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === "object" && value !== null && !Array.isArray(value);

/** A whole number of đồng in 1 … MAX_AMOUNT. Rejects NaN, Infinity, fractions, negatives and strings. */
export const isAmount = (value: unknown): value is number =>
  typeof value === "number" && Number.isInteger(value) && value > 0 && value <= MAX_AMOUNT;

export const isId = (value: unknown): value is string =>
  typeof value === "string" && value.length > 0 && value.length <= MAX_ID_LENGTH && ID_PATTERN.test(value);

export const isWorkspaceId = (value: unknown): value is "demo" | "personal" => value === "demo" || value === "personal";

/** Text fields are bounded; over-long text is shortened rather than rejected. */
const clampText = (value: string, max: number) => (value.length > max ? value.slice(0, max) : value);

export function readTransaction(value: unknown): Transaction | null {
  if (!isRecord(value)) return null;
  const { id, amount, type, category, note, date, createdAt, goalId, opening } = value;
  if (!isId(id) || !isAmount(amount)) return null;
  if (type !== "expense" && type !== "income" && type !== "saving") return null;
  if (!isCategoryId(category)) return null;
  if (type === "expense" && !isExpenseCategory(category)) return null;
  if (type === "income" && category !== "income") return null;
  if (type === "saving" && (category !== "saving" || !isId(goalId))) return null;
  if (typeof note !== "string" || typeof date !== "string" || date.length !== 16 || !parseLocal(date)) return null;
  if (!isValidTimestamp(createdAt)) return null;
  return {
    id,
    amount,
    type,
    category,
    note: clampText(note, NOTE_MAX_LENGTH),
    date,
    createdAt,
    ...(type === "saving" ? { goalId: goalId as string } : {}),
    ...(opening === true && type !== "expense" ? { opening: true as const } : {}),
  };
}

export function readGoal(value: unknown): Goal | null {
  if (!isRecord(value)) return null;
  const { id, name, targetAmount, deadline, monthlyContribution, createdAt } = value;
  if (!isId(id) || typeof name !== "string" || !name.trim() || !isAmount(targetAmount)) return null;
  if (typeof deadline !== "string" || deadline.length !== 10 || !parseLocal(deadline) || !isValidTimestamp(createdAt)) return null;
  const monthly = monthlyContribution === null || monthlyContribution === undefined || monthlyContribution === 0 ? null : monthlyContribution;
  if (monthly !== null && !isAmount(monthly)) return null;
  return { id, name: clampText(name.trim(), GOAL_NAME_MAX_LENGTH), targetAmount, deadline, monthlyContribution: monthly, createdAt };
}

/** Unknown or wrongly-typed fields fall back to the current value (or the default). */
export function readSettings(value: unknown, base: Settings = DEFAULT_SETTINGS): Settings {
  if (!isRecord(value)) return { ...base };
  return {
    displayName: typeof value.displayName === "string" ? clampText(value.displayName, DISPLAY_NAME_MAX_LENGTH) : base.displayName,
    hideAmounts: typeof value.hideAmounts === "boolean" ? value.hideAmounts : base.hideAmounts,
    nudges: typeof value.nudges === "boolean" ? value.nudges : base.nudges,
    motion: value.motion === "reduce" ? "reduce" : value.motion === "system" ? "system" : base.motion,
    introSeen: typeof value.introSeen === "boolean" ? value.introSeen : base.introSeen,
  };
}

/* ------------------------------------------------------------------ */
/* Mutation rules (below the UI, applied by the reducer)                */
/* ------------------------------------------------------------------ */

/**
 * An opening entry ("Số dư ban đầu" income, or a goal's "Đã tiết kiệm" saving) has a fixed
 * accounting identity: it stays an opening entry of the same type, category and goal for
 * its whole life. Only its amount, note and date may change. Ordinary records can never
 * become opening entries. Records that are not opening entries are unaffected.
 */
export function openingIdentityIsPreserved(existing: Transaction, next: Transaction): boolean {
  if (!existing.opening) return !next.opening;
  return next.opening === true && next.type === existing.type && next.category === existing.category && next.goalId === existing.goalId;
}

/**
 * Money can't be recorded for a day that hasn't happened yet. A mutation may not
 * introduce a future date; a record that already carries one (restored from a backup
 * made in a time zone that is ahead) is left as it is rather than rejected.
 */
export function introducesFutureDate(next: Transaction, previous: Transaction | undefined, now: Date): boolean {
  if (previous && previous.date === next.date) return false;
  const date = parseLocal(next.date);
  return date === null || isAfterToday(date, now);
}

/* ------------------------------------------------------------------ */
/* Workspace invariants                                                 */
/* ------------------------------------------------------------------ */

/** income − expense − savings, over every record (opening entries included). */
export function balanceOf(transactions: readonly Transaction[]): number {
  let balance = 0;
  for (const tx of transactions) balance += tx.type === "income" ? tx.amount : -tx.amount;
  return balance;
}

export function savedByGoal(transactions: readonly Transaction[]): Map<string, number> {
  const saved = new Map<string, number>();
  for (const tx of transactions) {
    if (tx.type === "saving" && tx.goalId) saved.set(tx.goalId, (saved.get(tx.goalId) ?? 0) + tx.amount);
  }
  return saved;
}

/**
 * Structural invariants every workspace must satisfy at all times:
 * unique ids, every saving linked to an existing goal, at most one opening entry per goal,
 * and the storage record ceiling.
 */
export function workspaceIsConsistent(data: WorkspaceData): boolean {
  if (data.transactions.length > MAX_RECORDS || data.goals.length > MAX_RECORDS) return false;
  const goalIds = new Set<string>();
  for (const goal of data.goals) {
    if (goalIds.has(goal.id)) return false;
    goalIds.add(goal.id);
  }
  const txIds = new Set<string>();
  const openings = new Set<string>();
  for (const tx of data.transactions) {
    if (txIds.has(tx.id)) return false;
    txIds.add(tx.id);
    if (tx.type !== "saving") continue;
    if (!tx.goalId || !goalIds.has(tx.goalId)) return false;
    if (tx.opening) {
      if (openings.has(tx.goalId)) return false;
      openings.add(tx.goalId);
    }
  }
  return true;
}

/**
 * Accounting rules for a change that moves money into goals. A change may never:
 * - create or deepen a negative balance by saving more (spending is never blocked — the money was spent);
 * - push a goal past its target, or keep it past a target that was just lowered.
 * Changes that only make things better (saving less, raising a target) are always allowed,
 * so legacy data that already breaks a rule can still be repaired.
 */
export function savingChangeIsAllowed(before: WorkspaceData, after: WorkspaceData): boolean {
  const savedBefore = savedByGoal(before.transactions);
  const savedAfter = savedByGoal(after.transactions);
  let totalBefore = 0;
  let totalAfter = 0;
  for (const value of savedBefore.values()) totalBefore += value;
  for (const value of savedAfter.values()) totalAfter += value;

  if (totalAfter > totalBefore) {
    const balanceAfter = balanceOf(after.transactions);
    if (balanceAfter < Math.min(0, balanceOf(before.transactions))) return false;
  }

  const targetsBefore = new Map(before.goals.map((goal) => [goal.id, goal.targetAmount]));
  for (const goal of after.goals) {
    const saved = savedAfter.get(goal.id) ?? 0;
    if (saved <= goal.targetAmount) continue;
    const previousSaved = savedBefore.get(goal.id) ?? 0;
    const previousTarget = targetsBefore.get(goal.id);
    if (saved > previousSaved || previousTarget === undefined || goal.targetAmount < previousTarget) return false;
  }
  return true;
}
