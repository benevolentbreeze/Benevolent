/**
 * Goal mathematics and goal-related accounting rules.
 *
 * Accounting model: a goal holds no money of its own. Its saved amount is the sum of
 * its `saving` transactions (the opening "Đã tiết kiệm" entry plus later contributions),
 * and every one of those was taken out of the balance. So:
 *   balance + Σ goal savings = Σ income − Σ expenses      (nothing created, nothing lost)
 * Deleting a goal deletes its saving transactions, which returns that money to the balance.
 */
import type { Goal, GoalProgress } from "../types/goal";
import type { Transaction } from "../types/transaction";
import {
  addDays,
  AVERAGE_MONTH_DAYS,
  daysBetween,
  isValidTimestamp,
  monthsBetween,
  parseLocal,
  startOfDay,
  toLocalDateTime,
  toMonthKey,
} from "../utils/date";
import { createId } from "../utils/id";
import { MAX_AMOUNT } from "../utils/money";
import { GOAL_NAME_MAX_LENGTH } from "./validation";

const PACE_WINDOW_DAYS = 90;
/** Projections further out than this are not meaningful; they are reported as "no estimate". */
const MAX_PROJECTION_DAYS = 100 * 366;
export { GOAL_NAME_MAX_LENGTH };

export function savingsFor(goalId: string, transactions: Transaction[]): Transaction[] {
  return transactions.filter((tx) => tx.type === "saving" && tx.goalId === goalId);
}

export function openingFor(goalId: string, transactions: Transaction[]): Transaction | undefined {
  return transactions.find((tx) => tx.type === "saving" && tx.goalId === goalId && tx.opening);
}

export function computeGoalProgress(goal: Goal, transactions: Transaction[], now: Date): GoalProgress {
  const savings = savingsFor(goal.id, transactions);
  const contributions = savings.filter((tx) => !tx.opening);
  const openingAmount = savings.filter((tx) => tx.opening).reduce((sum, tx) => sum + tx.amount, 0);
  const contributedAmount = contributions.reduce((sum, tx) => sum + tx.amount, 0);
  const savedAmount = openingAmount + contributedAmount;
  const target = Math.max(0, goal.targetAmount);
  const remaining = Math.max(0, target - savedAmount);
  const isComplete = remaining === 0;
  const percent = target > 0 ? Math.min(100, (savedAmount / target) * 100) : 100;

  const today = startOfDay(now);
  const deadline = parseLocal(goal.deadline) ?? today;
  const isOverdue = !isComplete && startOfDay(deadline) < today;
  const monthsLeft = Math.max(0, monthsBetween(today, deadline));
  // Less than a month left (or overdue) means the whole remainder is needed now.
  const requiredMonthly = isComplete ? 0 : isOverdue ? remaining : remaining / Math.max(monthsLeft, 1);

  // Pace: the user's plan if they set one, otherwise their real contribution rhythm.
  // Opening savings are a one-off, never a rhythm, so they are excluded.
  let pace = 0;
  let paceSource: GoalProgress["paceSource"] = "none";
  if (goal.monthlyContribution && goal.monthlyContribution > 0) {
    pace = goal.monthlyContribution;
    paceSource = "plan";
  } else {
    const created = isValidTimestamp(goal.createdAt) ? new Date(goal.createdAt) : today;
    const windowDays = Math.max(30, Math.min(PACE_WINDOW_DAYS, daysBetween(created, today)));
    const windowStart = addDays(today, -windowDays);
    const recent = contributions
      .filter((tx) => {
        const date = parseLocal(tx.date);
        return date !== null && date >= windowStart;
      })
      .reduce((sum, tx) => sum + tx.amount, 0);
    if (recent > 0) {
      pace = recent / (windowDays / AVERAGE_MONTH_DAYS);
      paceSource = "history";
    }
  }

  let estimatedCompletion: Date | null = null;
  if (isComplete) estimatedCompletion = today;
  else if (pace > 0) {
    const days = Math.ceil((remaining / pace) * AVERAGE_MONTH_DAYS);
    if (Number.isFinite(days) && days <= MAX_PROJECTION_DAYS) estimatedCompletion = addDays(today, days);
  }

  const projectedAtDeadline = isComplete ? savedAmount : savedAmount + pace * monthsLeft;
  const projectedGap = projectedAtDeadline - target;
  const onTrack = isComplete || (!isOverdue && pace > 0 && projectedGap >= 0);

  const monthKey = toMonthKey(today);
  const contributedThisMonth = contributions
    .filter((tx) => tx.date.startsWith(monthKey))
    .reduce((sum, tx) => sum + tx.amount, 0);
  const commitmentRemainingThisMonth =
    isComplete || !goal.monthlyContribution
      ? 0
      : Math.max(0, Math.min(goal.monthlyContribution - contributedThisMonth, remaining));

  return {
    goal,
    savedAmount,
    openingAmount,
    contributedAmount,
    remaining,
    percent,
    isComplete,
    isOverdue,
    monthsLeft,
    requiredMonthly,
    pace,
    paceSource,
    estimatedCompletion,
    onTrack,
    projectedAtDeadline,
    projectedGap,
    contributedThisMonth,
    commitmentRemainingThisMonth,
  };
}

/* ------------------------------------------------------------------ */
/* Creating and editing goals                                           */
/* ------------------------------------------------------------------ */

export interface GoalDraft {
  name: string;
  targetAmount: number;
  /** Total saved for the goal ("Đã tiết kiệm"): opening amount + contributions. */
  savedAmount: number;
  deadline: string;
  monthlyContribution: number;
}

export type GoalErrors = Partial<Record<keyof GoalDraft, string>>;

export interface GoalSaveContext {
  now: Date;
  /** Current balance (may be negative). */
  balance: number;
  /** The goal being edited, with its current progress. Omitted when creating. */
  existing?: GoalProgress;
}

/**
 * Validates a goal draft against the accounting rules:
 * - the opening amount ("Đã tiết kiệm" minus later contributions) comes out of the balance,
 *   so any increase must be covered by the current balance;
 * - it can't go below what was already contributed;
 * - saved can't exceed the target.
 */
export function validateGoalDraft(draft: GoalDraft, context: GoalSaveContext): GoalErrors {
  const { now, balance, existing } = context;
  const errors: GoalErrors = {};
  const contributed = existing?.contributedAmount ?? 0;
  const currentOpening = existing?.openingAmount ?? 0;

  if (!draft.name.trim()) errors.name = "Đặt tên cho mục tiêu";
  else if (draft.name.trim().length > GOAL_NAME_MAX_LENGTH) errors.name = `Tên tối đa ${GOAL_NAME_MAX_LENGTH} ký tự`;

  if (!Number.isInteger(draft.targetAmount) || draft.targetAmount <= 0) errors.targetAmount = "Nhập số tiền mục tiêu";
  else if (draft.targetAmount > MAX_AMOUNT) errors.targetAmount = "Số tiền vượt quá giới hạn ₫1.000.000.000";

  const opening = draft.savedAmount - contributed;
  if (!Number.isInteger(draft.savedAmount) || draft.savedAmount < 0) errors.savedAmount = "Số tiền không hợp lệ";
  else if (opening < 0) errors.savedAmount = "Không thể thấp hơn số đã góp qua Benevolent";
  else if (draft.savedAmount > MAX_AMOUNT) errors.savedAmount = "Số tiền vượt quá giới hạn";
  else if (!errors.targetAmount && draft.savedAmount > draft.targetAmount) errors.savedAmount = "Không thể lớn hơn số tiền mục tiêu";
  else if (opening - currentOpening > Math.max(0, balance)) {
    errors.savedAmount = "Số dư hiện có không đủ. Hãy ghi khoản thu trước";
  }

  const deadline = parseLocal(draft.deadline);
  const unchangedDeadline = existing !== undefined && draft.deadline === existing.goal.deadline;
  if (!deadline) errors.deadline = "Chọn hạn hoàn thành";
  else if (!unchangedDeadline && startOfDay(deadline) <= startOfDay(now)) errors.deadline = "Hạn hoàn thành cần ở tương lai";

  if (!Number.isInteger(draft.monthlyContribution) || draft.monthlyContribution < 0) {
    errors.monthlyContribution = "Số tiền không hợp lệ";
  } else if (draft.monthlyContribution > MAX_AMOUNT) errors.monthlyContribution = "Số tiền vượt quá giới hạn";
  return errors;
}

/** The opening amount implied by a validated draft. */
export function openingAmountFor(draft: GoalDraft, existing?: GoalProgress): number {
  return draft.savedAmount - (existing?.contributedAmount ?? 0);
}

/**
 * The opening "Đã tiết kiệm" entry for a goal: money moved out of the balance when the
 * goal is set up. Returns null when there is nothing to set aside (the entry is removed).
 */
export function buildOpeningEntry(goalId: string, amount: number, existing: Transaction | undefined, now: Date): Transaction | null {
  if (amount <= 0) return null;
  if (existing) return { ...existing, amount };
  return {
    id: createId("tx"),
    createdAt: now.toISOString(),
    amount,
    type: "saving",
    category: "saving",
    note: "",
    date: toLocalDateTime(now),
    goalId,
    opening: true,
  };
}
