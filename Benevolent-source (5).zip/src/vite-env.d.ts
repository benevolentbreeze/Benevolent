/// <reference types="vite/client" />

interface ImportMetaEnv {
  /**
   * Optional URL of YOUR server-side Brain endpoint (which holds the LLM key).
   * Never put an API key in a VITE_ variable — it would ship to the browser.
   */
  readonly VITE_BRAIN_ENDPOINT?: string;
}
