import { useEffect, useRef } from "react";

/**
 * Lets the system back gesture / button close an overlay (bottom sheet)
 * instead of leaving the page. Pushes one history entry while the overlay is open.
 */
export function useBackDismiss(active: boolean, onDismiss: () => void) {
  const dismiss = useRef(onDismiss);
  dismiss.current = onDismiss;

  useEffect(() => {
    if (!active) return;
    const marker = `overlay-${Math.random().toString(36).slice(2)}`;
    let pushed = false;
    let popped = false;
    // Deferred so StrictMode's mount → unmount → mount does not leave stray entries.
    const timer = window.setTimeout(() => {
      window.history.pushState({ ...(window.history.state ?? {}), overlay: marker }, "");
      pushed = true;
    }, 0);
    const onPop = () => {
      popped = true;
      dismiss.current();
    };
    window.addEventListener("popstate", onPop);
    return () => {
      window.clearTimeout(timer);
      window.removeEventListener("popstate", onPop);
      if (pushed && !popped && window.history.state?.overlay === marker) window.history.back();
    };
  }, [active]);
}
