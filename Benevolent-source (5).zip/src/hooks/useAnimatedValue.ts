import { useEffect, useRef, useState } from "react";

const easeOutQuart = (t: number) => 1 - Math.pow(1 - t, 4);

/**
 * Interpolates from the previously displayed value to the new one.
 * If a new value arrives mid-flight it continues from where the number is now,
 * so rapid repeated changes never jump.
 */
export function useAnimatedNumber(value: number, { duration = 820, disabled = false } = {}) {
  const [display, setDisplay] = useState(value);
  const [direction, setDirection] = useState<"up" | "down" | null>(null);
  const shown = useRef(value);

  useEffect(() => {
    const from = shown.current;
    if (from === value) return;
    if (disabled) {
      shown.current = value;
      setDisplay(value);
      return;
    }
    setDirection(value < from ? "down" : "up");
    // Whole-thousand amounts tick in thousands, so the number stays readable mid-flight.
    const step = from % 1000 === 0 && value % 1000 === 0 ? 1000 : 1;
    const started = performance.now();
    let frame = requestAnimationFrame(function tick(now) {
      const progress = Math.min(1, (now - started) / duration);
      const next = Math.round((from + (value - from) * easeOutQuart(progress)) / step) * step;
      shown.current = next;
      setDisplay(next);
      if (progress < 1) frame = requestAnimationFrame(tick);
      else setDirection(null);
    });
    return () => cancelAnimationFrame(frame);
  }, [value, duration, disabled]);

  return { display, direction };
}

/** Same idea for a series of numbers (chart points), so charts morph instead of redrawing. */
export function useAnimatedSeries(values: number[], { duration = 900, disabled = false } = {}): number[] {
  const [display, setDisplay] = useState(values);
  const shown = useRef(values);
  const signature = values.join(",");

  useEffect(() => {
    const from = shown.current;
    const target = values;
    if (disabled || from.length !== target.length) {
      shown.current = target;
      setDisplay(target);
      return;
    }
    if (from.every((v, i) => v === target[i])) return;
    const started = performance.now();
    let frame = requestAnimationFrame(function tick(now) {
      const progress = Math.min(1, (now - started) / duration);
      const eased = easeOutQuart(progress);
      const next = target.map((v, i) => from[i] + (v - from[i]) * eased);
      shown.current = next;
      setDisplay(next);
      if (progress < 1) frame = requestAnimationFrame(tick);
    });
    return () => cancelAnimationFrame(frame);
    // `signature` captures `values` by content, not identity.
  }, [signature, duration, disabled]);

  return display;
}
