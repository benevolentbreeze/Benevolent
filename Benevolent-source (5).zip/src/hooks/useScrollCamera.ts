import { useEffect, type RefObject } from "react";

const STOPS = ["balance", "spending", "brain", "goals"];

/**
 * Scroll as a camera: one rAF-throttled listener writes transforms straight to the
 * few elements that move (no React re-render, no global style recalculation), and an
 * IntersectionObserver tells the camera thread which part of the system is in view.
 */
export function useScrollCamera(thread: RefObject<HTMLElement | null>, enabled: boolean, viewKey: string) {
  useEffect(() => {
    const threadNode = thread.current;
    const parallax = [...document.querySelectorAll<HTMLElement>("[data-camera-parallax]")];
    if (!enabled) {
      parallax.forEach((node) => (node.style.transform = ""));
      return;
    }

    let frame = 0;
    const update = () => {
      frame = 0;
      const y = window.scrollY;
      const progress = Math.min(y / 900, 1);
      for (const node of parallax) {
        const rect = node.getBoundingClientRect();
        const offset = (rect.top + rect.height / 2 - window.innerHeight / 2) * -0.08;
        node.style.transform = `translate3d(0, ${offset.toFixed(1)}px, 0) scale(1.06)`;
      }
      if (threadNode) {
        threadNode.style.setProperty("--thread-progress", progress.toFixed(3));
      }
    };
    const onScroll = () => {
      if (!frame) frame = requestAnimationFrame(update);
    };
    update();
    window.addEventListener("scroll", onScroll, { passive: true });

    const stops = [...document.querySelectorAll<HTMLElement>("[data-camera-stop]")];
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (!entry.isIntersecting) continue;
          const stop = (entry.target as HTMLElement).dataset.cameraStop ?? "";
          threadNode?.setAttribute("data-active", String(STOPS.indexOf(stop)));
        }
      },
      { rootMargin: "-45% 0px -45% 0px" },
    );
    stops.forEach((stop) => observer.observe(stop));

    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener("scroll", onScroll);
      observer.disconnect();
    };
  }, [thread, enabled, viewKey]);
}

export const CAMERA_STOPS = [
  { id: "balance", label: "Số dư" },
  { id: "spending", label: "Chi tiêu" },
  { id: "brain", label: "Brain" },
  { id: "goals", label: "Mục tiêu" },
];
