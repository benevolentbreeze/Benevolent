import { useCallback, useEffect, useState } from "react";

export type View = "today" | "history" | "brain" | "goals" | "settings";

const VIEWS: View[] = ["today", "history", "brain", "goals", "settings"];

function readView(): View {
  const id = window.location.hash.replace(/^#\/?/, "");
  return (VIEWS as string[]).includes(id) ? (id as View) : "today";
}

/** Hash-based navigation so the browser/Android back button moves between screens. */
export function useHashView(): [View, (view: View) => void] {
  const [view, setView] = useState<View>(readView);

  useEffect(() => {
    // Overlays add history entries; we manage scroll ourselves so closing one never jumps the page.
    window.history.scrollRestoration = "manual";
    const onChange = () => {
      setView(readView());
      window.scrollTo({ top: 0 });
    };
    window.addEventListener("hashchange", onChange);
    return () => window.removeEventListener("hashchange", onChange);
  }, []);

  const navigate = useCallback((next: View) => {
    const hash = next === "today" ? "#/" : `#/${next}`;
    if (window.location.hash !== hash) window.location.hash = hash;
    setView(next);
    window.scrollTo({ top: 0 });
  }, []);

  return [view, navigate];
}
