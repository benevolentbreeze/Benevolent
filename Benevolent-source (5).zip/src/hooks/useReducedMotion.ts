import { useEffect, useState } from "react";
import { useFinance } from "../state/FinanceStore";

const QUERY = "(prefers-reduced-motion: reduce)";

function useSystemReducedMotion(): boolean {
  const [reduced, setReduced] = useState(() => typeof window !== "undefined" && window.matchMedia(QUERY).matches);
  useEffect(() => {
    const media = window.matchMedia(QUERY);
    const onChange = () => setReduced(media.matches);
    media.addEventListener("change", onChange);
    return () => media.removeEventListener("change", onChange);
  }, []);
  return reduced;
}

/** True when the OS asks for reduced motion or the user chose it in Settings. */
export function useReducedMotion(): boolean {
  const system = useSystemReducedMotion();
  const { settings } = useFinance();
  return system || settings.motion === "reduce";
}
