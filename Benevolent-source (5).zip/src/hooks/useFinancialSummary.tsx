import { createContext, useContext, useMemo, type ReactNode } from "react";
import { computeAllGoalProgress, computeSummary } from "../services/financialEngine";
import { buildContext, type BrainContext } from "../services/brainService";
import { useFinance } from "../state/FinanceStore";
import type { FinancialSummary } from "../types/financialSummary";
import type { GoalProgress } from "../types/goal";
import { useNow } from "./useNow";

export interface DerivedFinance {
  now: Date;
  summary: FinancialSummary;
  goals: GoalProgress[];
  brain: BrainContext;
}

const DerivedContext = createContext<DerivedFinance | null>(null);

/** Computes every derived number once per change, for the whole app. */
export function DerivedFinanceProvider({ children }: { children: ReactNode }) {
  const { data, workspace } = useFinance();
  const now = useNow();
  const value = useMemo(() => {
    const goals = computeAllGoalProgress(data, now);
    const summary = computeSummary(data, now, goals);
    return { now, summary, goals, brain: buildContext(summary, goals, workspace === "demo") };
  }, [data, now, workspace]);
  return <DerivedContext.Provider value={value}>{children}</DerivedContext.Provider>;
}

export function useFinancialSummary(): DerivedFinance {
  const value = useContext(DerivedContext);
  if (!value) throw new Error("useFinancialSummary must be used inside <DerivedFinanceProvider>");
  return value;
}
