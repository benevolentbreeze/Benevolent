/**
 * Local-time date helpers with Vietnamese formatting.
 * Dates are stored as local wall-clock strings ("YYYY-MM-DD" / "YYYY-MM-DDTHH:mm")
 * so grouping by day never drifts across time zones.
 */

const WEEKDAYS = ["Chủ nhật", "Thứ hai", "Thứ ba", "Thứ tư", "Thứ năm", "Thứ sáu", "Thứ bảy"];
const WEEKDAYS_SHORT = ["CN", "T2", "T3", "T4", "T5", "T6", "T7"];
const DAY_MS = 86_400_000;
export const AVERAGE_MONTH_DAYS = 30.4375;

const pad = (value: number) => String(value).padStart(2, "0");

export function toDateKey(date: Date): string {
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

export function toMonthKey(date: Date): string {
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}`;
}

export function toLocalDateTime(date: Date): string {
  return `${toDateKey(date)}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

/** Years the app accepts. Guards against the JS Date two-digit-year quirk (0–99 → 1900s) and absurd imports. */
const MIN_YEAR = 1970;
const MAX_YEAR = 2200;

/**
 * Parses "YYYY-MM-DD" or "YYYY-MM-DDTHH:mm" as local time. Returns null when invalid:
 * impossible calendar dates (31/02), out-of-range clock times (10:75) and years outside 1970–2200.
 */
export function parseLocal(value: unknown): Date | null {
  if (typeof value !== "string") return null;
  const match = /^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2}))?$/.exec(value);
  if (!match) return null;
  const [year, month, day, hours, minutes] = match.slice(1).map((part) => Number(part ?? 0));
  if (year < MIN_YEAR || year > MAX_YEAR || hours > 23 || minutes > 59) return null;
  const date = new Date(2000, 0, 1, hours, minutes);
  date.setFullYear(year, month - 1, day);
  if (date.getFullYear() !== year || date.getMonth() !== month - 1 || date.getDate() !== day) return null;
  return date;
}

/** True when an ISO timestamp (e.g. createdAt) parses to a real instant. */
export function isValidTimestamp(value: unknown): value is string {
  return typeof value === "string" && value.length <= 40 && Number.isFinite(Date.parse(value));
}

export function startOfDay(date: Date): Date {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}

/**
 * The single "is this in the future?" rule for recorded money: every time of today counts as
 * the present (a record can be logged for later today), tomorrow onwards is the future.
 */
export function isAfterToday(date: Date, now: Date): boolean {
  return startOfDay(date) > startOfDay(now);
}

export function addDays(date: Date, days: number): Date {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate() + days, date.getHours(), date.getMinutes());
}

export function addMonths(date: Date, months: number): Date {
  const target = new Date(date.getFullYear(), date.getMonth() + months, 1, date.getHours(), date.getMinutes());
  const lastDay = new Date(target.getFullYear(), target.getMonth() + 1, 0).getDate();
  target.setDate(Math.min(date.getDate(), lastDay));
  return target;
}

export function startOfMonth(date: Date): Date {
  return new Date(date.getFullYear(), date.getMonth(), 1);
}

export function daysInMonth(date: Date): number {
  return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
}

export function daysBetween(from: Date, to: Date): number {
  return Math.round((startOfDay(to).getTime() - startOfDay(from).getTime()) / DAY_MS);
}

export function monthsBetween(from: Date, to: Date): number {
  return daysBetween(from, to) / AVERAGE_MONTH_DAYS;
}

/** "Thứ bảy, 3 tháng 10" */
export function formatLongDate(date: Date): string {
  return `${WEEKDAYS[date.getDay()]}, ${date.getDate()} tháng ${date.getMonth() + 1}`;
}

/** "Hôm nay" · "Hôm qua" · "Thứ hai, 6 tháng 10" (+ year when not the current year) */
export function formatDayHeading(date: Date, now: Date): string {
  const diff = daysBetween(date, now);
  if (diff === 0) return "Hôm nay";
  if (diff === 1) return "Hôm qua";
  const base = formatLongDate(date);
  return date.getFullYear() === now.getFullYear() ? base : `${base}, ${date.getFullYear()}`;
}

export function formatWeekdayShort(date: Date): string {
  return WEEKDAYS_SHORT[date.getDay()];
}

export function formatTime(date: Date): string {
  return `${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

/** "Tháng 10" or "Tháng 10, 2025" */
export function formatMonth(date: Date, now?: Date): string {
  const label = `Tháng ${date.getMonth() + 1}`;
  return now && now.getFullYear() !== date.getFullYear() ? `${label}, ${date.getFullYear()}` : label;
}

/** "tháng 6/2027" */
export function formatMonthYear(date: Date): string {
  return `tháng ${date.getMonth() + 1}/${date.getFullYear()}`;
}

/** "15.06.27" — compact label for the horizon */
export function formatShortDate(date: Date): string {
  return `${pad(date.getDate())}.${pad(date.getMonth() + 1)}.${String(date.getFullYear()).slice(2)}`;
}

/** "15/06/2027" */
export function formatNumericDate(date: Date): string {
  return `${pad(date.getDate())}/${pad(date.getMonth() + 1)}/${date.getFullYear()}`;
}
