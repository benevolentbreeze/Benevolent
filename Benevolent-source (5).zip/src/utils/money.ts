const grouped = new Intl.NumberFormat("vi-VN", { maximumFractionDigits: 0 });
const MINUS = "−";

/** Largest single amount the app accepts (1 tỷ đồng). */
export const MAX_AMOUNT = 1_000_000_000;

export const HIDDEN_MONEY = "₫ •••••";

export function formatMoney(value: number, options: { signed?: boolean } = {}): string {
  if (!Number.isFinite(value)) return "₫—";
  const rounded = Math.round(value);
  const sign = rounded < 0 ? MINUS : options.signed && rounded > 0 ? "+" : "";
  return `${sign}₫${grouped.format(Math.abs(rounded))}`;
}

/** 2.50 → "2,5" · 10.00 → "10" (Vietnamese decimal comma, no trailing zeros) */
function trimDecimal(value: number, digits: number): string {
  let fixed = value.toFixed(digits);
  if (fixed.includes(".")) fixed = fixed.replace(/0+$/, "").replace(/\.$/, "");
  return fixed.replace(".", ",");
}

/** ₫950 · ₫9,5K · ₫438K · ₫2,84M · ₫1,2 tỷ */
export function formatCompactMoney(value: number): string {
  if (!Number.isFinite(value)) return "₫—";
  const abs = Math.abs(Math.round(value));
  const sign = value < 0 ? MINUS : "";
  if (abs < 1_000) return `${sign}₫${abs}`;
  if (abs < 10_000) return `${sign}₫${trimDecimal(abs / 1_000, 1)}K`;
  if (abs < 1_000_000) return `${sign}₫${Math.round(abs / 1_000)}K`;
  if (abs < 1_000_000_000) return `${sign}₫${trimDecimal(abs / 1_000_000, abs < 10_000_000 ? 2 : 1)}M`;
  return `${sign}₫${trimDecimal(abs / 1_000_000_000, 2)} tỷ`;
}

/** 0.338 → "33,8%" · signed: −0.27 → "−27%", 0.12 → "+12%" */
export function formatPercent(ratio: number, digits = 0, signed = false): string {
  if (!Number.isFinite(ratio)) return "—";
  const value = ratio * 100;
  const precision = digits === 0 && value !== 0 && Math.abs(value) < 1 ? 1 : digits;
  const sign = value < 0 ? MINUS : signed && value > 0 ? "+" : "";
  return `${sign}${trimDecimal(Math.abs(value), precision)}%`;
}

export function parseAmountInput(raw: string): number {
  const digits = raw.replace(/\D/g, "").replace(/^0+(?=\d)/, "");
  if (!digits) return 0;
  return Number(digits.slice(0, 13));
}

/** "35000" → "35.000" for display inside the amount field */
export function formatAmountInput(value: number): string {
  return value > 0 ? grouped.format(value) : "";
}
