import type { Goal } from "./goal";
import type { Transaction } from "./transaction";

export type WorkspaceId = "demo" | "personal";

export interface WorkspaceData {
  transactions: Transaction[];
  /** The first goal is the primary goal. */
  goals: Goal[];
}

export interface Settings {
  displayName: string;
  hideAmounts: boolean;
  /** Gentle in-app nudges (no push notifications). */
  nudges: boolean;
  motion: "system" | "reduce";
  introSeen: boolean;
}

export const STATE_VERSION = 2;

export interface PersistedState {
  version: typeof STATE_VERSION;
  activeWorkspace: WorkspaceId;
  workspaces: {
    demo: WorkspaceData | null;
    personal: WorkspaceData;
  };
  settings: Settings;
}
