export type ExpenseCategoryId = "food" | "transport" | "study" | "entertainment" | "shopping" | "other";

/** "income" and "saving" are system categories used by non-expense transactions. */
export type CategoryId = ExpenseCategoryId | "income" | "saving";

export type CategoryIcon =
  | "food"
  | "transport"
  | "study"
  | "entertainment"
  | "shopping"
  | "other"
  | "income"
  | "goal";

export interface CategoryDefinition {
  id: CategoryId;
  label: string;
  icon: CategoryIcon;
}
