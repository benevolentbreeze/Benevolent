import type { CategoryId } from "./category";

/**
 * expense — money spent
 * income  — money received
 * saving  — money moved from the balance into a goal (linked by goalId)
 */
export type TransactionType = "expense" | "income" | "saving";

export interface Transaction {
  id: string;
  /** Positive whole number of đồng. The sign comes from `type`. */
  amount: number;
  type: TransactionType;
  category: CategoryId;
  /** Exactly what the user typed. Empty string when no note was given. */
  note: string;
  /** When it happened, local wall-clock time: "YYYY-MM-DDTHH:mm". */
  date: string;
  /** ISO timestamp of when the record was created. */
  createdAt: string;
  goalId?: string;
  /**
   * Opening entry, not regular activity:
   * - on a `saving` tx: the "Đã tiết kiệm" amount set aside when the goal was set up;
   * - on an `income` tx: money that existed before tracking (only created by data
   *   migration / demo data). It counts toward the balance but not toward income statistics.
   * Opening entries never count toward a goal's monthly pace.
   */
  opening?: true;
}

export interface TransactionDraft {
  amount: number;
  type: TransactionType;
  category: CategoryId | null;
  note: string;
  date: string;
  goalId?: string;
}
