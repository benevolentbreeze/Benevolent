import type { ExpenseCategoryId } from "./category";

export interface DailyPoint {
  key: string;
  date: Date;
  expense: number;
  income: number;
}

export interface CategorySpend {
  id: ExpenseCategoryId;
  label: string;
  amount: number;
  /** 0–1 share of this month's spending */
  share: number;
  count: number;
  lastMonthAmount: number;
  last7: number;
  prev7: number;
}

export interface FinancialSummary {
  now: Date;
  transactionCount: number;

  balance: number;
  totalIncome: number;
  totalExpense: number;
  totalSaved: number;

  todayExpense: number;
  todayCount: number;

  monthIncome: number;
  monthExpense: number;
  monthSaved: number;
  monthCount: number;
  /** monthExpense / monthIncome — null when there is no income this month. */
  spendingRatio: number | null;
  /** Share of this month's income not spent: (income − expense) / income. null without income. */
  savingsRate: number | null;

  daysLeftInMonth: number;
  goalCommitmentRemaining: number;
  safeToSpend: number;
  dailyAllowance: number;

  last7: DailyPoint[];
  last7Total: number;
  prev7Total: number;
  /** Relative change last 7 days vs the 7 before. null when no baseline. */
  weekChange: number | null;

  /** Per-category spending for each of the last 7 days (aligned with `last7`). */
  categoryLast7: Record<ExpenseCategoryId, number[]>;
  monthDays: DailyPoint[];
  categories: CategorySpend[];
  topCategory: CategorySpend | null;
}
