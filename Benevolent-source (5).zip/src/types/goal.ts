/**
 * A savings goal. It holds no money itself: every đồng in a goal is a `saving`
 * transaction moved out of the balance (see Transaction.opening for money that was
 * already set aside when the goal was created). That keeps one source of truth —
 * balance + goal savings always equals what the user has.
 */
export interface Goal {
  id: string;
  name: string;
  targetAmount: number;
  /** "YYYY-MM-DD" */
  deadline: string;
  /** Planned monthly contribution, if the user set one. */
  monthlyContribution: number | null;
  createdAt: string;
}

export type GoalPaceSource = "plan" | "history" | "none";

/** Everything here is derived from the goal + its saving transactions. */
export interface GoalProgress {
  goal: Goal;
  /** Opening savings + contributions, i.e. everything moved into this goal. */
  savedAmount: number;
  /** The part of savedAmount recorded as "Đã tiết kiệm" when the goal was set up. */
  openingAmount: number;
  /** Contributions made after set-up (savedAmount − openingAmount). */
  contributedAmount: number;
  remaining: number;
  /** 0–100 */
  percent: number;
  isComplete: boolean;
  isOverdue: boolean;
  monthsLeft: number;
  /** Needed per month from now to hit the deadline. */
  requiredMonthly: number;
  /** Monthly pace used for projections. */
  pace: number;
  paceSource: GoalPaceSource;
  estimatedCompletion: Date | null;
  onTrack: boolean;
  /** Saved amount at the deadline if the pace holds. */
  projectedAtDeadline: number;
  /** Positive = surplus, negative = shortfall at the deadline. */
  projectedGap: number;
  contributedThisMonth: number;
  /** Planned contribution still to set aside this month (0 when no plan). */
  commitmentRemainingThisMonth: number;
}
