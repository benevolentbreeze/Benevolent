import { useCallback, useEffect, useRef } from "react";
import BottomNavigation from "./components/BottomNavigation";
import ErrorBoundary from "./components/ErrorBoundary";
import Intro from "./components/Intro";
import MoneyTransferLayer from "./components/MoneyTransfer";
import QuickEntry from "./components/QuickEntry";
import Toasts from "./components/Toasts";
import { DerivedFinanceProvider, useFinancialSummary } from "./hooks/useFinancialSummary";
import { useHashView } from "./hooks/useHashView";
import { useReducedMotion } from "./hooks/useReducedMotion";
import { CAMERA_STOPS, useScrollCamera } from "./hooks/useScrollCamera";
import Brain from "./pages/Brain";
import Goals from "./pages/Goals";
import History from "./pages/History";
import Home from "./pages/Home";
import Settings from "./pages/Settings";
import { FinanceProvider, useFinance } from "./state/FinanceStore";
import { UIProvider, useUI } from "./state/UIStore";
import { formatCompactMoney, formatPercent } from "./utils/money";

function CameraThread() {
  const thread = useRef<HTMLDivElement>(null);
  const { view } = useUI();
  const reduced = useReducedMotion();
  useScrollCamera(thread, !reduced, view);
  if (view !== "today") return null;
  return (
    <div className="camera-thread" ref={thread} aria-hidden="true">
      <span />
      {CAMERA_STOPS.map((stop) => (
        <i key={stop.id}>
          <b>{stop.label}</b>
        </i>
      ))}
      <small>TIỀN CỦA BẠN · HƯỚNG CỦA BẠN</small>
    </div>
  );
}

function Shell() {
  const { settings, actions, ready } = useFinance();
  const { summary } = useFinancialSummary();
  const ui = useUI();
  const reduced = useReducedMotion();

  useEffect(() => {
    document.documentElement.dataset.motion = reduced ? "reduce" : "full";
  }, [reduced]);

  const { endIntroReplay } = ui;
  const finishIntro = useCallback(() => {
    actions.updateSettings({ introSeen: true });
    endIntroReplay();
  }, [actions, endIntroReplay]);

  if (!ready) return <div className="app-loading" aria-busy="true" />;

  // First visit plays the intro unless motion is reduced; "Xem lại phần mở đầu" always plays it
  // (as a still composition when motion is reduced).
  const showIntro = (!settings.introSeen && !reduced) || ui.introReplay;
  const hide = settings.hideAmounts;
  const introFigures = [
    hide ? "₫•••" : formatCompactMoney(summary.todayExpense),
    summary.weekChange !== null ? `${summary.weekChange < 0 ? "−" : "+"}${formatPercent(Math.abs(summary.weekChange))}` : "7 ngày",
    hide ? "₫•••" : `${formatCompactMoney(summary.dailyAllowance)}/ngày`,
    summary.spendingRatio !== null ? formatPercent(summary.spendingRatio, 1) : "0%",
    hide ? "₫•••" : formatCompactMoney(summary.balance),
  ];

  const page = {
    today: <Home />,
    history: <History />,
    brain: <Brain />,
    goals: <Goals />,
    settings: <Settings />,
  }[ui.view];

  return (
    <div className="app-shell">
      {showIntro && <Intro figures={introFigures} onDone={finishIntro} still={reduced} />}
      <a
        className="skip-link"
        href="#main"
        onClick={(event) => {
          // Routing lives in the hash, so move focus instead of navigating to "#main".
          event.preventDefault();
          const main = document.getElementById("main");
          main?.setAttribute("tabindex", "-1");
          main?.focus();
        }}
      >
        Bỏ qua tới nội dung
      </a>
      <BottomNavigation active={ui.view} onChange={ui.navigate} />
      <CameraThread />
      <div className="app-content" key={ui.view}>
        {page}
      </div>
      {ui.entry && <QuickEntry key={ui.entry.mode === "edit" ? ui.entry.tx.id : "new"} request={ui.entry} />}
      <MoneyTransferLayer />
      <Toasts />
    </div>
  );
}

function Routed() {
  const [view, navigate] = useHashView();
  return (
    <UIProvider view={view} navigate={navigate}>
      <Shell />
    </UIProvider>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <FinanceProvider>
        <DerivedFinanceProvider>
          <Routed />
        </DerivedFinanceProvider>
      </FinanceProvider>
    </ErrorBoundary>
  );
}
