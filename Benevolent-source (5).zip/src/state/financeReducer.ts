/**
 * The pure state machine behind FinanceStore. Kept free of React so every
 * financial state transition can be unit-tested directly.
 */
import { createDemoWorkspace, createEmptyWorkspace } from "../data/demoSeed";
import { createDefaultState, readPersistedState } from "../services/storageService";
import { sortTransactions } from "../services/transactionService";
import {
  MAX_RECORDS,
  isId,
  isRecord,
  isWorkspaceId,
  readGoal,
  readSettings,
  readTransaction,
  savingChangeIsAllowed,
  introducesFutureDate,
  openingIdentityIsPreserved,
  workspaceIsConsistent,
} from "../services/validation";
import type { Goal } from "../types/goal";
import type { PersistedState, Settings, WorkspaceData, WorkspaceId } from "../types/state";
import type { Transaction } from "../types/transaction";

export type StorageIssue = "unavailable" | "corrupted" | "save-failed" | "repaired" | null;

export interface StoreState {
  status: "loading" | "ready";
  persisted: PersistedState;
  issue: StorageIssue;
}

export type Action =
  | { type: "hydrate"; persisted: PersistedState; issue: StorageIssue }
  | { type: "external"; persisted: PersistedState }
  | { type: "addTransaction"; tx: Transaction; workspace?: WorkspaceId }
  | { type: "updateTransaction"; tx: Transaction; workspace?: WorkspaceId }
  | { type: "deleteTransaction"; id: string; workspace?: WorkspaceId }
  | { type: "saveGoal"; goal: Goal; opening: Transaction | null; workspace?: WorkspaceId }
  | { type: "deleteGoal"; id: string; workspace?: WorkspaceId }
  | { type: "setPrimaryGoal"; id: string }
  | { type: "updateSettings"; patch: Partial<Settings> }
  | { type: "switchWorkspace"; workspace: WorkspaceId }
  | { type: "resetWorkspace"; workspace: WorkspaceId }
  | { type: "replaceAll"; persisted: PersistedState }
  | { type: "setIssue"; issue: StorageIssue; onlyIf?: StorageIssue };

/**
 * Applies a change to one workspace. Delayed commits (a transfer animation, a goal
 * contribution) name the workspace they were started in, so switching workspaces
 * mid-animation can never write into the wrong one.
 */
function updateWorkspace(state: StoreState, target: WorkspaceId | undefined, update: (data: WorkspaceData) => WorkspaceData): StoreState {
  const { persisted } = state;
  const key = target ?? persisted.activeWorkspace;
  const current = persisted.workspaces[key];
  if (!current) return state;
  const next = update(current);
  if (next === current) return state;
  return { ...state, persisted: { ...persisted, workspaces: { ...persisted.workspaces, [key]: next } } };
}

/**
 * Every action is treated as untrusted input — it may come from a stale sheet, another
 * tab, an undo toast, a future remote adapter or a bug. Payloads are re-validated with the
 * same readers that guard storage, and any change that would break an accounting invariant
 * is ignored: the state is returned unchanged (same reference), never partially applied.
 */
function guarded(before: WorkspaceData, after: WorkspaceData, movesMoney: boolean): WorkspaceData {
  if (!workspaceIsConsistent(after)) return before;
  if (movesMoney && !savingChangeIsAllowed(before, after)) return before;
  return after;
}

/** A target outside the two known workspaces is ignored rather than creating a new key. */
const validTarget = (workspace: unknown) => workspace === undefined || isWorkspaceId(workspace);

/** Re-validates a whole state that arrives from outside the reducer (storage, another tab, a backup, undo). */
function readWhole(persisted: unknown): PersistedState | null {
  const result = readPersistedState(persisted);
  return result.ok ? result.state : null;
}

/** The trusted source of "now" for the business rules the reducer enforces. */
export type Clock = () => Date;
const systemClock: Clock = () => new Date();

/**
 * Builds the reducer around a clock. The app uses the system clock; tests pass a fixed one,
 * so date rules (no future records) are deterministic and never depend on the machine.
 */
export function createReducer(clock: Clock = systemClock): (state: StoreState, action: Action) => StoreState {
  return (state, action) => reduce(state, action, clock);
}

export const reducer = createReducer();

function reduce(state: StoreState, action: Action, clock: Clock): StoreState {
  if (!isRecord(action)) return state;
  if ("workspace" in action && action.type !== "switchWorkspace" && action.type !== "resetWorkspace" && !validTarget(action.workspace)) {
    return state;
  }
  switch (action.type) {
    case "hydrate": {
      const persisted = readWhole(action.persisted);
      if (!persisted) return { status: "ready", persisted: ensureDemo(createDefaultState()), issue: "corrupted" };
      return { status: "ready", persisted: ensureDemo(persisted), issue: action.issue };
    }
    case "external": {
      const persisted = readWhole(action.persisted);
      return persisted ? { ...state, persisted: ensureDemo(persisted) } : state;
    }
    case "addTransaction": {
      const tx = readTransaction(action.tx);
      if (!tx) return state;
      return updateWorkspace(state, action.workspace, (data) => {
        // Idempotent: adding the same record twice (double tap, repeated undo) changes nothing.
        if (data.transactions.some((item) => item.id === tx.id)) return data;
        if (data.transactions.length >= MAX_RECORDS) return data;
        if (introducesFutureDate(tx, undefined, clock())) return data;
        const next = { ...data, transactions: sortTransactions([tx, ...data.transactions]) };
        return guarded(data, next, tx.type === "saving");
      });
    }
    case "updateTransaction": {
      const tx = readTransaction(action.tx);
      if (!tx) return state;
      return updateWorkspace(state, action.workspace, (data) => {
        const existing = data.transactions.find((item) => item.id === tx.id);
        if (!existing) return data;
        // An opening entry keeps its accounting identity; an ordinary record can't become one.
        if (!openingIdentityIsPreserved(existing, tx)) return data;
        if (introducesFutureDate(tx, existing, clock())) return data;
        const next = { ...data, transactions: sortTransactions(data.transactions.map((item) => (item.id === tx.id ? tx : item))) };
        return guarded(data, next, tx.type === "saving" || existing.type === "saving");
      });
    }
    case "deleteTransaction":
      if (!isId(action.id)) return state;
      return updateWorkspace(state, action.workspace, (data) =>
        data.transactions.some((tx) => tx.id === action.id)
          ? { ...data, transactions: data.transactions.filter((tx) => tx.id !== action.id) }
          : data,
      );
    case "saveGoal": {
      // Goal and its opening savings change together, in one step, so they can never drift apart.
      const goal = readGoal(action.goal);
      if (!goal) return state;
      let opening: Transaction | null = null;
      if (action.opening !== null) {
        opening = readTransaction(action.opening);
        if (!opening || opening.type !== "saving" || !opening.opening || opening.goalId !== goal.id) return state;
      }
      return updateWorkspace(state, action.workspace, (data) => {
        const exists = data.goals.some((item) => item.id === goal.id);
        if (!exists && data.goals.length >= MAX_RECORDS) return data;
        const goals = exists ? data.goals.map((item) => (item.id === goal.id ? goal : item)) : [...data.goals, goal];
        const previous = data.transactions.find((tx) => tx.type === "saving" && tx.goalId === goal.id && tx.opening);
        if (opening && introducesFutureDate(opening, previous, clock())) return data;
        const withoutOpening = data.transactions.filter((tx) => tx !== previous);
        const transactions = opening ? sortTransactions([opening, ...withoutOpening]) : withoutOpening;
        return guarded(data, { goals, transactions }, true);
      });
    }
    case "deleteGoal":
      // The goal's savings (opening + contributions) return to the balance with it.
      if (!isId(action.id)) return state;
      return updateWorkspace(state, action.workspace, (data) =>
        data.goals.some((goal) => goal.id === action.id)
          ? {
              goals: data.goals.filter((goal) => goal.id !== action.id),
              transactions: data.transactions.filter((tx) => tx.goalId !== action.id),
            }
          : data,
      );
    case "setPrimaryGoal":
      if (!isId(action.id)) return state;
      return updateWorkspace(state, undefined, (data) => {
        const goal = data.goals.find((item) => item.id === action.id);
        return goal && data.goals[0] !== goal ? { ...data, goals: [goal, ...data.goals.filter((item) => item.id !== action.id)] } : data;
      });
    case "updateSettings": {
      if (!isRecord(action.patch)) return state;
      const settings = readSettings({ ...state.persisted.settings, ...action.patch }, state.persisted.settings);
      return { ...state, persisted: { ...state.persisted, settings } };
    }
    case "switchWorkspace":
      if (!isWorkspaceId(action.workspace)) return state;
      return { ...state, persisted: ensureDemo({ ...state.persisted, activeWorkspace: action.workspace }) };
    case "resetWorkspace": {
      if (!isWorkspaceId(action.workspace)) return state;
      const fresh = action.workspace === "demo" ? createDemoWorkspace() : createEmptyWorkspace();
      return {
        ...state,
        persisted: { ...state.persisted, workspaces: { ...state.persisted.workspaces, [action.workspace]: fresh } },
      };
    }
    case "replaceAll": {
      const persisted = readWhole(action.persisted);
      return persisted ? { ...state, persisted: ensureDemo(persisted), issue: null } : state;
    }
    case "setIssue":
      if (action.onlyIf !== undefined && state.issue !== action.onlyIf) return state;
      return state.issue === action.issue ? state : { ...state, issue: action.issue };
    default:
      return state;
  }
}

export function ensureDemo(persisted: PersistedState): PersistedState {
  if (persisted.activeWorkspace !== "demo" || persisted.workspaces.demo) return persisted;
  return { ...persisted, workspaces: { ...persisted.workspaces, demo: createDemoWorkspace() } };
}
