import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { flushSync } from "react-dom";
import type { View } from "../hooks/useHashView";
import type { CategoryId } from "../types/category";
import type { Transaction, TransactionType } from "../types/transaction";

export type EntryRequest =
  | { mode: "create"; type: Exclude<TransactionType, "saving"> }
  | { mode: "edit"; tx: Transaction };

export interface Toast {
  id: number;
  message: string;
  tone: "neutral" | "success" | "warning";
  action?: { label: string; run: () => void };
}

export interface TransferRequest {
  id: number;
  amount: number;
  direction: "out" | "in";
  categoryId: CategoryId;
  label: string;
  origin: DOMRect;
  /** Applies the change to the store — called when the money reaches the balance. */
  commit: () => void;
}

interface UIContextValue {
  view: View;
  navigate: (view: View) => void;
  entry: EntryRequest | null;
  openEntry: (request?: EntryRequest) => void;
  closeEntry: () => void;
  toasts: Toast[];
  toast: (message: string, tone?: Toast["tone"], action?: Toast["action"]) => void;
  dismissToast: (id: number) => void;
  transfers: TransferRequest[];
  launchTransfer: (request: Omit<TransferRequest, "id">) => void;
  finishTransfer: (id: number) => void;
  /** "Xem lại phần mở đầu": plays the intro again (a static version under reduced motion). */
  introReplay: boolean;
  replayIntro: () => void;
  endIntroReplay: () => void;
  /**
   * Registers a data change that an animation will apply a little later. Returns the
   * once-only commit function. Anything still pending is applied immediately if the
   * page is hidden, reloaded or closed, so an animation can never cost a record.
   */
  deferCommit: (commit: () => void) => () => void;
}

/** Safety net: a transfer's data change lands even if its animation never runs. */
const TRANSFER_COMMIT_FALLBACK_MS = 1600;

const UIContext = createContext<UIContextValue | null>(null);

export function UIProvider({ children, view, navigate }: { children: ReactNode; view: View; navigate: (view: View) => void }) {
  const [entry, setEntry] = useState<EntryRequest | null>(null);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [transfers, setTransfers] = useState<TransferRequest[]>([]);
  const [introReplay, setIntroReplay] = useState(false);
  const counter = useRef(0);

  const dismissToast = useCallback((id: number) => setToasts((items) => items.filter((item) => item.id !== id)), []);

  const toast = useCallback(
    (message: string, tone: Toast["tone"] = "neutral", action?: Toast["action"]) => {
      counter.current += 1;
      const id = counter.current;
      setToasts((items) => [...items.slice(-2), { id, message, tone, action }]);
      window.setTimeout(() => dismissToast(id), action || tone === "warning" ? 6500 : 3600);
    },
    [dismissToast],
  );

  const pending = useRef(new Set<() => void>());

  const deferCommit = useCallback((apply: () => void) => {
    let done = false;
    const commit = () => {
      if (done) return;
      done = true;
      pending.current.delete(commit);
      apply();
    };
    pending.current.add(commit);
    return commit;
  }, []);

  // Leaving the page (reload, close, app switch) applies every pending change synchronously,
  // so it is rendered and persisted before the page can go away.
  useEffect(() => {
    const flush = () => {
      if (!pending.current.size) return;
      flushSync(() => [...pending.current].forEach((commit) => commit()));
    };
    const onVisibility = () => document.visibilityState === "hidden" && flush();
    window.addEventListener("pagehide", flush);
    document.addEventListener("visibilitychange", onVisibility);
    return () => {
      window.removeEventListener("pagehide", flush);
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, []);

  const launchTransfer = useCallback(
    (request: Omit<TransferRequest, "id">) => {
      counter.current += 1;
      const id = counter.current;
      // The data change must happen exactly once, even if the animation is interrupted.
      const commit = deferCommit(request.commit);
      window.setTimeout(commit, TRANSFER_COMMIT_FALLBACK_MS);
      setTransfers((items) => [...items, { ...request, commit, id }]);
    },
    [deferCommit],
  );

  const finishTransfer = useCallback((id: number) => setTransfers((items) => items.filter((item) => item.id !== id)), []);

  const openEntry = useCallback((request: EntryRequest = { mode: "create", type: "expense" }) => setEntry(request), []);
  const closeEntry = useCallback(() => setEntry(null), []);
  const replayIntro = useCallback(() => setIntroReplay(true), []);
  const endIntroReplay = useCallback(() => setIntroReplay(false), []);

  const value = useMemo(
    () => ({
      view,
      navigate,
      entry,
      openEntry,
      closeEntry,
      toasts,
      toast,
      dismissToast,
      transfers,
      launchTransfer,
      finishTransfer,
      introReplay,
      replayIntro,
      endIntroReplay,
      deferCommit,
    }),
    [view, navigate, entry, openEntry, closeEntry, toasts, toast, dismissToast, transfers, launchTransfer, finishTransfer, introReplay, replayIntro, endIntroReplay, deferCommit],
  );
  return <UIContext.Provider value={value}>{children}</UIContext.Provider>;
}

export function useUI(): UIContextValue {
  const value = useContext(UIContext);
  if (!value) throw new Error("useUI must be used inside <UIProvider>");
  return value;
}
