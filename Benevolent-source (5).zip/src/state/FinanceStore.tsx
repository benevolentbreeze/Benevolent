/**
 * The single source of truth. Every page reads the same workspace data and
 * every action flows through one reducer, then persists through the storage adapter.
 */
import { createContext, useContext, useEffect, useMemo, useReducer, useRef, type ReactNode } from "react";
import { createDefaultState, localStorageAdapter, type LoadResult, type StorageAdapter } from "../services/storageService";
import type { Goal } from "../types/goal";
import type { PersistedState, Settings, WorkspaceData, WorkspaceId } from "../types/state";
import type { Transaction } from "../types/transaction";
import { reducer, type StorageIssue } from "./financeReducer";

export type { StorageIssue } from "./financeReducer";

export interface FinanceActions {
  addTransaction(tx: Transaction, workspace?: WorkspaceId): void;
  updateTransaction(tx: Transaction, workspace?: WorkspaceId): void;
  deleteTransaction(id: string, workspace?: WorkspaceId): void;
  saveGoal(goal: Goal, opening: Transaction | null, workspace?: WorkspaceId): void;
  deleteGoal(id: string, workspace?: WorkspaceId): void;
  setPrimaryGoal(id: string): void;
  updateSettings(patch: Partial<Settings>): void;
  switchWorkspace(workspace: WorkspaceId): void;
  resetWorkspace(workspace: WorkspaceId): void;
  replaceAll(persisted: PersistedState): void;
  dismissIssue(): void;
}

interface FinanceContextValue {
  ready: boolean;
  persisted: PersistedState;
  data: WorkspaceData;
  settings: Settings;
  workspace: WorkspaceId;
  issue: StorageIssue;
  actions: FinanceActions;
}

/**
 * Loading can have side effects (a corrupted copy is moved aside), so it must run
 * exactly once per adapter — even when React StrictMode mounts effects twice.
 */
const loads = new WeakMap<StorageAdapter, Promise<LoadResult>>();
function loadOnce(adapter: StorageAdapter): Promise<LoadResult> {
  let pending = loads.get(adapter);
  if (!pending) {
    pending = adapter.load();
    loads.set(adapter, pending);
  }
  return pending;
}

const FinanceContext = createContext<FinanceContextValue | null>(null);

export function FinanceProvider({ children, adapter = localStorageAdapter }: { children: ReactNode; adapter?: StorageAdapter }) {
  const [state, dispatch] = useReducer(reducer, undefined, () => ({
    status: "loading" as const,
    persisted: createDefaultState(),
    issue: null,
  }));
  const canPersist = useRef(true);

  useEffect(() => {
    let cancelled = false;
    loadOnce(adapter).then(
      (result) => {
        if (cancelled) return;
        if (result.status === "ok") {
          dispatch({ type: "hydrate", persisted: result.state, issue: result.dropped > 0 ? "repaired" : null });
        } else if (result.status === "unavailable") {
          canPersist.current = false;
          dispatch({ type: "hydrate", persisted: createDefaultState(), issue: "unavailable" });
        } else if (result.status === "corrupted" && result.preservedKey === null) {
          // The unreadable copy could not be set aside (storage full). Never overwrite it:
          // run without saving and say so, instead of claiming it was kept.
          canPersist.current = false;
          dispatch({ type: "hydrate", persisted: createDefaultState(), issue: "save-failed" });
        } else {
          dispatch({ type: "hydrate", persisted: createDefaultState(), issue: result.status === "corrupted" ? "corrupted" : null });
        }
      },
      () => {
        // An adapter that fails to load must not leave the app on an endless loading screen.
        if (cancelled) return;
        canPersist.current = false;
        dispatch({ type: "hydrate", persisted: createDefaultState(), issue: "unavailable" });
      },
    );
    return () => {
      cancelled = true;
    };
  }, [adapter]);

  // Persist after every change once hydrated. State that just arrived from another tab
  // is not written back (that would echo between tabs).
  const lastWritten = useRef<string | null>(null);
  useEffect(() => {
    if (state.status !== "ready" || !canPersist.current) return;
    const serialized = JSON.stringify(state.persisted);
    if (serialized === lastWritten.current) return;
    lastWritten.current = serialized;
    adapter.save(state.persisted).then(
      () => dispatch({ type: "setIssue", issue: null, onlyIf: "save-failed" }),
      () => dispatch({ type: "setIssue", issue: "save-failed" }),
    );
  }, [adapter, state.persisted, state.status]);

  // Another tab changed the data: adopt it instead of overwriting it with a stale copy.
  useEffect(() => {
    if (state.status !== "ready" || !adapter.subscribe) return;
    return adapter.subscribe((incoming) => {
      lastWritten.current = JSON.stringify(incoming);
      dispatch({ type: "external", persisted: incoming });
    });
  }, [adapter, state.status]);

  const actions = useMemo<FinanceActions>(
    () => ({
      addTransaction: (tx, workspace) => dispatch({ type: "addTransaction", tx, workspace }),
      updateTransaction: (tx, workspace) => dispatch({ type: "updateTransaction", tx, workspace }),
      deleteTransaction: (id, workspace) => dispatch({ type: "deleteTransaction", id, workspace }),
      saveGoal: (goal, opening, workspace) => dispatch({ type: "saveGoal", goal, opening, workspace }),
      deleteGoal: (id, workspace) => dispatch({ type: "deleteGoal", id, workspace }),
      setPrimaryGoal: (id) => dispatch({ type: "setPrimaryGoal", id }),
      updateSettings: (patch) => dispatch({ type: "updateSettings", patch }),
      switchWorkspace: (workspace) => dispatch({ type: "switchWorkspace", workspace }),
      resetWorkspace: (workspace) => dispatch({ type: "resetWorkspace", workspace }),
      replaceAll: (persisted) => dispatch({ type: "replaceAll", persisted }),
      dismissIssue: () => dispatch({ type: "setIssue", issue: null }),
    }),
    [],
  );

  const { persisted } = state;
  const workspace = persisted.activeWorkspace;
  const data = persisted.workspaces[workspace] ?? persisted.workspaces.personal;

  const value = useMemo<FinanceContextValue>(
    () => ({ ready: state.status === "ready", persisted, data, settings: persisted.settings, workspace, issue: state.issue, actions }),
    [state.status, persisted, data, workspace, state.issue, actions],
  );

  return <FinanceContext.Provider value={value}>{children}</FinanceContext.Provider>;
}

export function useFinance(): FinanceContextValue {
  const value = useContext(FinanceContext);
  if (!value) throw new Error("useFinance must be used inside <FinanceProvider>");
  return value;
}
