import { useRef, useState } from "react";
import { EXPENSE_CATEGORIES, getCategory } from "../data/categories";
import { useFinancialSummary } from "../hooks/useFinancialSummary";
import { useReducedMotion } from "../hooks/useReducedMotion";
import {
  buildTransaction,
  combineDayAndTime,
  hasErrors,
  NOTE_MAX_LENGTH,
  validateDraft,
  type DraftErrors,
} from "../services/transactionService";
import { useFinance } from "../state/FinanceStore";
import { useUI, type EntryRequest } from "../state/UIStore";
import type { ExpenseCategoryId } from "../types/category";
import type { Transaction, TransactionType } from "../types/transaction";
import { formatLongDate, parseLocal, toDateKey } from "../utils/date";
import { formatMoney } from "../utils/money";
import AmountField from "./AmountField";
import Icon from "./Icon";
import Sheet, { useSheetClose } from "./Sheet";

const TITLES: Record<TransactionType, { create: string; edit: string }> = {
  expense: { create: "Khoản chi mới", edit: "Sửa khoản chi" },
  income: { create: "Khoản thu mới", edit: "Sửa khoản thu" },
  saving: { create: "Góp tiết kiệm", edit: "Sửa khoản tiết kiệm" },
};

export default function QuickEntry({ request }: { request: EntryRequest }) {
  const { actions, settings, data, workspace } = useFinance();
  const { summary, now, goals } = useFinancialSummary();
  const ui = useUI();
  const reduced = useReducedMotion();
  const editing: Transaction | null = request.mode === "edit" ? request.tx : null;

  const [type, setType] = useState<TransactionType>(editing?.type ?? (request.mode === "create" ? request.type : "expense"));
  const [amount, setAmount] = useState(editing?.amount ?? 0);
  const [category, setCategory] = useState<ExpenseCategoryId | null>(
    editing && editing.type === "expense" ? (editing.category as ExpenseCategoryId) : null,
  );
  const [note, setNote] = useState(editing?.note ?? "");
  const [day, setDay] = useState(editing ? editing.date.slice(0, 10) : toDateKey(now));
  const [errors, setErrors] = useState<DraftErrors>({});
  const [confirmDelete, setConfirmDelete] = useState(false);
  const amountRef = useRef<HTMLDivElement>(null);
  // One sheet, one record: a second tap while the sheet is closing must not save twice.
  const submitted = useRef(false);
  const [closing, requestClose] = useSheetClose(ui.closeEntry);

  const titles = TITLES[type];
  const totalSteps = type === "expense" ? 3 : 2;
  const step = !amount ? 1 : type === "expense" && !category ? 2 : totalSteps;
  const todayKey = toDateKey(new Date());

  const save = () => {
    if (submitted.current) return;
    const draft = {
      amount,
      type,
      category: type === "expense" ? category : type,
      note,
      date: editing ? combineDayAndTime(day, editing.date) : combineDayAndTime(day, new Date()),
      goalId: editing?.goalId,
    };
    // Money moved into a goal is limited by the balance and by what the goal still needs.
    const goalProgress = editing?.type === "saving" ? goals.find((item) => item.goal.id === editing.goalId) : undefined;
    const limits =
      type === "saving" && editing
        ? { available: Math.max(0, summary.balance) + editing.amount, goalRemaining: (goalProgress?.remaining ?? 0) + editing.amount }
        : {};
    const found = validateDraft(draft, new Date(), limits);
    setErrors(found);
    if (hasErrors(found)) return;

    if (editing && !data.transactions.some((item) => item.id === editing.id)) {
      // Deleted elsewhere (another tab) while this sheet was open.
      submitted.current = true;
      ui.toast("Giao dịch này không còn tồn tại.", "warning");
      requestClose();
      return;
    }

    const tx = buildTransaction(draft, editing ?? undefined);
    submitted.current = true;

    // Expenses are never blocked (the money was spent), but going below zero is said out loud.
    const effect = (item: Pick<Transaction, "type" | "amount">) => (item.type === "income" ? item.amount : -item.amount);
    const balanceAfter = summary.balance + effect(tx) - (editing ? effect(editing) : 0);
    const warnIfNegative = () => {
      if (summary.balance >= 0 && balanceAfter < 0) {
        window.setTimeout(() => ui.toast("Số dư đang âm. Hãy ghi lại khoản thu khi bạn nhận tiền.", "warning"), 700);
      }
    };

    if (editing) {
      actions.updateTransaction(tx, workspace);
      ui.toast("Đã cập nhật", "success");
      warnIfNegative();
      requestClose();
      return;
    }

    const label = tx.type === "income" ? "Thu nhập" : getCategory(tx.category).label;
    const confirm = () => {
      ui.toast(`Đã ghi lại · ${settings.hideAmounts ? "" : formatMoney(tx.amount) + " · "}${label}`, "success");
      warnIfNegative();
      const spentToday = summary.todayExpense + tx.amount;
      if (settings.nudges && tx.type === "expense" && tx.date.startsWith(todayKey) && summary.dailyAllowance > 0 && spentToday > summary.dailyAllowance) {
        window.setTimeout(
          () => ui.toast(`Hôm nay bạn đã chi vượt mức gợi ý ${settings.hideAmounts ? "" : formatMoney(summary.dailyAllowance) + " "}mỗi ngày. Không sao — chỉ để bạn biết.`, "warning"),
          900,
        );
      }
    };

    const origin = amountRef.current?.getBoundingClientRect();
    const canFly = !reduced && origin && (ui.view === "today" || ui.view === "history");
    if (canFly) {
      ui.launchTransfer({
        amount: tx.amount,
        direction: tx.type === "income" ? "in" : "out",
        categoryId: tx.category,
        label,
        origin,
        commit: () => {
          actions.addTransaction(tx, workspace);
          confirm();
        },
      });
    } else {
      actions.addTransaction(tx, workspace);
      confirm();
    }
    requestClose();
  };

  const remove = () => {
    if (!editing || submitted.current) return;
    if (!confirmDelete) {
      setConfirmDelete(true);
      return;
    }
    submitted.current = true;
    actions.deleteTransaction(editing.id, workspace);
    const restored = editing;
    ui.toast("Đã xoá giao dịch", "neutral", { label: "Hoàn tác", run: () => actions.addTransaction(restored, workspace) });
    requestClose();
  };

  const linkedGoal = editing?.goalId ? data.goals.find((goal) => goal.id === editing.goalId) : null;
  const selectedDate = parseLocal(day);

  return (
    <Sheet label={editing ? titles.edit : titles.create} closing={closing} onRequestClose={requestClose} className="entry-sheet">
      <form
        onSubmit={(event) => {
          event.preventDefault();
          save();
        }}
        noValidate
      >
        <div className="entry-head">
          <div>
            <span className="eyebrow">{editing ? titles.edit : titles.create}</span>
            {!editing && (
              <strong aria-label={`Bước ${step} trên ${totalSteps}`}>
                {step}/{totalSteps}
              </strong>
            )}
          </div>
          <button type="button" className="button icon-button" onClick={requestClose} aria-label="Đóng">
            <Icon name="close" />
          </button>
        </div>

        {/* An opening entry's type is part of its accounting identity, so it isn't offered for change. */}
        {type !== "saving" && !editing?.opening && (
          <div className="type-toggle" role="group" aria-label="Loại giao dịch">
            {(["expense", "income"] as const).map((option) => (
              <button
                key={option}
                type="button"
                aria-pressed={type === option}
                className={`button ${type === option ? "type-toggle--active" : ""}`}
                onClick={() => {
                  setType(option);
                  setErrors({});
                }}
              >
                <Icon name={option === "expense" ? "minus" : "plus"} size={16} />
                {option === "expense" ? "Khoản chi" : "Khoản thu"}
              </button>
            ))}
          </div>
        )}

        <div className="amount-stage">
          <AmountField
            ref={amountRef}
            label="Số tiền"
            value={amount}
            onChange={(value) => {
              setAmount(value);
              if (errors.amount) setErrors(({ amount: _removed, ...rest }) => rest);
            }}
            error={errors.amount}
            hint={amount ? `${amount.toLocaleString("vi-VN")} đồng` : "Nhập số tiền bằng bàn phím số"}
            variant="hero"
            autoFocus={!editing}
          />
        </div>

        {type === "expense" && (
          <fieldset className="category-stage">
            <legend className="eyebrow">Chọn nhóm chi tiêu</legend>
            <div className="category-grid">
              {EXPENSE_CATEGORIES.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  aria-pressed={category === item.id}
                  className={`button ${category === item.id ? "category--active" : ""}`}
                  onClick={() => {
                    setCategory(item.id);
                    if (errors.category) setErrors(({ category: _removed, ...rest }) => rest);
                  }}
                >
                  <Icon name={item.icon} />
                  <span>{item.label}</span>
                  {category === item.id && <Icon name="check" size={12} />}
                </button>
              ))}
            </div>
            {errors.category && (
              <small className="field-error" role="alert">
                {errors.category}
              </small>
            )}
          </fieldset>
        )}

        {linkedGoal && (
          <p className="entry-linked">
            <Icon name="goal" size={16} /> Khoản góp cho <strong>{linkedGoal.name}</strong>
          </p>
        )}

        <div className="entry-fields">
          <label className="note-row">
            <span className="sr-only">Ghi chú</span>
            <input
              value={note}
              maxLength={NOTE_MAX_LENGTH}
              onChange={(event) => setNote(event.target.value)}
              placeholder={type === "income" ? "Ghi chú — ví dụ: Bố mẹ gửi, số dư hiện có" : "Thêm ghi chú (không bắt buộc)"}
              enterKeyHint="done"
            />
          </label>
          <label className={`date-row ${errors.date ? "date-row--error" : ""}`}>
            <span>{selectedDate ? (day === todayKey ? "Hôm nay" : formatLongDate(selectedDate)) : "Ngày"}</span>
            <input
              type="date"
              value={day}
              max={todayKey}
              onChange={(event) => setDay(event.target.value)}
              aria-label="Ngày giao dịch"
              aria-invalid={Boolean(errors.date)}
            />
          </label>
          {errors.date && (
            <small className="field-error" role="alert">
              {errors.date}
            </small>
          )}
        </div>

        <div className="entry-actions">
          {editing && (
            <button type="button" className={`button delete-button ${confirmDelete ? "delete-button--confirm" : ""}`} onClick={remove}>
              <Icon name="trash" size={18} />
              <span>{confirmDelete ? "Chạm lần nữa để xoá" : "Xoá"}</span>
            </button>
          )}
          <button type="submit" className="button save-expense">
            <span>{editing ? "Lưu thay đổi" : type === "income" ? "Lưu khoản thu" : "Lưu khoản chi"}</span>
            <Icon name="arrow" />
          </button>
        </div>
      </form>
    </Sheet>
  );
}
