export default function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`brand ${compact ? "brand--compact" : ""}`}>
      <span className="brand-mark" aria-hidden="true">
        <i />
        <i />
        <i />
      </span>
      {compact ? <span className="sr-only">Benevolent</span> : <span className="brand-name">Benevolent</span>}
    </div>
  );
}
