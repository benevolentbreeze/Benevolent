import { useUI } from "../state/UIStore";
import Icon from "./Icon";

/** Quiet confirmations and nudges. Also the app's polite live region for screen readers. */
export default function Toasts() {
  const { toasts, dismissToast } = useUI();
  return (
    <div className="toast-stack" role="status" aria-live="polite">
      {toasts.map((toast) => (
        <div key={toast.id} className={`toast toast--${toast.tone}`}>
          <Icon name={toast.tone === "warning" ? "alert" : "check"} size={16} />
          <span>{toast.message}</span>
          {toast.action && (
            <button
              type="button"
              className="button toast-action"
              onClick={() => {
                toast.action?.run();
                dismissToast(toast.id);
              }}
            >
              {toast.action.label}
            </button>
          )}
        </div>
      ))}
    </div>
  );
}
