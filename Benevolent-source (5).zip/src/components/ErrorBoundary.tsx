import { Component, type ReactNode } from "react";

/**
 * Last line of defence: if rendering throws, show a calm recovery screen instead of a
 * blank page. Data lives in storage, so reloading loses nothing that was saved.
 */
export default class ErrorBoundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  state = { failed: false };

  static getDerivedStateFromError() {
    return { failed: true };
  }

  render() {
    if (!this.state.failed) return this.props.children;
    return (
      <main className="view inner-view" id="main">
        <div className="page-title">
          <span className="eyebrow">Benevolent</span>
          <h1>Có lỗi</h1>
          <p>Màn hình này gặp sự cố. Dữ liệu đã lưu của bạn không bị ảnh hưởng.</p>
        </div>
        <div className="empty-state">
          <strong>Tải lại để tiếp tục.</strong>
          <p>Nếu lỗi lặp lại, hãy vào Cài đặt và tạo bản sao lưu trước khi thử lại.</p>
          <div className="empty-actions">
            <button type="button" className="button pill-button" onClick={() => window.location.reload()}>
              Tải lại
            </button>
          </div>
        </div>
      </main>
    );
  }
}
