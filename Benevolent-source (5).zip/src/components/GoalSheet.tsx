import { useRef, useState } from "react";
import { useFinancialSummary } from "../hooks/useFinancialSummary";
import {
  buildOpeningEntry,
  computeGoalProgress,
  openingAmountFor,
  openingFor,
  validateGoalDraft,
  type GoalDraft,
  type GoalErrors,
} from "../services/goalService";
import { hasErrors } from "../services/transactionService";
import { useFinance } from "../state/FinanceStore";
import { useUI } from "../state/UIStore";
import type { Goal, GoalProgress } from "../types/goal";
import { addDays, addMonths, formatMonthYear, toDateKey } from "../utils/date";
import { createId } from "../utils/id";
import { formatMoney, HIDDEN_MONEY } from "../utils/money";
import AmountField from "./AmountField";
import Icon from "./Icon";
import Sheet, { useSheetClose } from "./Sheet";

export default function GoalSheet({
  progress,
  isPrimary,
  onClose,
  onSaved,
}: {
  progress: GoalProgress | null;
  isPrimary: boolean;
  onClose: () => void;
  onSaved: (goalId: string) => void;
}) {
  const { actions, data, settings, workspace } = useFinance();
  const { now, summary } = useFinancialSummary();
  const ui = useUI();
  const editing = progress?.goal ?? null;
  const contributed = progress?.contributedAmount ?? 0;
  const saved = progress?.savedAmount ?? 0;
  const [closing, requestClose] = useSheetClose(onClose);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [errors, setErrors] = useState<GoalErrors>({});
  // A new goal gets one id for the life of the sheet; a second tap can't create a twin.
  const [goalId] = useState(() => editing?.id ?? createId("goal"));
  const submitted = useRef(false);
  const [draft, setDraft] = useState<GoalDraft>(() => ({
    name: editing?.name ?? "",
    targetAmount: editing?.targetAmount ?? 0,
    savedAmount: saved,
    deadline: editing?.deadline ?? toDateKey(addMonths(now, 6)),
    monthlyContribution: editing?.monthlyContribution ?? 0,
  }));
  const update = <K extends keyof GoalDraft>(key: K, value: GoalDraft[K]) => {
    setDraft((current) => ({ ...current, [key]: value }));
    if (errors[key]) setErrors(({ [key]: _removed, ...rest }) => rest);
  };
  const context = { now, balance: summary.balance, existing: progress ?? undefined };

  const buildGoal = (): Goal => ({
    id: goalId,
    createdAt: editing?.createdAt ?? new Date().toISOString(),
    name: draft.name.trim(),
    targetAmount: draft.targetAmount,
    deadline: draft.deadline,
    monthlyContribution: draft.monthlyContribution > 0 ? draft.monthlyContribution : null,
  });
  const buildOpening = (goal: Goal) =>
    buildOpeningEntry(goal.id, openingAmountFor(draft, progress ?? undefined), openingFor(goal.id, data.transactions), new Date());

  // Live preview — the exact calculation the Goals page will show after saving.
  const previewErrors = validateGoalDraft(draft, context);
  const preview =
    !previewErrors.targetAmount && !previewErrors.deadline && !previewErrors.savedAmount
      ? (() => {
          const goal = buildGoal();
          const opening = buildOpening(goal);
          const others = data.transactions.filter((tx) => !(tx.goalId === goal.id && tx.opening));
          return computeGoalProgress(goal, opening ? [opening, ...others] : others, now);
        })()
      : null;

  const save = () => {
    if (submitted.current) return;
    const found = validateGoalDraft(draft, context);
    setErrors(found);
    if (hasErrors(found)) return;
    submitted.current = true;
    const goal = buildGoal();
    actions.saveGoal(goal, buildOpening(goal), workspace);
    ui.toast(editing ? "Đã cập nhật mục tiêu" : "Đã tạo mục tiêu", "success");
    onSaved(goal.id);
    requestClose();
  };

  const remove = () => {
    if (!editing || submitted.current) return;
    if (!confirmDelete) {
      setConfirmDelete(true);
      return;
    }
    submitted.current = true;
    actions.deleteGoal(editing.id, workspace);
    ui.toast("Đã xoá mục tiêu", "neutral");
    requestClose();
  };

  return (
    <Sheet label={editing ? "Sửa mục tiêu" : "Mục tiêu mới"} closing={closing} onRequestClose={requestClose} className="goal-sheet">
      <form
        onSubmit={(event) => {
          event.preventDefault();
          save();
        }}
        noValidate
      >
        <div className="entry-head">
          <span className="eyebrow">{editing ? "Sửa mục tiêu" : "Mục tiêu mới"}</span>
          <button type="button" className="button icon-button" onClick={requestClose} aria-label="Đóng">
            <Icon name="close" />
          </button>
        </div>

        <label className={`text-field ${errors.name ? "text-field--error" : ""}`}>
          <span>Tên mục tiêu</span>
          <input
            value={draft.name}
            onChange={(event) => update("name", event.target.value)}
            placeholder="Ví dụ: MacBook Air, Quỹ dự phòng"
            maxLength={40}
            aria-invalid={Boolean(errors.name)}
            data-autofocus={!editing || undefined}
          />
          {errors.name && (
            <small className="field-error" role="alert">
              {errors.name}
            </small>
          )}
        </label>

        <div className="field-grid">
          <AmountField label="Số tiền cần có" value={draft.targetAmount} onChange={(v) => update("targetAmount", v)} error={errors.targetAmount} />
          <AmountField
            label="Đã tiết kiệm"
            value={draft.savedAmount}
            onChange={(v) => update("savedAmount", v)}
            error={errors.savedAmount}
            hint={
              contributed > 0
                ? settings.hideAmounts
                  ? "Gồm cả số đã góp qua Benevolent"
                  : `Gồm ${formatMoney(contributed)} góp qua Benevolent`
                : "Trích từ số dư hiện có"
            }
          />
          <label className={`text-field ${errors.deadline ? "text-field--error" : ""}`}>
            <span>Hạn hoàn thành</span>
            <input
              type="date"
              value={draft.deadline}
              min={toDateKey(addDays(now, 1))}
              onChange={(event) => update("deadline", event.target.value)}
              aria-invalid={Boolean(errors.deadline)}
            />
            {errors.deadline && (
              <small className="field-error" role="alert">
                {errors.deadline}
              </small>
            )}
          </label>
          <AmountField
            label="Góp mỗi tháng (không bắt buộc)"
            value={draft.monthlyContribution}
            onChange={(v) => update("monthlyContribution", v)}
            error={errors.monthlyContribution}
          />
        </div>

        {preview && !preview.isComplete && (
          <p className="goal-preview" aria-live="polite">
            Cần khoảng <strong>{settings.hideAmounts ? HIDDEN_MONEY : formatMoney(Math.ceil(preview.requiredMonthly / 1000) * 1000)}</strong> mỗi tháng để kịp hạn.
            {preview.estimatedCompletion && (
              <>
                {" "}
                Với nhịp đã đặt, dự kiến xong vào <strong>{formatMonthYear(preview.estimatedCompletion)}</strong>.
              </>
            )}
          </p>
        )}

        <div className="entry-actions">
          {editing && (
            <button type="button" className={`button delete-button ${confirmDelete ? "delete-button--confirm" : ""}`} onClick={remove}>
              <Icon name="trash" size={18} />
              <span>
                {confirmDelete
                  ? saved > 0
                    ? settings.hideAmounts
                      ? "Xoá — tiền đã góp trở lại số dư"
                      : `Xoá — ${formatMoney(saved)} trở lại số dư`
                    : "Chạm lần nữa để xoá"
                  : "Xoá"}
              </span>
            </button>
          )}
          <button type="submit" className="button save-expense">
            <span>{editing ? "Lưu mục tiêu" : "Tạo mục tiêu"}</span>
            <Icon name="arrow" />
          </button>
        </div>
        {editing && !isPrimary && (
          <button
            type="button"
            className="button text-link goal-primary-link"
            onClick={() => {
              if (submitted.current) return;
              submitted.current = true;
              actions.setPrimaryGoal(editing.id);
              ui.toast(`${editing.name} là mục tiêu chính`, "success");
              requestClose();
            }}
          >
            Đặt làm mục tiêu chính
          </button>
        )}
      </form>
    </Sheet>
  );
}
