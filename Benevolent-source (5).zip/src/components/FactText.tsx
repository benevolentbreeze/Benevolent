import { Fragment } from "react";
import type { Fact, FactMap } from "../services/brainService";
import { formatPercent } from "../utils/money";
import { Money } from "./MoneyDisplay";

export function FactValue({ fact, compact }: { fact: Fact; compact?: boolean }) {
  switch (fact.kind) {
    case "money":
      return <Money value={fact.value} compact={compact} />;
    case "percent":
      return <>{formatPercent(fact.value, fact.value < 0.1 ? 1 : 0)}</>;
    case "trend":
      return <>{formatPercent(fact.value, 0, true)}</>;
    case "days":
      return <>{fact.value} ngày</>;
    case "count":
      return <>{fact.value}</>;
    default:
      return <>{fact.text}</>;
  }
}

/** Resolves "{factId}" tokens against computed facts. Unknown tokens render as an em dash, never a guess. */
export default function FactText({ template, facts }: { template: string; facts: FactMap }) {
  const parts = template.split(/(\{[\w:.-]+\})/g);
  return (
    <>
      {parts.map((part, index) => {
        const match = /^\{([\w:.-]+)\}$/.exec(part);
        if (!match) return <Fragment key={index}>{part}</Fragment>;
        const fact = facts[match[1]];
        return fact ? (
          <span key={index} className="fact-token">
            <FactValue fact={fact} />
          </span>
        ) : (
          <Fragment key={index}>—</Fragment>
        );
      })}
    </>
  );
}
