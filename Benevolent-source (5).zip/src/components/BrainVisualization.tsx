import type { Fact, FactMap } from "../services/brainService";
import { useFinance } from "../state/FinanceStore";
import { formatCompactMoney, formatPercent } from "../utils/money";

export type BrainPhase = "dormant" | "activating" | "relating" | "focusing" | "resolved";

/** Fixed constellation positions (percent of the surface), so the field feels like a stable map. */
const POSITIONS = [
  { x: 13, y: 16 },
  { x: 38, y: 10 },
  { x: 63, y: 16 },
  { x: 86, y: 10 },
  { x: 18, y: 48 },
  { x: 42, y: 42 },
  { x: 66, y: 48 },
  { x: 87, y: 40 },
];
/** Where relationships converge — just above the answer, so the insight "lands" in the text. */
const INSIGHT = { x: 50, y: 88 };

function shortValue(fact: Fact, hidden: boolean): string {
  if (fact.kind === "percent" || fact.kind === "trend") return formatPercent(fact.value, 0, fact.kind === "trend");
  if (fact.kind === "money") return hidden ? "₫•••" : formatCompactMoney(fact.value);
  return fact.text ?? String(fact.value);
}

interface BrainVisualizationProps {
  facts: FactMap;
  nodeIds: string[];
  focus: string[];
  phase: BrainPhase;
}

/** DATA → RELATIONSHIP → INSIGHT. Real figures as nodes; the ones an answer uses light up and connect. */
export default function BrainVisualization({ facts, nodeIds, focus, phase }: BrainVisualizationProps) {
  const { settings } = useFinance();
  const nodes = nodeIds
    .map((id, index) => ({ fact: facts[id], position: POSITIONS[index % POSITIONS.length] }))
    .filter((node) => node.fact);
  const focusSet = new Set(focus);
  const showFocus = phase === "focusing" || phase === "resolved";

  return (
    <div className={`brain-field brain-phase--${phase}`} aria-hidden="true">
      <div className="data-field" />
      <svg className="brain-links" viewBox="0 0 100 100" preserveAspectRatio="none">
        {nodes.map(({ fact, position }, index) => {
          const next = nodes[(index + 1) % nodes.length].position;
          return <line key={`mesh-${fact.id}`} className="brain-mesh" x1={position.x} y1={position.y} x2={next.x} y2={next.y} />;
        })}
        {nodes
          .filter(({ fact }) => focusSet.has(fact.id))
          .map(({ fact, position }) => (
            <line key={`link-${fact.id}`} className="brain-link" x1={position.x} y1={position.y} x2={INSIGHT.x} y2={INSIGHT.y} />
          ))}
      </svg>
      {nodes.map(({ fact, position }, index) => (
        <span
          key={fact.id}
          className={`brain-node ${showFocus ? (focusSet.has(fact.id) ? "brain-node--focus" : "brain-node--recede") : ""}`}
          style={{ left: `${position.x}%`, top: `${position.y}%`, transitionDelay: phase === "activating" ? `${index * 70}ms` : "0ms" }}
        >
          <i />
          <b>{shortValue(fact, settings.hideAmounts)}</b>
          <small>{fact.label}</small>
        </span>
      ))}
      <span className="brain-insight" style={{ left: `${INSIGHT.x}%`, top: `${INSIGHT.y}%` }} />
      <div className="analysis-sweep" />
    </div>
  );
}
