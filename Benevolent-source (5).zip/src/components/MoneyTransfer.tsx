/**
 * Signature interaction — money travels through the system.
 *
 *   amount (sheet) → leaves the balance → travels → lands in its category (or the ledger)
 *
 * One object makes the whole journey. The store is updated at the moment the
 * money passes the balance, so the number, the chart and the history react to
 * the money arriving — cause, then effect.
 */
import { useLayoutEffect, useRef, useState } from "react";
import { getCategory } from "../data/categories";
import { useUI, type TransferRequest } from "../state/UIStore";
import { useFinance } from "../state/FinanceStore";
import { formatMoney, HIDDEN_MONEY } from "../utils/money";
import Icon from "./Icon";

type Point = { x: number; y: number };

const DURATION = 1350;
const EASE = "cubic-bezier(0.22, 1, 0.36, 1)";

const centerOf = (rect: DOMRect): Point => ({ x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 });

function visibleRect(selector: string): { el: HTMLElement; point: Point } | null {
  const el = document.querySelector<HTMLElement>(selector);
  if (!el) return null;
  const rect = el.getBoundingClientRect();
  const navSpace = window.innerWidth >= 1100 ? 0 : 96;
  if (rect.width === 0 || rect.bottom < 24 || rect.top > window.innerHeight - navSpace) return null;
  return { el, point: centerOf(rect) };
}

/** Smooth path through the waypoints (quadratic curves via midpoints). */
function pathThrough(points: Point[]): string {
  if (points.length < 2) return "";
  let d = `M${points[0].x} ${points[0].y}`;
  for (let i = 1; i < points.length - 1; i += 1) {
    const mid = { x: (points[i].x + points[i + 1].x) / 2, y: (points[i].y + points[i + 1].y) / 2 };
    d += ` Q${points[i].x} ${points[i].y} ${mid.x} ${mid.y}`;
  }
  const last = points[points.length - 1];
  return `${d} T${last.x} ${last.y}`;
}

function Flight({ request }: { request: TransferRequest }) {
  const { finishTransfer } = useUI();
  const { settings } = useFinance();
  const token = useRef<HTMLDivElement>(null);
  const [trail, setTrail] = useState<{ d: string; impact: Point | null } | null>(null);

  useLayoutEffect(() => {
    const node = token.current;
    if (!node) return;
    const origin = centerOf(request.origin);
    const balance = visibleRect('[data-transfer-target="balance"]');
    const destination =
      request.direction === "out"
        ? visibleRect(`[data-transfer-target="category-${request.categoryId}"]`) ?? visibleRect('[data-transfer-target="ledger"]')
        : null;

    // Build the journey.
    const lift: Point = { x: origin.x, y: origin.y - 36 };
    const waypoints: { point: Point; offset: number; scale: number }[] = [
      { point: origin, offset: 0, scale: 0.92 },
      { point: lift, offset: 0.14, scale: 1 },
    ];
    let commitAt: number;
    if (request.direction === "in") {
      const end = balance?.point ?? { x: window.innerWidth / 2, y: 120 };
      waypoints.push({ point: end, offset: 0.62, scale: 0.7 }, { point: end, offset: 1, scale: 0.25 });
      commitAt = 0.6;
    } else if (balance && destination) {
      waypoints.push({ point: balance.point, offset: 0.4, scale: 0.78 }, { point: destination.point, offset: 0.82, scale: 0.6 }, { point: destination.point, offset: 1, scale: 0.2 });
      commitAt = 0.4;
    } else if (destination) {
      waypoints.push({ point: destination.point, offset: 0.72, scale: 0.82 }, { point: destination.point, offset: 1, scale: 0.3 });
      commitAt = 0.5;
    } else {
      const end = balance?.point ?? { x: origin.x, y: Math.max(80, origin.y - 260) };
      waypoints.push({ point: end, offset: 0.66, scale: 0.7 }, { point: end, offset: 1, scale: 0.25 });
      commitAt = 0.55;
    }

    setTrail({ d: pathThrough(waypoints.map((w) => w.point)), impact: destination?.point ?? balance?.point ?? null });

    const animation = node.animate(
      waypoints.map((w, index) => ({
        offset: w.offset,
        opacity: index === 0 ? 0 : index === waypoints.length - 1 ? 0 : 1,
        transform: `translate(${w.point.x}px, ${w.point.y}px) translate(-50%, -50%) scale(${w.scale})`,
      })),
      { duration: DURATION, easing: EASE, fill: "forwards" },
    );

    const commit = () => {
      request.commit();
      balance?.el.animate(
        [{ translate: "0 0" }, { translate: request.direction === "out" ? "0 3px" : "0 -3px" }, { translate: "0 0" }],
        { duration: 620, easing: EASE },
      );
    };
    const commitTimer = window.setTimeout(commit, DURATION * commitAt);
    const receiveTimer = window.setTimeout(() => {
      destination?.el.animate([{ scale: "1" }, { scale: "1.12" }, { scale: "1" }], { duration: 700, easing: EASE });
    }, DURATION * 0.8);

    animation.onfinish = () => finishTransfer(request.id);
    return () => {
      // An interrupted flight still commits through the store's fallback timer.
      window.clearTimeout(commitTimer);
      window.clearTimeout(receiveTimer);
      animation.cancel();
    };
  }, [request, finishTransfer]);

  const category = getCategory(request.categoryId);
  return (
    <>
      {trail && (
        <svg className="transfer-trail" width="100%" height="100%" aria-hidden="true">
          <path d={trail.d} />
        </svg>
      )}
      {trail?.impact && request.direction === "out" && (
        <div className="transfer-impact" style={{ left: trail.impact.x, top: trail.impact.y }} aria-hidden="true">
          <i />
          <i />
          <i />
        </div>
      )}
      <div ref={token} className={`transfer-token transfer-token--${request.direction}`} aria-hidden="true">
        <strong>{settings.hideAmounts ? HIDDEN_MONEY : `${request.direction === "out" ? "−" : "+"}${formatMoney(request.amount)}`}</strong>
        <span>
          <Icon name={category.icon} size={16} />
          {request.label}
        </span>
      </div>
    </>
  );
}

export default function MoneyTransferLayer() {
  const { transfers } = useUI();
  if (!transfers.length) return null;
  return (
    <div className="money-transfer">
      {transfers.map((request) => (
        <Flight key={request.id} request={request} />
      ))}
    </div>
  );
}
