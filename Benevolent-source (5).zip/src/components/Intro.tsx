import { useEffect } from "react";
import Brand from "./Brand";

const DURATION_MS = 7200;
/** The still version stays until dismissed, or this long. */
const STILL_DURATION_MS = 6000;

/**
 * First-visit intro: darkness → a point of light → its trajectory → the data
 * field → the user's own numbers resolve → Benevolent. Skippable at any moment.
 */
export default function Intro({ figures, onDone, still = false }: { figures: string[]; onDone: () => void; still?: boolean }) {
  useEffect(() => {
    const timer = window.setTimeout(onDone, still ? STILL_DURATION_MS : DURATION_MS);
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape" || event.key === "Enter" || event.key === " ") onDone();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      window.clearTimeout(timer);
      window.removeEventListener("keydown", onKey);
    };
  }, [onDone, still]);

  return (
    <div className={`intro ${still ? "intro--still" : ""}`} onClick={onDone} role="dialog" aria-label="Phần mở đầu Benevolent">
      <div className="intro-grain" aria-hidden="true" />
      <div className="intro-dark-label" aria-hidden="true">
        Một điểm sáng.
      </div>
      <div className="trajectory" aria-hidden="true">
        <span className="light-point" />
        <svg viewBox="0 0 1200 420" preserveAspectRatio="none">
          <defs>
            <linearGradient id="intro-line" x1="0" x2="1">
              <stop offset="0" stopColor="#6f8375" stopOpacity="0" />
              <stop offset=".4" stopColor="#b9d8bd" />
              <stop offset="1" stopColor="#f0f1e8" />
            </linearGradient>
          </defs>
          <path d="M0 340 C180 335 220 290 365 305 S565 340 670 230 S850 70 1200 110" />
        </svg>
        <div className="intro-grid" />
        <div className="intro-data">
          {figures.slice(0, 5).map((figure, index) => (
            <span key={index}>{figure}</span>
          ))}
        </div>
      </div>
      <div className="intro-interface" aria-hidden="true">
        <i />
        <i />
        <i />
        <i />
        <i />
      </div>
      <div className="intro-statement" aria-hidden="true">
        <span>Tiền đang chuyển động.</span>
        <strong>
          Tiền bạc.
          <br />
          <em>Rõ ràng.</em>
        </strong>
      </div>
      <div className="intro-brand">
        <Brand />
        <span className="intro-sub">Tài chính, theo cách nhẹ nhàng hơn.</span>
      </div>
      <button
        type="button"
        className="button skip"
        onClick={(event) => {
          event.stopPropagation();
          onDone();
        }}
      >
        Bỏ qua
      </button>
    </div>
  );
}
