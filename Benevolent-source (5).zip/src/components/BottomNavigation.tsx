import type { View } from "../hooks/useHashView";
import Brand from "./Brand";
import Icon, { type IconName } from "./Icon";

const NAV_ITEMS: { id: View; label: string; icon: IconName }[] = [
  { id: "today", label: "Hôm nay", icon: "home" },
  { id: "history", label: "Lịch sử", icon: "history" },
  { id: "brain", label: "Brain", icon: "brain" },
  { id: "goals", label: "Mục tiêu", icon: "goal" },
  { id: "settings", label: "Cài đặt", icon: "settings" },
];

export default function BottomNavigation({ active, onChange }: { active: View; onChange: (view: View) => void }) {
  const items = NAV_ITEMS.map((item) => ({ ...item, current: active === item.id }));
  return (
    <>
      <nav className="desktop-nav" aria-label="Điều hướng chính">
        <Brand compact />
        <div className="desktop-nav-items">
          {items.map((item) => (
            <button
              key={item.id}
              type="button"
              className={`button ${item.current ? "nav-active" : ""}`}
              onClick={() => onChange(item.id)}
              aria-current={item.current ? "page" : undefined}
            >
              <Icon name={item.icon} />
              <span>{item.label}</span>
            </button>
          ))}
        </div>
        <span className="nav-signature" aria-hidden="true">
          BV
          <br />
          {String(new Date().getFullYear()).slice(2)}
        </span>
      </nav>
      <nav className="mobile-nav" aria-label="Điều hướng chính">
        {items.map((item) => (
          <button
            key={item.id}
            type="button"
            className={`button ${item.current ? "nav-active" : ""}`}
            onClick={() => onChange(item.id)}
            aria-current={item.current ? "page" : undefined}
          >
            <span aria-hidden="true">
              <Icon name={item.icon} />
            </span>
            <small>{item.label}</small>
          </button>
        ))}
      </nav>
    </>
  );
}
