import { forwardRef, useId } from "react";
import { formatAmountInput, parseAmountInput } from "../utils/money";

interface AmountFieldProps {
  label: string;
  value: number;
  onChange: (value: number) => void;
  error?: string;
  hint?: string;
  variant?: "hero" | "inline";
  autoFocus?: boolean;
  placeholder?: string;
}

/** Numeric money input: opens the numeric keypad, groups digits as you type (35.000). */
const AmountField = forwardRef<HTMLDivElement, AmountFieldProps>(function AmountField(
  { label, value, onChange, error, hint, variant = "inline", autoFocus, placeholder = "0" },
  ref,
) {
  const id = useId();
  const describedBy = error ? `${id}-error` : hint ? `${id}-hint` : undefined;
  const display = formatAmountInput(value);
  return (
    <div className={`amount-field amount-field--${variant} ${error ? "amount-field--error" : ""}`}>
      <label htmlFor={id}>{label}</label>
      <div
        className="amount-input"
        ref={ref}
        data-length={display.length}
        style={{ "--chars": Math.max(1, display.length || placeholder.length) } as React.CSSProperties}
      >
        <b aria-hidden="true">₫</b>
        <input
          id={id}
          inputMode="numeric"
          enterKeyHint="next"
          autoComplete="off"
          placeholder={placeholder}
          value={display}
          onChange={(event) => onChange(parseAmountInput(event.target.value))}
          aria-invalid={Boolean(error)}
          aria-describedby={describedBy}
          {...(autoFocus ? { "data-autofocus": true } : {})}
        />
      </div>
      {error ? (
        <small id={`${id}-error`} className="field-error" role="alert">
          {error}
        </small>
      ) : hint ? (
        <small id={`${id}-hint`}>{hint}</small>
      ) : null}
    </div>
  );
});

export default AmountField;
