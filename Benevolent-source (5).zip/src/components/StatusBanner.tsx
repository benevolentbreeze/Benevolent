import { useFinance } from "../state/FinanceStore";
import { useUI } from "../state/UIStore";
import Icon from "./Icon";

const MESSAGES = {
  unavailable: {
    title: "Không thể lưu trên thiết bị này",
    body: "Trình duyệt đang chặn bộ nhớ cục bộ (có thể do chế độ ẩn danh). Dữ liệu sẽ mất khi tải lại trang — hãy xuất bản sao lưu trong Cài đặt.",
  },
  "save-failed": {
    title: "Lần lưu gần nhất chưa thành công",
    body: "Bộ nhớ của trình duyệt có thể đã đầy. Thay đổi vẫn hiển thị, nhưng hãy xuất bản sao lưu để giữ an toàn.",
  },
  corrupted: {
    title: "Dữ liệu cũ không đọc được",
    body: "Benevolent đã giữ lại bản lỗi trên thiết bị và bắt đầu lại sạch sẽ. Nếu có bản sao lưu, bạn có thể khôi phục trong Cài đặt.",
  },
  repaired: {
    title: "Đã sửa dữ liệu bị lỗi",
    body: "Một vài bản ghi không hợp lệ đã được bỏ qua. Phần còn lại vẫn nguyên vẹn.",
  },
} as const;

export default function StatusBanner() {
  const { issue, actions, workspace } = useFinance();
  const { view, toast } = useUI();

  if (issue) {
    const message = MESSAGES[issue];
    return (
      <div className="status-banner status-banner--warning" role="alert">
        <Icon name="alert" size={18} />
        <div>
          <strong>{message.title}</strong>
          <p>{message.body}</p>
        </div>
        <button type="button" className="button status-dismiss" onClick={actions.dismissIssue} aria-label="Đóng thông báo">
          <Icon name="close" size={16} />
        </button>
      </div>
    );
  }

  if (workspace === "demo" && view === "today") {
    return (
      <div className="status-banner status-banner--demo">
        <span className="demo-pill">Dữ liệu mẫu</span>
        <p>Bạn đang xem dữ liệu minh hoạ. Số liệu không phải của bạn.</p>
        <button
          type="button"
          className="button status-link"
          onClick={() => {
            actions.switchWorkspace("personal");
            toast("Đã chuyển sang dữ liệu của bạn. Có thể mở lại dữ liệu mẫu trong Cài đặt.", "success");
          }}
        >
          Dùng dữ liệu của tôi
        </button>
      </div>
    );
  }
  return null;
}
