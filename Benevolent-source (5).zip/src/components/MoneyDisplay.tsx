import { useAnimatedNumber } from "../hooks/useAnimatedValue";
import { useReducedMotion } from "../hooks/useReducedMotion";
import { useFinance } from "../state/FinanceStore";
import { formatCompactMoney, formatMoney, HIDDEN_MONEY } from "../utils/money";

interface MoneyProps {
  value: number;
  compact?: boolean;
  signed?: boolean;
  /** Render as an outflow ("−₫45.000"). */
  negative?: boolean;
  className?: string;
}

function HiddenMoney({ className }: { className?: string }) {
  return (
    <span className={`money money--hidden ${className ?? ""}`}>
      <span aria-hidden="true">{HIDDEN_MONEY}</span>
      <span className="sr-only">Số tiền đã ẩn</span>
    </span>
  );
}

/** Every amount in the UI goes through here, so privacy mode covers the whole app. */
export function Money({ value, compact, signed, negative, className }: MoneyProps) {
  const { settings } = useFinance();
  if (settings.hideAmounts) return <HiddenMoney className={className} />;
  const shown = negative ? -Math.abs(value) : value;
  return <span className={`money ${className ?? ""}`}>{compact ? formatCompactMoney(shown) : formatMoney(shown, { signed })}</span>;
}

/** A balance-style number that travels from its old value to the new one. */
export function AnimatedMoney({ value, className }: { value: number; className?: string }) {
  const { settings } = useFinance();
  const reduced = useReducedMotion();
  const { display, direction } = useAnimatedNumber(value, { disabled: reduced || settings.hideAmounts });
  if (settings.hideAmounts) return <HiddenMoney className={className} />;
  return (
    <span className={`money ${direction ? `money-moving money-moving--${direction}` : ""} ${className ?? ""}`}>
      <span aria-hidden="true">{formatMoney(display)}</span>
      <span className="sr-only">{formatMoney(value)}</span>
    </span>
  );
}
