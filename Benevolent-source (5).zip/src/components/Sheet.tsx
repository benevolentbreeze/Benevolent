import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { useBackDismiss } from "../hooks/useBackDismiss";
import { useReducedMotion } from "../hooks/useReducedMotion";

const EXIT_MS = 240;
let openSheets = 0;

/** Lets a sheet play its exit before it unmounts. */
export function useSheetClose(onClosed: () => void): [boolean, () => void] {
  const [closing, setClosing] = useState(false);
  const reduced = useReducedMotion();
  const closed = useRef(onClosed);
  closed.current = onClosed;
  const timer = useRef<number | null>(null);
  const requestClose = useCallback(() => {
    if (timer.current !== null) return;
    setClosing(true);
    timer.current = window.setTimeout(() => closed.current(), reduced ? 0 : EXIT_MS);
  }, [reduced]);
  // If this sheet is replaced before its exit finishes, its close must not hit the next sheet.
  useEffect(
    () => () => {
      if (timer.current !== null) window.clearTimeout(timer.current);
    },
    [],
  );
  return [closing, requestClose];
}

const FOCUSABLE = 'button:not([disabled]), input:not([disabled]), select, textarea, [href], [tabindex]:not([tabindex="-1"])';

interface SheetProps {
  label: string;
  closing: boolean;
  onRequestClose: () => void;
  children: ReactNode;
  className?: string;
}

/** Accessible bottom sheet: dialog semantics, focus trap, Escape and system back close it. */
export default function Sheet({ label, closing, onRequestClose, children, className = "" }: SheetProps) {
  const panel = useRef<HTMLElement>(null);
  useBackDismiss(!closing, onRequestClose);

  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    const node = panel.current;
    const preferred = node?.querySelector<HTMLElement>("[data-autofocus]") ?? node?.querySelector<HTMLElement>(FOCUSABLE);
    preferred?.focus({ preventScroll: true });
    document.body.classList.add("sheet-open");
    // Hide the page behind the dialog from assistive tech and keyboard, not just visually.
    const root = document.getElementById("root");
    root?.setAttribute("inert", "");
    openSheets += 1;
    return () => {
      openSheets -= 1;
      if (openSheets === 0) {
        root?.removeAttribute("inert");
        document.body.classList.remove("sheet-open");
      }
      previous?.focus?.({ preventScroll: true });
    };
  }, []);

  const onKeyDown = (event: React.KeyboardEvent) => {
    if (event.key === "Escape") {
      event.stopPropagation();
      onRequestClose();
      return;
    }
    if (event.key !== "Tab" || !panel.current) return;
    const items = [...panel.current.querySelectorAll<HTMLElement>(FOCUSABLE)].filter((el) => el.offsetParent !== null);
    if (!items.length) return;
    const first = items[0];
    const last = items[items.length - 1];
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  };

  // Portalled to <body> so no page-level stacking context (view transitions) can trap it under the navigation.
  return createPortal(
    <div
      className={`sheet-backdrop ${closing ? "sheet-backdrop--closing" : ""}`}
      onMouseDown={(event) => event.target === event.currentTarget && onRequestClose()}
      onKeyDown={onKeyDown}
    >
      <section ref={panel} className={`sheet ${className} ${closing ? "sheet--closing" : ""}`} role="dialog" aria-modal="true" aria-label={label}>
        <div className="sheet-handle" aria-hidden="true" />
        {children}
      </section>
    </div>,
    document.body,
  );
}
