import { useState } from "react";
import type { GoalProgress } from "../types/goal";
import { formatShortDate, parseLocal } from "../utils/date";

export type JourneyPhase = "idle" | "entering" | "advancing";

const MILESTONES = [25, 50, 75];

/**
 * The goal horizon: the line is the distance to the goal, the light is you.
 * A contribution enters from below, the light travels, milestones respond.
 */
export default function GoalVisualization({
  progress,
  phase,
  previousPercent,
}: {
  progress: GoalProgress;
  phase: JourneyPhase;
  /** Percent before the latest contribution — milestones crossed since then respond. */
  previousPercent: number;
}) {
  const [imageFailed, setImageFailed] = useState(false);
  const deadline = parseLocal(progress.goal.deadline);
  const percent = progress.percent;
  const nowLabelHidden = percent < 14 || percent > 84;

  return (
    <div
      className={`goal-horizon goal-horizon--${phase} ${imageFailed ? "goal-horizon--no-image" : ""}`}
      style={{ "--progress": `${percent}%` } as React.CSSProperties}
      role="img"
      aria-label={`Tiến độ ${progress.goal.name}: ${Math.round(percent)}%`}
    >
      {!imageFailed && (
        <img
          className="goal-city"
          src="https://images.unsplash.com/photo-1740030325812-53c15c9f48d6?auto=format&fit=crop&w=1200&q=76"
          srcSet="https://images.unsplash.com/photo-1740030325812-53c15c9f48d6?auto=format&fit=crop&w=640&q=72 640w, https://images.unsplash.com/photo-1740030325812-53c15c9f48d6?auto=format&fit=crop&w=1200&q=76 1200w"
          sizes="(max-width: 767px) 100vw, 900px"
          loading="lazy"
          referrerPolicy="no-referrer"
          alt=""
          onError={() => setImageFailed(true)}
        />
      )}
      <div className="horizon-glow" />
      <div className="horizon-line">
        <span />
      </div>
      {MILESTONES.map((mark) => {
        const reached = percent >= mark;
        const justCrossed = reached && previousPercent < mark && phase !== "idle";
        return (
          <i
            key={mark}
            className={`horizon-tick ${reached ? "horizon-tick--reached" : ""} ${justCrossed ? "horizon-tick--crossed" : ""}`}
            style={{ left: `calc(8% + ${mark * 0.84}%)` }}
          />
        );
      })}
      <div className="journey-light" />
      <div className="journey-particles">
        <i />
        <i />
        <i />
        <i />
        <i />
      </div>
      <div className="milestone milestone--start">
        <i />
        <span>Bắt đầu</span>
      </div>
      <div className={`milestone milestone--now ${nowLabelHidden ? "milestone--quiet" : ""}`}>
        <i />
        <span>Hiện tại</span>
      </div>
      <div className="milestone milestone--end">
        <i />
        <span>{progress.isComplete ? "Đã đạt" : deadline ? formatShortDate(deadline) : "Đích"}</span>
      </div>
    </div>
  );
}
