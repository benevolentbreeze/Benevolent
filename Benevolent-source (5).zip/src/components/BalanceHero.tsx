import { useFinancialSummary } from "../hooks/useFinancialSummary";
import { useFinance } from "../state/FinanceStore";
import { formatWeekdayShort } from "../utils/date";
import { formatMoney } from "../utils/money";
import FinancialChart from "./FinancialChart";
import Icon from "./Icon";
import { AnimatedMoney, Money } from "./MoneyDisplay";

export default function BalanceHero() {
  const { settings, actions } = useFinance();
  const { summary } = useFinancialSummary();
  const hidden = settings.hideAmounts;
  const lengthClass = formatMoney(summary.balance).length > 11 ? "balance-value--long" : "";

  let guide: React.ReactNode;
  if (summary.transactionCount === 0) {
    guide = <>Ghi số dư hiện có hoặc khoản thu đầu tiên để bắt đầu.</>;
  } else if (summary.balance <= 0) {
    guide = <>Số dư đã hết — ghi lại khoản thu khi bạn nhận tiền.</>;
  } else if (summary.safeToSpend <= 0) {
    guide = <>Phần còn lại đang được giữ cho mục tiêu tháng này.</>;
  } else {
    guide = (
      <>
        Bạn còn có thể chi khoảng{" "}
        <strong>
          <Money value={summary.dailyAllowance} />
          /ngày
        </strong>
      </>
    );
  }

  return (
    <section className="balance-hero" aria-labelledby="balance-label" data-camera-stop="balance">
      <div className="balance-topline">
        <span id="balance-label">Số dư khả dụng</span>
        <button
          type="button"
          className="button privacy-toggle"
          aria-pressed={hidden}
          aria-label={hidden ? "Hiện số tiền" : "Ẩn số tiền"}
          onClick={() => actions.updateSettings({ hideAmounts: !hidden })}
        >
          <Icon name={hidden ? "eyeOff" : "eye"} size={18} />
        </button>
      </div>
      <div className={`balance-value ${lengthClass}`} data-transfer-target="balance">
        <AnimatedMoney value={summary.balance} />
      </div>
      <p className="daily-guide" aria-live="polite">
        <span className="pulse-dot" aria-hidden="true" />
        <span>{guide}</span>
      </p>
      <FinancialChart
        title="7 ngày qua"
        values={summary.last7.map((point) => point.expense)}
        labels={summary.last7.map((point, index) => (index === 6 ? "Nay" : formatWeekdayShort(point.date)))}
        total={summary.last7Total}
      />
    </section>
  );
}
