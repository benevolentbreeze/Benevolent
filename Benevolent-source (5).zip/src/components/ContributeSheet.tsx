import { useRef, useState } from "react";
import { useFinancialSummary } from "../hooks/useFinancialSummary";
import { useFinance } from "../state/FinanceStore";
import type { GoalProgress } from "../types/goal";
import { formatCompactMoney, formatMoney } from "../utils/money";
import AmountField from "./AmountField";
import Icon from "./Icon";
import Sheet, { useSheetClose } from "./Sheet";

export default function ContributeSheet({
  progress,
  onClose,
  onConfirm,
}: {
  progress: GoalProgress;
  onClose: () => void;
  onConfirm: (amount: number) => void;
}) {
  const { summary } = useFinancialSummary();
  const { settings } = useFinance();
  const money = (value: number) => (settings.hideAmounts ? "" : ` (${formatMoney(Math.max(0, value))})`);
  const [closing, requestClose] = useSheetClose(onClose);
  // The most that can really be contributed now: limited by the balance and by what the goal still needs.
  const maxContribution = Math.max(0, Math.min(progress.remaining, summary.balance));
  const suggested = Math.min(maxContribution, progress.commitmentRemainingThisMonth || progress.goal.monthlyContribution || 500_000);
  const [amount, setAmount] = useState(suggested);
  const [error, setError] = useState<string | undefined>(() =>
    maxContribution === 0 ? `Số dư hiện có${money(summary.balance)} không đủ để góp` : undefined,
  );
  const confirmed = useRef(false);
  const chips = [200_000, 500_000, 1_000_000].filter((value) => value <= maxContribution);

  const submit = () => {
    if (amount <= 0) return setError(maxContribution === 0 ? `Số dư hiện có${money(summary.balance)} không đủ để góp` : "Nhập số tiền lớn hơn ₫0");
    if (amount > summary.balance) return setError(`Số dư hiện có${money(summary.balance)} không đủ`);
    if (amount > progress.remaining) return setError(`Số này vượt phần còn thiếu${money(progress.remaining)}`);
    if (confirmed.current) return;
    confirmed.current = true;
    onConfirm(amount);
    requestClose();
  };

  return (
    <Sheet label={`Góp vào ${progress.goal.name}`} closing={closing} onRequestClose={requestClose} className="contribute-sheet">
      <form
        onSubmit={(event) => {
          event.preventDefault();
          submit();
        }}
        noValidate
      >
        <div className="entry-head">
          <span className="eyebrow">Góp vào {progress.goal.name}</span>
          <button type="button" className="button icon-button" onClick={requestClose} aria-label="Đóng">
            <Icon name="close" />
          </button>
        </div>
        <div className="amount-stage">
          <AmountField
            label="Số tiền góp"
            value={amount}
            onChange={(value) => {
              setAmount(value);
              setError(undefined);
            }}
            error={error}
            hint={`Lấy từ số dư${settings.hideAmounts ? "" : ` · còn thiếu ${formatMoney(progress.remaining)}`}`}
            variant="hero"
            autoFocus
          />
        </div>
        {maxContribution > 0 && (chips.length > 0 || progress.remaining <= maxContribution) && (
          <div className="quick-chips" role="group" aria-label="Số tiền gợi ý">
            {chips.map((value) => (
              <button
                key={value}
                type="button"
                className={`button filter-chip ${amount === value ? "filter-chip--active" : ""}`}
                aria-pressed={amount === value}
                onClick={() => {
                  setAmount(value);
                  setError(undefined);
                }}
              >
                {formatCompactMoney(value)}
              </button>
            ))}
            {progress.remaining <= maxContribution && (
              <button
                type="button"
                className={`button filter-chip ${amount === progress.remaining ? "filter-chip--active" : ""}`}
                aria-pressed={amount === progress.remaining}
                onClick={() => {
                  setAmount(progress.remaining);
                  setError(undefined);
                }}
              >
                Phần còn lại
              </button>
            )}
          </div>
        )}
        <button type="submit" className="button save-expense contribute-submit">
          <span>Góp {amount > 0 ? formatMoney(amount) : ""}</span>
          <Icon name="arrow" />
        </button>
      </form>
    </Sheet>
  );
}
