import { useEffect, useState } from "react";
import { EXPENSE_CATEGORIES } from "../data/categories";
import { useFinancialSummary } from "../hooks/useFinancialSummary";
import { useUI } from "../state/UIStore";
import type { ExpenseCategoryId } from "../types/category";
import { formatMonth, formatWeekdayShort } from "../utils/date";
import { formatPercent } from "../utils/money";
import Icon from "./Icon";
import { Money } from "./MoneyDisplay";

/** Node size follows rank, so the biggest spend is always the biggest shape. */
const SLOTS = ["large", "medium-a", "medium-b", "small"] as const;

export default function CategoryEcosystem() {
  const { summary } = useFinancialSummary();
  const { transfers } = useUI();
  const nodes = summary.categories.filter((c) => c.amount > 0).slice(0, 4);
  const [focused, setFocused] = useState<ExpenseCategoryId | null>(null);
  const incoming = transfers[transfers.length - 1]?.categoryId;

  const nodeIds = nodes.map((node) => node.id).join(",");

  // Money on its way to a category pulls focus to it.
  useEffect(() => {
    if (incoming && nodeIds.split(",").includes(incoming)) setFocused(incoming as ExpenseCategoryId);
  }, [incoming, nodeIds]);

  const active = summary.categories.find((c) => c.id === focused) ?? summary.topCategory ?? nodes[0];
  const hasSpending = summary.monthExpense > 0;
  const series = active ? summary.categoryLast7[active.id] : [];
  const seriesMax = Math.max(1, ...series);
  const segments = summary.categories.filter((c) => c.amount > 0);

  return (
    <section className={`category-ecosystem ${incoming ? "category-ecosystem--receive" : ""}`} aria-labelledby="ecosystem-title" data-camera-stop="spending">
      <div className="section-heading">
        <div>
          <span className="eyebrow">Hệ sinh thái chi tiêu · {formatMonth(summary.now)}</span>
          <h2 id="ecosystem-title">Tiền đi đâu?</h2>
        </div>
        <span className="category-total">
          <Money value={summary.monthExpense} />
        </span>
      </div>

      {!hasSpending ? (
        <div className="category-field category-field--empty">
          <div className="category-orbit" aria-hidden="true">
            <i />
            <i />
            <i />
          </div>
          <p>Chưa có khoản chi nào trong {formatMonth(summary.now).toLowerCase()}. Khi bạn ghi lại, các nhóm chi tiêu sẽ xuất hiện ở đây theo tỷ trọng.</p>
        </div>
      ) : (
        <>
          <div className={`category-field ${focused ? "category-field--focused" : ""}`}>
            <div className="category-orbit" aria-hidden="true">
              <i />
              <i />
              <i />
            </div>
            {nodes.map((item, index) => {
              const definition = EXPENSE_CATEGORIES.find((c) => c.id === item.id)!;
              const isActive = active?.id === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  data-transfer-target={`category-${item.id}`}
                  className={`button category-node category-node--${SLOTS[index]} ${isActive ? "category-node--active" : "category-node--recede"}`}
                  onClick={() => setFocused(item.id)}
                  aria-pressed={isActive}
                >
                  <Icon name={definition.icon} />
                  <span>{item.label}</span>
                  <strong>
                    <Money value={item.amount} compact />
                  </strong>
                  <small>{formatPercent(item.share)}</small>
                </button>
              );
            })}
          </div>

          {active && (
            <div className="category-focus" key={active.id} aria-live="polite">
              <p className="category-caption">
                <span aria-hidden="true" />
                {active.label} đang chiếm <strong>{formatPercent(active.share, 1)}</strong> tổng chi tiêu tháng này.
              </p>
              <div className="share-bar" aria-hidden="true">
                {segments.map((segment) => (
                  <i
                    key={segment.id}
                    className={segment.id === active.id ? "share-bar--active" : ""}
                    style={{ flexGrow: segment.amount }}
                  />
                ))}
              </div>
              <div className="focus-detail">
                <dl>
                  <div>
                    <dt>Số khoản</dt>
                    <dd>{active.count}</dd>
                  </div>
                  <div>
                    <dt>Trung bình</dt>
                    <dd>
                      <Money value={active.count ? active.amount / active.count : 0} compact />
                    </dd>
                  </div>
                  <div>
                    <dt>Tháng trước</dt>
                    <dd>
                      <Money value={active.lastMonthAmount} compact />
                    </dd>
                  </div>
                </dl>
                <div className="focus-bars" role="img" aria-label={`${active.label} trong 7 ngày qua`}>
                  {series.map((value, index) => (
                    <span key={summary.last7[index].key}>
                      <i style={{ transform: `scaleY(${Math.max(0.04, value / seriesMax)})` }} className={value ? "" : "focus-bars--zero"} />
                      <small>{index === 6 ? "Nay" : formatWeekdayShort(summary.last7[index].date)}</small>
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </section>
  );
}
