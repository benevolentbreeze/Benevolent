import { getCategory } from "../data/categories";
import { describeTransaction } from "../services/transactionService";
import type { Goal } from "../types/goal";
import type { Transaction } from "../types/transaction";
import { formatTime, parseLocal } from "../utils/date";
import Icon from "./Icon";
import { Money } from "./MoneyDisplay";

const FRESH_MS = 2500;

interface TransactionRowProps {
  tx: Transaction;
  goals: Goal[];
  onOpen?: (tx: Transaction) => void;
  dimmed?: boolean;
}

export default function TransactionRow({ tx, goals, onOpen, dimmed }: TransactionRowProps) {
  const { title, subtitle } = describeTransaction(tx, goals);
  const date = parseLocal(tx.date);
  const fresh = Date.now() - Date.parse(tx.createdAt) < FRESH_MS;
  const meta = [date ? formatTime(date) : "", subtitle].filter(Boolean).join(" · ");
  const category = getCategory(tx.category);
  const content = (
    <>
      <span className={`transaction-icon transaction-icon--${tx.type}`}>
        <Icon name={category.icon} />
      </span>
      <span className="transaction-copy">
        <strong>{title}</strong>
        <small>{meta}</small>
      </span>
      <strong className={`transaction-amount transaction-amount--${tx.type}`}>
        <Money value={tx.amount} signed={tx.type === "income"} negative={tx.type !== "income"} />
      </strong>
    </>
  );
  const className = `transaction ${fresh ? "transaction--fresh" : ""} ${dimmed ? "transaction--dimmed" : ""}`;
  return onOpen ? (
    <button type="button" className={`button ${className}`} onClick={() => onOpen(tx)}>
      {content}
      <span className="sr-only">Sửa giao dịch</span>
    </button>
  ) : (
    <div className={className}>{content}</div>
  );
}
