import { useId } from "react";
import { useAnimatedSeries } from "../hooks/useAnimatedValue";
import { useReducedMotion } from "../hooks/useReducedMotion";
import { useFinance } from "../state/FinanceStore";
import { formatMoney } from "../utils/money";
import { Money } from "./MoneyDisplay";

const WIDTH = 620;
const HEIGHT = 130;
const TOP = 16;
const BOTTOM = 118;

function toPoints(values: number[], max: number) {
  const step = values.length > 1 ? WIDTH / (values.length - 1) : WIDTH;
  return values.map((value, index) => ({ x: index * step, y: BOTTOM - (value / max) * (BOTTOM - TOP) }));
}

/** Catmull-Rom → cubic Bézier, clamped so the curve never dips below zero. */
function smoothPath(points: { x: number; y: number }[]): string {
  if (!points.length) return "";
  let d = `M${points[0].x.toFixed(1)} ${points[0].y.toFixed(1)}`;
  for (let i = 0; i < points.length - 1; i += 1) {
    const p0 = points[i - 1] ?? points[i];
    const p1 = points[i];
    const p2 = points[i + 1];
    const p3 = points[i + 2] ?? p2;
    const c1 = { x: p1.x + (p2.x - p0.x) / 6, y: Math.min(BOTTOM, p1.y + (p2.y - p0.y) / 6) };
    const c2 = { x: p2.x - (p3.x - p1.x) / 6, y: Math.min(BOTTOM, p2.y - (p3.y - p1.y) / 6) };
    d += ` C${c1.x.toFixed(1)} ${c1.y.toFixed(1)} ${c2.x.toFixed(1)} ${c2.y.toFixed(1)} ${p2.x.toFixed(1)} ${p2.y.toFixed(1)}`;
  }
  return d;
}

interface FinancialChartProps {
  title: string;
  values: number[];
  labels: string[];
  total: number;
}

export default function FinancialChart({ title, values, labels, total }: FinancialChartProps) {
  const gradientId = useId().replace(/:/g, "");
  const reduced = useReducedMotion();
  const { settings } = useFinance();
  const max = Math.max(1, ...values) * 1.08;
  const animated = useAnimatedSeries(values, { disabled: reduced });
  const points = toPoints(animated, max);
  const line = smoothPath(points);
  const last = points[points.length - 1];
  const empty = values.every((value) => value === 0);

  const description = settings.hideAmounts
    ? `${title}: số tiền đã ẩn`
    : `${title}: ${labels.map((label, index) => `${label} ${formatMoney(values[index])}`).join(", ")}`;

  return (
    <figure className={`sparkline ${empty ? "sparkline--empty" : ""}`}>
      <figcaption className="chart-label">
        <span>{title}</span>
        <Money value={total} />
      </figcaption>
      <div className="chart-plot">
        <svg viewBox={`0 0 ${WIDTH} ${HEIGHT}`} preserveAspectRatio="none" role="img" aria-label={description}>
          <defs>
            <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="#64816c" stopOpacity=".28" />
              <stop offset="1" stopColor="#64816c" stopOpacity="0" />
            </linearGradient>
          </defs>
          <path className="chart-area" d={`${line} V${HEIGHT} H0Z`} fill={`url(#${gradientId})`} />
          <path className="chart-line" d={line} />
        </svg>
        {last && <span className="chart-now" style={{ top: `${(last.y / HEIGHT) * 100}%` }} aria-hidden="true" />}
      </div>
      <div className="chart-days" aria-hidden="true">
        {labels.map((label, index) => (
          <span key={`${label}-${index}`} className={index === labels.length - 1 ? "chart-days--today" : ""}>
            {label}
          </span>
        ))}
      </div>
      {empty && <p className="chart-empty">Chưa có khoản chi nào trong 7 ngày qua.</p>}
    </figure>
  );
}
