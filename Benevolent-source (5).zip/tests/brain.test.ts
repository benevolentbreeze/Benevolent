import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  answerLocally,
  askBrain,
  buildContext,
  extractAmount,
  isSafeRemoteText,
  parseQuestion,
  readEndpoint,
  type BrainAnswer,
  type FactMap,
} from "../src/services/brainService";
import { computeAllGoalProgress, computeSummary } from "../src/services/financialEngine";
import type { WorkspaceData } from "../src/types/state";
import { goal, NOW, tx, workspace } from "./helpers";

describe("amount parser (Vietnamese)", () => {
  const cases: [string, number | undefined][] = [
    ["300k", 300_000],
    ["300 K", 300_000],
    ["1tr 5", 1_500_000],
    ["1,5tr", 1_500_000],
    ["1.5tr", 1_500_000],
    ["1.500.000", 1_500_000],
    ["2 triệu 2", 2_200_000],
    ["1 triệu 50 nghìn", 1_050_000],
    ["1tr 500k", 1_500_000],
    ["1tr5 mua được không?", 1_500_000],
    ["450k có quá nhiều không?", 450_000],
    ["-300k", 300_000],
    ["0k", undefined],
    ["NaN", undefined],
    ["Infinity", undefined],
    ["999999999999999999999", undefined],
    ["300.000", 300_000],
    ["300 nghìn", 300_000],
    ["300 ngàn", 300_000],
    ["1tr", 1_000_000],
    ["1 triệu", 1_000_000],
    ["1,5 triệu", 1_500_000],
    ["1.5 triệu", 1_500_000],
    ["1tr5", 1_500_000],
    ["2tr2", 2_200_000],
    ["1tr500", 1_500_000],
    ["500k", 500_000],
    ["500 nghìn", 500_000],
    ["2 triệu rưỡi", 2_500_000],
    ["5 nghìn rưỡi", 5_500],
    ["1 củ", 1_000_000],
    ["450000", 450_000],
    ["Mua cái này 300k được không?", 300_000],
    ["1tr5 có quá nhiều không?", 1_500_000],
    ["Tháng 10 còn bao nhiêu?", undefined],
    ["năm 2026 tiết kiệm được bao nhiêu", undefined],
    ["mua 2 cái áo", undefined],
    ["không có số", undefined],
    ["300 không", undefined],
  ];
  for (const [text, expected] of cases) {
    it(`"${text}" → ${expected ?? "không có số tiền"}`, () => assert.equal(extractAmount(text), expected));
  }
});

describe("question intents", () => {
  const cases: [string, string, number?][] = [
    ["Mua cái này 300k được không?", "afford", 300_000],
    ["Em còn đủ tiền mua cái này không?", "afford"],
    ["Tuần này em tiêu bao nhiêu?", "highlights"],
    ["Tháng này còn bao nhiêu?", "allowance"],
    ["Mục tiêu laptop của em còn bao lâu?", "goal"],
    ["Em cần tiết kiệm bao nhiêu mỗi tháng?", "goal"],
    ["450k mua được không?", "afford", 450_000],
    ["1tr5 có quá nhiều không?", "afford", 1_500_000],
    ["1tr5 mua được không?", "afford", 1_500_000],
    ["450k có quá nhiều không?", "afford", 450_000],
    ["Mục tiêu laptop còn bao lâu?", "goal"],
    ["Cần tiết kiệm bao nhiêu mỗi tháng?", "goal"],
    ["Ăn uống tháng này bao nhiêu?", "category"],
    ["Mua sắm tháng này thế nào?", "category"],
    ["xem chi tiêu", "unknown"],
    ["thời tiết hôm nay", "unknown"],
    ["", "highlights"],
  ];
  for (const [text, intent, amount] of cases) {
    it(`"${text}" → ${intent}`, () => {
      const parsed = parseQuestion(text);
      assert.equal(parsed.intent, intent);
      if (amount !== undefined) assert.equal(parsed.amount, amount);
    });
  }

  it("bounds very long questions", () => {
    assert.ok(parseQuestion("a".repeat(10_000)).text.length <= 160);
  });
});

describe("Brain explains the engine's numbers, never its own", () => {
  const g = goal({ name: "Quỹ dự phòng", targetAmount: 6_000_000, monthlyContribution: 300_000 });
  const laptop = goal({ name: "Laptop", targetAmount: 20_000_000 });
  const data: WorkspaceData = workspace(
    [
      tx({ type: "income", amount: 4_500_000, date: "2026-10-01T09:00" }),
      tx({ type: "expense", amount: 45_000, date: "2026-10-05T12:00" }),
      tx({ type: "expense", amount: 120_000, category: "transport", date: "2026-09-29T08:00" }),
      tx({ type: "saving", amount: 1_500_000, goalId: g.id, opening: true, date: "2026-09-01T10:00" }),
    ],
    [laptop, g],
  );
  const goals = computeAllGoalProgress(data, NOW);
  const summary = computeSummary(data, NOW, goals);
  const ctx = buildContext(summary, goals, false);
  const ask = (q: string) => answerLocally(parseQuestion(q), ctx, summary, goals);
  const facts = (answer: BrainAnswer): FactMap => ({ ...ctx.facts, ...answer.facts });

  /** Every {token} resolves, and no digit appears outside tokens except in fixed example phrasing. */
  function assertGrounded(answer: BrainAnswer) {
    for (const text of [answer.lead, answer.detail]) {
      for (const [, id] of text.matchAll(/\{([\w:.-]+)\}/g)) assert.ok(id in facts(answer), `unknown fact ${id}`);
      // Fixed wording ("7 ngày qua", quoted examples) is not a financial figure.
      const bare = text.replace(/\{[\w:.-]+\}/g, "").replace(/“[^”]*”/g, "").replace(/\b7 ngày\b/g, "");
      assert.equal(/\d/.test(bare), false, `invented number in: ${text}`);
    }
  }

  it("daily allowance equals the dashboard's figure", () => {
    const answer = ask("Còn tiêu được bao nhiêu?");
    assertGrounded(answer);
    assert.equal(facts(answer).dailyAllowance.value, summary.dailyAllowance);
    assert.equal(facts(answer).balance.value, summary.balance);
  });

  it("afford answers use the engine's simulation", () => {
    const answer = ask("Mua giày 450k được không?");
    assertGrounded(answer);
    assert.equal(answer.facts.purchase.value, 450_000);
    assert.equal(answer.facts.balanceAfter.value, summary.balance - 450_000);
  });

  it("asks for the amount instead of guessing one", () => {
    const answer = ask("Em còn đủ tiền mua cái này không?");
    assertGrounded(answer);
    assert.equal(answer.facts.purchase, undefined);
    assert.ok(answer.lead.includes("bao nhiêu"));
  });

  it("answers about the goal named in the question, not just the primary one", () => {
    const answer = ask("Quỹ dự phòng còn bao lâu?");
    assertGrounded(answer);
    assert.equal(facts(answer)["goal:name"].text, "Quỹ dự phòng");
    assert.equal(facts(answer)["goal:saved"].value, 1_500_000);
    assert.equal(ask("Mục tiêu có kịp không?").facts["goal:name"], undefined, "primary goal uses context facts");
  });

  it("every intent stays grounded, including empty data", () => {
    const empty = workspace();
    const emptyGoals = computeAllGoalProgress(empty, NOW);
    const emptySummary = computeSummary(empty, NOW, emptyGoals);
    const emptyCtx = buildContext(emptySummary, emptyGoals, false);
    for (const q of ["", "Còn tiêu được bao nhiêu?", "mua 300k được không", "mục tiêu", "ăn uống", "abc", "đủ tiền mua không"]) {
      assertGrounded(ask(q));
      const answer = answerLocally(parseQuestion(q), emptyCtx, emptySummary, emptyGoals);
      for (const [, id] of `${answer.lead} ${answer.detail}`.matchAll(/\{([\w:.-]+)\}/g)) {
        assert.ok(id in emptyCtx.facts || id in answer.facts, `${q}: unknown fact ${id}`);
      }
    }
  });

  it("negative balance is explained, not hidden", () => {
    const broke = workspace([tx({ type: "expense", amount: 200_000 })]);
    const brokeGoals = computeAllGoalProgress(broke, NOW);
    const brokeSummary = computeSummary(broke, NOW, brokeGoals);
    const answer = answerLocally(parseQuestion("Còn tiêu được bao nhiêu?"), buildContext(brokeSummary, brokeGoals, false), brokeSummary, brokeGoals);
    assert.equal(answer.stat, "balance");
    assert.ok(answer.lead.includes("chưa đủ"));
  });
});

describe("remote Brain guard rails", () => {
  const allowed: FactMap = { balance: { id: "balance", label: "Số dư", kind: "money", value: 1 } };
  it("accepts text whose only numbers are fact tokens", () => {
    assert.ok(isSafeRemoteText("Bạn còn {balance}.", allowed));
  });
  it("rejects invented numbers, unknown tokens, empty or huge text", () => {
    for (const bad of ["Bạn còn 999.999 đồng", "Bạn còn {secret}", "", "   ", "x".repeat(500), 42, null, { lead: "x" }]) {
      assert.equal(isSafeRemoteText(bad, allowed), false, String(bad));
    }
  });
  it("only accepts https or same-origin endpoints", () => {
    assert.equal(readEndpoint("https://api.example.com/brain"), "https://api.example.com/brain");
    assert.equal(readEndpoint("/api/brain"), "/api/brain");
    for (const bad of ["http://api.example.com", "javascript:alert(1)", "//evil.com", "", " ", undefined, 3]) {
      assert.equal(readEndpoint(bad), undefined, String(bad));
    }
  });
});

describe("remote Brain (injected transport)", () => {
  const data = workspace([tx({ type: "income", amount: 3_000_000 }), tx({ type: "expense", amount: 50_000 })]);
  const goals = computeAllGoalProgress(data, NOW);
  const summary = computeSummary(data, NOW, goals);
  const ctx = buildContext(summary, goals, false);
  const respond = (body: unknown, init: ResponseInit = {}) =>
    (async () => new Response(typeof body === "string" ? body : JSON.stringify(body), init)) as unknown as typeof fetch;
  const ask = (question: string, fetchImpl: typeof fetch, extra: { timeoutMs?: number; recentCalls?: number[] } = {}) =>
    askBrain(parseQuestion(question), ctx, summary, goals, undefined, { endpoint: "https://brain.example/ask", fetchImpl, recentCalls: [], ...extra });

  it("uses a valid remote wording, numbers still from facts", async () => {
    const answer = await ask("Còn tiêu được bao nhiêu?", respond({ lead: "Bạn ổn.", detail: "Mỗi ngày còn {dailyAllowance}." }));
    assert.equal(answer.source, "remote");
    assert.equal(answer.detail, "Mỗi ngày còn {dailyAllowance}.");
  });

  it("sends only the facts the answer needs — no notes, no transactions", async () => {
    let sent = "";
    const capture = (async (_url: string, init: RequestInit) => {
      sent = String(init.body);
      return new Response(JSON.stringify({ lead: "Ổn.", detail: "Ổn." }));
    }) as unknown as typeof fetch;
    await ask("Còn tiêu được bao nhiêu?", capture);
    const body = JSON.parse(sent);
    assert.deepEqual(Object.keys(body).sort(), ["facts", "intent", "locale", "question"]);
    assert.ok(body.facts.length <= 8);
    assert.equal(sent.includes("note"), false);
  });

  it("falls back locally on malformed, missing-field, wrong-type, invented-number, oversized, empty and error responses", async () => {
    const bad = [
      respond("not json"),
      respond(""),
      respond({ lead: "Ổn." }),
      respond({ lead: 1, detail: 2 }),
      respond({ lead: "Còn 5.000.000 đồng", detail: "x" }),
      respond({ lead: "{unknownFact}", detail: "x" }),
      respond({ lead: "a".repeat(20_000), detail: "b" }),
      respond([1, 2, 3]),
      respond("null"),
      respond({ lead: "x", detail: "y" }, { status: 500 }),
    ];
    for (const fetchImpl of bad) {
      const answer = await ask("Còn tiêu được bao nhiêu?", fetchImpl);
      assert.equal(answer.source, "local");
      assert.ok(answer.notice);
      assert.ok(answer.lead.includes("{dailyAllowance}"));
    }
  });

  it("times out instead of hanging", async () => {
    const never = ((_url: string, init: RequestInit) =>
      new Promise((_, reject) => init.signal?.addEventListener("abort", () => reject(new Error("aborted"))))) as unknown as typeof fetch;
    const started = Date.now();
    const answer = await ask("Còn tiêu được bao nhiêu?", never, { timeoutMs: 50 });
    assert.equal(answer.source, "local");
    assert.ok(Date.now() - started < 1_000);
  });

  it("never sends unknown questions or non-https endpoints anywhere", async () => {
    let calls = 0;
    const counting = (async () => {
      calls += 1;
      return new Response("{}");
    }) as unknown as typeof fetch;
    await ask("thời tiết hôm nay", counting);
    await askBrain(parseQuestion("Còn tiêu được bao nhiêu?"), ctx, summary, goals, undefined, { endpoint: "http://insecure", fetchImpl: counting });
    assert.equal(calls, 0);
  });

  it("rate-limits rapid repeated questions on the client", async () => {
    let calls = 0;
    const counting = (async () => {
      calls += 1;
      return new Response(JSON.stringify({ lead: "Ổn.", detail: "Ổn." }));
    }) as unknown as typeof fetch;
    const recentCalls: number[] = [];
    for (let i = 0; i < 20; i += 1) await ask("Còn tiêu được bao nhiêu?", counting, { recentCalls });
    assert.equal(calls, 8);
  });
});
