import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { computeAllGoalProgress, computeSummary } from "../src/services/financialEngine";
import { MAX_BACKUP_BYTES, parseBackup, parseStoredState, readPersistedState, serializeBackup, createDefaultState } from "../src/services/storageService";
import type { PersistedState } from "../src/types/state";
import { NOW } from "./helpers";

const validTx = (over: Record<string, unknown> = {}) => ({
  id: "tx_a1",
  amount: 35_000,
  type: "expense",
  category: "food",
  note: "Ăn trưa với Minh",
  date: "2026-10-05T12:30",
  createdAt: "2026-10-05T05:30:00.000Z",
  ...over,
});
const validGoal = (over: Record<string, unknown> = {}) => ({
  id: "goal_1",
  name: "MacBook Air",
  targetAmount: 25_000_000,
  deadline: "2027-06-15",
  monthlyContribution: 1_000_000,
  createdAt: "2026-06-01T03:00:00.000Z",
  ...over,
});
const stateWith = (transactions: unknown[], goals: unknown[] = [], version = 2) => ({
  version,
  activeWorkspace: "personal",
  workspaces: { personal: { transactions, goals }, demo: null },
  settings: { displayName: "An", hideAmounts: false, nudges: true, motion: "system", introSeen: true },
});

function read(value: unknown) {
  const result = readPersistedState(value);
  assert.ok(result.ok, "expected a readable state");
  return result;
}

describe("reading stored state", () => {
  it("keeps valid records exactly, including Vietnamese notes", () => {
    const result = read(stateWith([validTx()], [validGoal()]));
    assert.equal(result.dropped, 0);
    assert.deepEqual(result.state.workspaces.personal.transactions[0], validTx());
  });

  it("drops each kind of invalid transaction and counts it", () => {
    const bad = [
      validTx({ id: "a", amount: 0 }),
      validTx({ id: "b", amount: -1 }),
      validTx({ id: "c", amount: 1.5 }),
      validTx({ id: "d", amount: 999_999_999_999_999 }),
      validTx({ id: "e", amount: "35000" }),
      validTx({ id: "f", type: "gift" }),
      validTx({ id: "g", category: "crypto" }),
      validTx({ id: "h", type: "income", category: "food" }),
      validTx({ id: "i", date: "2026-02-31T10:00" }),
      validTx({ id: "j", date: "2026-10-05T25:00" }),
      validTx({ id: "k", date: "0099-10-05T10:00" }),
      validTx({ id: "l", createdAt: "yesterday" }),
      validTx({ id: "m", type: "saving", category: "saving", goalId: "missing_goal" }),
      validTx({ id: "<script>" }),
      { id: "n" },
      null,
      "text",
    ];
    const result = read(stateWith([validTx(), ...bad]));
    assert.equal(result.state.workspaces.personal.transactions.length, 1);
    assert.equal(result.dropped, bad.length);
  });

  it("removes duplicate ids (first one wins) and sorts newest first", () => {
    const result = read(
      stateWith([
        validTx({ id: "old", date: "2026-09-01T10:00" }),
        validTx({ id: "dup", date: "2026-10-01T10:00", amount: 1_000 }),
        validTx({ id: "dup", date: "2026-10-02T10:00", amount: 9_000 }),
      ], [validGoal(), validGoal({ name: "Twin" })]),
    );
    const txs = result.state.workspaces.personal.transactions;
    assert.deepEqual(txs.map((t) => t.id), ["dup", "old"]);
    assert.equal(txs[0].amount, 1_000);
    assert.equal(result.state.workspaces.personal.goals.length, 1);
    assert.equal(result.dropped, 2);
  });

  it("bounds enormous strings instead of storing them", () => {
    const result = read(stateWith([validTx({ note: "x".repeat(100_000) })], [validGoal({ name: "y".repeat(5_000) })]));
    assert.equal(result.state.workspaces.personal.transactions[0].note.length, 140);
    assert.equal(result.state.workspaces.personal.goals[0].name.length, 40);
  });

  it("ignores unknown fields and fills missing settings with defaults", () => {
    const raw = stateWith([validTx({ extra: "ignored", __proto__: { polluted: true } })]);
    (raw as Record<string, unknown>).unexpected = 1;
    (raw as Record<string, unknown>).settings = { hideAmounts: "yes" };
    const result = read(raw);
    assert.equal("extra" in result.state.workspaces.personal.transactions[0], false);
    assert.equal(result.state.settings.hideAmounts, false);
    assert.equal(({} as Record<string, unknown>).polluted, undefined);
  });

  it("rejects state from a newer app version instead of misreading it", () => {
    const result = readPersistedState(stateWith([], [], 99));
    assert.deepEqual(result, { ok: false, reason: "newer-version" });
  });

  it("never throws on malformed JSON or absurd input", () => {
    for (const raw of ["{not json", "", "null", "[]", '{"version":2}', '{"version":"2"}', "1e999"]) {
      assert.equal(parseStoredState(raw).ok, false, raw);
    }
  });

  it("migrates v1 'startingAmount' to an opening entry without changing balance or progress", () => {
    const v1 = stateWith(
      [validTx({ id: "inc", type: "income", category: "income", amount: 5_000_000, note: "" }), validTx({ id: "sv", type: "saving", category: "saving", amount: 500_000, goalId: "goal_1" })],
      [{ ...validGoal({ targetAmount: 15_000_000 }), startingAmount: 3_000_000 }],
      1,
    );
    const result = read(v1);
    const data = result.state.workspaces.personal;
    const goals = computeAllGoalProgress(data, NOW);
    const summary = computeSummary(data, NOW, goals);
    // v1 showed: balance 5.000.000 − 500.000 = 4.500.000 and goal 3.000.000 + 500.000.
    assert.equal(summary.balance, 4_500_000);
    assert.equal(goals[0].savedAmount, 3_500_000);
    assert.equal(goals[0].openingAmount, 3_000_000);
    assert.equal(summary.monthIncome, 5_000_000, "the migrated opening balance is not income");
    assert.equal(result.state.version, 2);
    assert.equal("startingAmount" in data.goals[0], false);
  });
});

describe("backup files", () => {
  it("round-trips the whole state", () => {
    const state: PersistedState = createDefaultState();
    state.workspaces.personal = read(stateWith([validTx()], [validGoal()])).state.workspaces.personal;
    const parsed = parseBackup(serializeBackup(state));
    assert.ok(parsed.ok);
    assert.deepEqual(parsed.state.workspaces.personal, state.workspaces.personal);
  });

  it("rejects malformed, foreign, oversized and future files with a readable reason", () => {
    const cases = [
      "not json",
      JSON.stringify({ app: "other", kind: "backup", state: {} }),
      JSON.stringify({ app: "benevolent", kind: "backup", state: { version: 2 } }),
      JSON.stringify({ app: "benevolent", kind: "backup", state: stateWith([], [], 7) }),
      "x".repeat(MAX_BACKUP_BYTES + 1),
    ];
    for (const text of cases) {
      const result = parseBackup(text);
      assert.equal(result.ok, false);
      if (!result.ok) assert.ok(result.reason.length > 10);
    }
  });

  it("normalises a backup with bad records instead of importing them", () => {
    const text = JSON.stringify({
      app: "benevolent",
      kind: "backup",
      state: stateWith([validTx(), validTx({ id: "neg", amount: -5 })], [validGoal({ id: "bad", deadline: "soon" })]),
    });
    const result = parseBackup(text);
    assert.ok(result.ok);
    assert.equal(result.dropped, 2);
  });
});
