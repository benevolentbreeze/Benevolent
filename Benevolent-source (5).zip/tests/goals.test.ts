import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { computeAllGoalProgress, computeSummary } from "../src/services/financialEngine";
import {
  buildOpeningEntry,
  computeGoalProgress,
  openingAmountFor,
  openingFor,
  validateGoalDraft,
  type GoalDraft,
} from "../src/services/goalService";
import { createDefaultState } from "../src/services/storageService";
import { createReducer, type StoreState } from "../src/state/financeReducer";
import type { GoalProgress } from "../src/types/goal";
import type { WorkspaceData } from "../src/types/state";
import { goal, NOW, tx, workspace } from "./helpers";

/** Fixed clock: date rules in the reducer never depend on the machine's real time. */
const reducer = createReducer(() => NOW);

function store(data: WorkspaceData): StoreState {
  const persisted = createDefaultState();
  return { status: "ready", issue: null, persisted: { ...persisted, activeWorkspace: "personal", workspaces: { demo: null, personal: data } } };
}

/** No NaN, no Infinity, no Invalid Date anywhere in a progress object. */
function assertSane(progress: GoalProgress) {
  for (const [key, value] of Object.entries(progress)) {
    if (typeof value === "number") assert.ok(Number.isFinite(value), `${key} = ${value}`);
    if (value instanceof Date) assert.ok(Number.isFinite(value.getTime()), `${key} is an invalid date`);
  }
  assert.ok(progress.percent >= 0 && progress.percent <= 100);
  assert.ok(progress.remaining >= 0);
}

const draft = (partial: Partial<GoalDraft> = {}): GoalDraft => ({
  name: "Laptop",
  targetAmount: 15_000_000,
  savedAmount: 0,
  deadline: "2027-06-15",
  monthlyContribution: 0,
  ...partial,
});

describe("goal math — edge cases", () => {
  it("1. target 0 (only reachable through bad data) is complete, not NaN", () => {
    const progress = computeGoalProgress(goal({ targetAmount: 0 }), [], NOW);
    assertSane(progress);
    assert.equal(progress.isComplete, true);
  });

  it("2. nothing saved yet", () => {
    const progress = computeGoalProgress(goal(), [], NOW);
    assertSane(progress);
    assert.equal(progress.savedAmount, 0);
    assert.equal(progress.remaining, 15_000_000);
    assert.equal(progress.paceSource, "none");
    assert.equal(progress.estimatedCompletion, null);
  });

  it("3–4. saved equal to / above the target is complete at 100%", () => {
    const g = goal({ targetAmount: 1_000_000 });
    for (const amount of [1_000_000, 1_500_000]) {
      const progress = computeGoalProgress(g, [tx({ type: "saving", amount, goalId: g.id, opening: true })], NOW);
      assertSane(progress);
      assert.equal(progress.isComplete, true);
      assert.equal(progress.percent, 100);
      assert.equal(progress.remaining, 0);
      assert.equal(progress.requiredMonthly, 0);
      assert.equal(progress.commitmentRemainingThisMonth, 0);
    }
  });

  it("5. a zero or non-integer contribution can't exist (rejected by validation and storage)", () => {
    const g = goal();
    const progress = computeGoalProgress(g, [], NOW);
    assertSane(progress);
  });

  it("6. no monthly plan and no contributions → no pace, no estimate", () => {
    const progress = computeGoalProgress(goal({ monthlyContribution: null }), [], NOW);
    assert.equal(progress.pace, 0);
    assert.equal(progress.onTrack, false);
  });

  it("7. deadline today is not overdue; the whole remainder is due now", () => {
    const progress = computeGoalProgress(goal({ deadline: "2026-10-05", targetAmount: 3_000_000 }), [], NOW);
    assertSane(progress);
    assert.equal(progress.isOverdue, false);
    assert.equal(progress.requiredMonthly, 3_000_000);
  });

  it("8. deadline tomorrow", () => {
    const progress = computeGoalProgress(goal({ deadline: "2026-10-06", targetAmount: 3_000_000 }), [], NOW);
    assertSane(progress);
    assert.equal(progress.isOverdue, false);
    assert.equal(progress.requiredMonthly, 3_000_000);
  });

  it("9. deadline in the past is overdue", () => {
    const progress = computeGoalProgress(goal({ deadline: "2026-10-04", monthlyContribution: 500_000 }), [], NOW);
    assertSane(progress);
    assert.equal(progress.isOverdue, true);
    assert.equal(progress.onTrack, false);
    assert.equal(progress.requiredMonthly, progress.remaining);
  });

  it("10–11. one month and many years ahead", () => {
    const oneMonth = computeGoalProgress(goal({ deadline: "2026-11-05", targetAmount: 3_000_000 }), [], NOW);
    assertSane(oneMonth);
    assert.ok(oneMonth.monthsLeft > 0.9 && oneMonth.monthsLeft < 1.1);
    const years = computeGoalProgress(goal({ deadline: "2046-10-05", targetAmount: 240_000_000 }), [], NOW);
    assertSane(years);
    assert.ok(Math.abs(years.requiredMonthly - 1_000_000) < 5_000);
  });

  it("projects completion from the plan and flags a shortfall", () => {
    const g = goal({ targetAmount: 25_000_000, monthlyContribution: 1_000_000, deadline: "2027-06-15" });
    const progress = computeGoalProgress(g, [tx({ type: "saving", amount: 8_450_000, goalId: g.id, opening: true })], NOW);
    assertSane(progress);
    assert.equal(progress.remaining, 16_550_000);
    assert.equal(progress.onTrack, false);
    assert.ok(progress.projectedGap < 0);
    assert.ok(progress.estimatedCompletion && progress.estimatedCompletion.getFullYear() === 2028);
  });

  it("15. contributions after set-up count toward pace; the opening amount never does", () => {
    const g = goal({ createdAt: new Date(2026, 6, 1).toISOString() });
    const progress = computeGoalProgress(
      g,
      [
        tx({ type: "saving", amount: 5_000_000, goalId: g.id, opening: true, date: "2026-10-01T10:00" }),
        tx({ type: "saving", amount: 900_000, goalId: g.id, date: "2026-09-01T10:00" }),
      ],
      NOW,
    );
    assert.equal(progress.openingAmount, 5_000_000);
    assert.equal(progress.contributedAmount, 900_000);
    assert.equal(progress.contributedThisMonth, 0);
    assert.equal(progress.paceSource, "history");
    assert.ok(progress.pace > 250_000 && progress.pace < 350_000);
  });

  it("an absurdly slow pace gives no estimate instead of an invalid date", () => {
    const g = goal({ targetAmount: 1_000_000_000, createdAt: new Date(2026, 6, 1).toISOString() });
    const progress = computeGoalProgress(g, [tx({ type: "saving", amount: 1, goalId: g.id, date: "2026-09-20T10:00" })], NOW);
    assertSane(progress);
    assert.equal(progress.estimatedCompletion, null);
  });

  it("survives a corrupt createdAt and deadline", () => {
    const progress = computeGoalProgress(goal({ createdAt: "not a date", deadline: "2026-02-31" }), [], NOW);
    assertSane(progress);
  });
});

describe("starting amount semantics", () => {
  it("target 15tr, starting 3tr, contributions 2tr → saved 5tr, remaining 10tr, nothing counted twice", () => {
    const g = goal({ targetAmount: 15_000_000 });
    const txs = [
      tx({ type: "income", amount: 10_000_000 }),
      tx({ type: "saving", amount: 3_000_000, goalId: g.id, opening: true }),
      tx({ type: "saving", amount: 1_200_000, goalId: g.id }),
      tx({ type: "saving", amount: 800_000, goalId: g.id }),
    ];
    const progress = computeGoalProgress(g, txs, NOW);
    assert.equal(progress.openingAmount, 3_000_000);
    assert.equal(progress.contributedAmount, 2_000_000);
    assert.equal(progress.savedAmount, 5_000_000);
    assert.equal(progress.remaining, 10_000_000);
    assert.ok(Math.abs(progress.percent - 100 / 3) < 1e-9);
    const summary = computeSummary(workspace(txs, [g]), NOW, [progress]);
    assert.equal(summary.balance, 5_000_000, "10tr income − 5tr set aside");
    assert.equal(summary.balance + progress.savedAmount, 10_000_000);
  });

  it("starting amount only / contribution only / both", () => {
    const g = goal({ targetAmount: 1_000_000 });
    const opening = tx({ type: "saving", amount: 300_000, goalId: g.id, opening: true });
    const contribution = tx({ type: "saving", amount: 200_000, goalId: g.id });
    assert.equal(computeGoalProgress(g, [opening], NOW).savedAmount, 300_000);
    assert.equal(computeGoalProgress(g, [contribution], NOW).savedAmount, 200_000);
    const both = computeGoalProgress(g, [opening, contribution], NOW);
    assert.equal(both.savedAmount, 500_000);
    assert.equal(both.remaining, 500_000);
    assert.equal(both.percent, 50);
  });

  it("editing and deleting a linked saving transaction keeps goal and balance in step", () => {
    const g = goal({ targetAmount: 5_000_000 });
    const contribution = tx({ type: "saving", amount: 500_000, goalId: g.id });
    let state = store(workspace([tx({ type: "income", amount: 3_000_000 }), contribution], [g]));
    const look = () => {
      const data = state.persisted.workspaces.personal;
      const goals = computeAllGoalProgress(data, NOW);
      return { balance: computeSummary(data, NOW, goals).balance, saved: goals[0].savedAmount };
    };
    state = reducer(state, { type: "updateTransaction", tx: { ...contribution, amount: 2_000_000 } });
    assert.deepEqual(look(), { balance: 1_000_000, saved: 2_000_000 });
    state = reducer(state, { type: "updateTransaction", tx: { ...contribution, amount: 200_000 } });
    assert.deepEqual(look(), { balance: 2_800_000, saved: 200_000 });
    state = reducer(state, { type: "deleteTransaction", id: contribution.id });
    assert.deepEqual(look(), { balance: 3_000_000, saved: 0 });
    state = reducer(state, { type: "updateTransaction", tx: { ...contribution, goalId: "deleted-goal" } });
    assert.deepEqual(look(), { balance: 3_000_000, saved: 0 }, "an edit can't point at a missing goal");
  });
});

describe("goal validation (create / edit)", () => {
  const ctx = (balance: number, existing?: GoalProgress) => ({ now: NOW, balance, existing });

  it("rejects target 0, saved > target, and past or same-day deadlines", () => {
    assert.ok(validateGoalDraft(draft({ targetAmount: 0 }), ctx(10_000_000)).targetAmount);
    assert.ok(validateGoalDraft(draft({ savedAmount: 16_000_000 }), ctx(100_000_000)).savedAmount);
    assert.ok(validateGoalDraft(draft({ deadline: "2026-10-05" }), ctx(0)).deadline);
    assert.ok(validateGoalDraft(draft({ deadline: "2026-10-04" }), ctx(0)).deadline);
    assert.equal(validateGoalDraft(draft({ deadline: "2026-10-06" }), ctx(0)).deadline, undefined);
  });

  it("the opening amount must be covered by the balance (it is moved out of it)", () => {
    assert.ok(validateGoalDraft(draft({ savedAmount: 3_000_000 }), ctx(2_000_000)).savedAmount);
    assert.ok(validateGoalDraft(draft({ savedAmount: 3_000_000 }), ctx(-500_000)).savedAmount);
    assert.equal(validateGoalDraft(draft({ savedAmount: 3_000_000 }), ctx(5_000_000)).savedAmount, undefined);
  });

  it("editing: only the increase needs balance; can't go below what was contributed", () => {
    const g = goal({ deadline: "2026-10-01" });
    const existing = computeGoalProgress(
      g,
      [
        tx({ type: "saving", amount: 3_000_000, goalId: g.id, opening: true }),
        tx({ type: "saving", amount: 1_000_000, goalId: g.id }),
      ],
      NOW,
    );
    const edit = (savedAmount: number, balance: number) => validateGoalDraft(draft({ savedAmount, deadline: g.deadline }), ctx(balance, existing));
    assert.equal(edit(4_000_000, 0).savedAmount, undefined, "unchanged needs nothing");
    assert.equal(edit(4_500_000, 500_000).savedAmount, undefined);
    assert.ok(edit(4_500_000, 499_000).savedAmount);
    assert.ok(edit(900_000, 0).savedAmount, "below contributions");
    assert.equal(edit(2_000_000, 0).deadline, undefined, "an overdue goal can be edited without moving its deadline");
    assert.equal(openingAmountFor(draft({ savedAmount: 4_500_000 }), existing), 3_500_000);
  });
});

describe("goal accounting through the store", () => {
  const totals = (state: StoreState) => {
    const data = state.persisted.workspaces.personal;
    const goals = computeAllGoalProgress(data, NOW);
    const summary = computeSummary(data, NOW, goals);
    return { balance: summary.balance, saved: goals.reduce((sum, item) => sum + item.savedAmount, 0), goals };
  };

  it("creating a goal with 'Đã tiết kiệm' moves that money out of the available balance", () => {
    let state = store(workspace([tx({ type: "income", amount: 5_000_000 })]));
    const g = goal({ targetAmount: 15_000_000 });
    state = reducer(state, { type: "saveGoal", goal: g, opening: buildOpeningEntry(g.id, 3_000_000, undefined, NOW) });
    const { balance, saved, goals } = totals(state);
    assert.equal(goals[0].savedAmount, 3_000_000);
    assert.equal(balance, 2_000_000);
    assert.equal(balance + saved, 5_000_000);
  });

  it("editing the opening amount updates the single opening entry (no duplicates)", () => {
    const g = goal();
    let state = store(workspace([tx({ type: "income", amount: 5_000_000 })]));
    state = reducer(state, { type: "saveGoal", goal: g, opening: buildOpeningEntry(g.id, 3_000_000, undefined, NOW) });
    const existing = openingFor(g.id, state.persisted.workspaces.personal.transactions);
    state = reducer(state, { type: "saveGoal", goal: { ...g, name: "MacBook" }, opening: buildOpeningEntry(g.id, 1_000_000, existing, NOW) });
    const openings = state.persisted.workspaces.personal.transactions.filter((t) => t.opening && t.goalId === g.id);
    assert.equal(openings.length, 1);
    assert.equal(totals(state).balance, 4_000_000);
    state = reducer(state, { type: "saveGoal", goal: g, opening: buildOpeningEntry(g.id, 0, openingFor(g.id, state.persisted.workspaces.personal.transactions), NOW) });
    assert.equal(totals(state).balance, 5_000_000);
  });

  it("deleting a goal (empty, with opening, with contributions, completed, overdue) returns exactly its savings", () => {
    const cases = [
      { label: "empty", opening: 0, contribution: 0, target: 10_000_000, deadline: "2027-01-01" },
      { label: "opening", opening: 3_000_000, contribution: 0, target: 10_000_000, deadline: "2027-01-01" },
      { label: "contributions", opening: 1_000_000, contribution: 500_000, target: 10_000_000, deadline: "2027-01-01" },
      { label: "completed", opening: 2_000_000, contribution: 1_000_000, target: 3_000_000, deadline: "2027-01-01" },
      { label: "overdue", opening: 1_000_000, contribution: 0, target: 10_000_000, deadline: "2026-09-01" },
    ];
    for (const item of cases) {
      const g = goal({ targetAmount: item.target, deadline: item.deadline });
      const txs = [tx({ type: "income", amount: 10_000_000 }), tx({ type: "expense", amount: 123_000 })];
      if (item.opening) txs.push(tx({ type: "saving", amount: item.opening, goalId: g.id, opening: true }));
      if (item.contribution) txs.push(tx({ type: "saving", amount: item.contribution, goalId: g.id }));
      let state = store(workspace(txs, [g]));
      const before = totals(state);
      state = reducer(state, { type: "deleteGoal", id: g.id });
      const after = totals(state);
      assert.equal(after.balance, before.balance + item.opening + item.contribution, item.label);
      assert.equal(after.balance + after.saved, before.balance + before.saved, `${item.label}: money conserved`);
      assert.equal(state.persisted.workspaces.personal.transactions.some((t) => t.goalId === g.id), false);
      state = reducer(state, { type: "deleteGoal", id: g.id });
      assert.equal(totals(state).balance, after.balance, `${item.label}: second delete is a no-op`);
    }
  });

  it("a contribution that lands after its goal was deleted is rejected, so no money vanishes", () => {
    const g = goal();
    let state = store(workspace([tx({ type: "income", amount: 1_000_000 })], [g]));
    state = reducer(state, { type: "deleteGoal", id: g.id });
    state = reducer(state, { type: "addTransaction", tx: tx({ type: "saving", amount: 500_000, goalId: g.id }) });
    assert.equal(totals(state).balance, 1_000_000);
  });

  it("delayed commits land in the workspace they were started in", () => {
    let state = store(workspace());
    state = { ...state, persisted: { ...state.persisted, workspaces: { ...state.persisted.workspaces, demo: workspace() } } };
    state = reducer(state, { type: "switchWorkspace", workspace: "demo" });
    state = reducer(state, { type: "addTransaction", tx: tx({ type: "expense", amount: 1_000 }), workspace: "personal" });
    assert.equal(state.persisted.workspaces.personal.transactions.length, 1);
    assert.equal(state.persisted.workspaces.demo?.transactions.length, 0);
  });

  it("adding the same record twice (double tap, repeated undo) is a no-op", () => {
    const expense = tx({ type: "expense", amount: 1_000 });
    let state = store(workspace());
    state = reducer(state, { type: "addTransaction", tx: expense });
    state = reducer(state, { type: "addTransaction", tx: expense });
    assert.equal(state.persisted.workspaces.personal.transactions.length, 1);
  });
});
