import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { buildTransaction, combineDayAndTime, transactionsToCsv, validateDraft } from "../src/services/transactionService";
import type { TransactionDraft } from "../src/types/transaction";
import { addMonths, formatDayHeading, parseLocal, toDateKey } from "../src/utils/date";
import { formatCompactMoney, formatMoney, formatPercent, parseAmountInput } from "../src/utils/money";
import { goal, NOW, tx } from "./helpers";

const draft = (partial: Partial<TransactionDraft> = {}): TransactionDraft => ({
  amount: 35_000,
  type: "expense",
  category: "food",
  note: "",
  date: "2026-10-05T12:00",
  ...partial,
});

describe("transaction validation", () => {
  it("rejects zero, negative, fractional, NaN and oversized amounts", () => {
    for (const amount of [0, -1, 1.5, Number.NaN, Number.POSITIVE_INFINITY, 1_000_000_001, 999_999_999_999_999]) {
      assert.ok(validateDraft(draft({ amount }), NOW).amount, String(amount));
    }
    assert.equal(validateDraft(draft({ amount: 1 }), NOW).amount, undefined);
    assert.equal(validateDraft(draft({ amount: 1_000_000_000 }), NOW).amount, undefined);
  });

  it("requires a category for expenses and a goal for savings", () => {
    assert.ok(validateDraft(draft({ category: null }), NOW).category);
    assert.equal(validateDraft(draft({ type: "income", category: null }), NOW).category, undefined);
    assert.ok(validateDraft(draft({ type: "saving", category: "saving" }), NOW).amount);
  });

  it("rejects future and impossible dates but allows the past", () => {
    assert.ok(validateDraft(draft({ date: "2026-10-06T00:01" }), NOW).date);
    assert.ok(validateDraft(draft({ date: "2026-02-30T10:00" }), NOW).date);
    assert.ok(validateDraft(draft({ date: "T12:00" }), NOW).date);
    assert.equal(validateDraft(draft({ date: "2020-01-01T10:00" }), NOW).date, undefined);
    assert.equal(validateDraft(draft({ date: "2026-10-05T23:59" }), NOW).date, undefined, "later today is still today");
  });

  it("limits a goal contribution by the balance and by what the goal still needs", () => {
    const saving = draft({ type: "saving", category: "saving", goalId: "g", amount: 600_000 });
    assert.ok(validateDraft(saving, NOW, { available: 500_000 }).amount);
    assert.ok(validateDraft(saving, NOW, { available: 1_000_000, goalRemaining: 500_000 }).amount);
    assert.equal(validateDraft(saving, NOW, { available: 600_000, goalRemaining: 600_000 }).amount, undefined);
  });

  it("keeps the note exactly as typed (outer spaces trimmed, bounded length)", () => {
    assert.equal(buildTransaction(draft({ note: "  Ăn trưa với Minh  " })).note, "Ăn trưa với Minh");
    assert.equal(buildTransaction(draft({ note: "" })).note, "");
    assert.equal(buildTransaction(draft({ note: "x".repeat(500) })).note.length, 140);
  });

  it("editing keeps id, creation time, time of day and the opening flag", () => {
    const existing = tx({ type: "saving", amount: 1_000_000, goalId: "g", opening: true, date: "2026-09-01T08:15" });
    const edited = buildTransaction({ ...draft({ type: "saving", category: "saving", goalId: "g", amount: 2_000_000 }), date: combineDayAndTime("2026-09-02", existing.date) }, existing);
    assert.equal(edited.id, existing.id);
    assert.equal(edited.createdAt, existing.createdAt);
    assert.equal(edited.date, "2026-09-02T08:15");
    assert.equal(edited.opening, true);
    const retyped = buildTransaction(draft({ type: "income", category: "income" }), tx({ type: "income", amount: 1, opening: true }));
    assert.equal(retyped.opening, true);
    const changedType = buildTransaction(draft(), tx({ type: "income", amount: 1, opening: true }));
    assert.equal(changedType.opening, undefined, "an opening balance turned into an expense is no longer an opening entry");
  });
});

describe("CSV export", () => {
  const g = goal({ name: "Quỹ, \"dự phòng\"" });
  const csv = transactionsToCsv(
    [
      tx({ type: "expense", amount: 35_000, note: 'Ăn trưa, "Minh"\nlúc 12h', date: "2026-10-05T12:00" }),
      tx({ type: "expense", amount: 10_000, note: "=HYPERLINK(\"http://evil\")", date: "2026-10-04T12:00" }),
      tx({ type: "expense", amount: 10_000, note: "+1-2", date: "2026-10-03T12:00" }),
      tx({ type: "saving", amount: 500_000, goalId: g.id, date: "2026-10-02T12:00" }),
      tx({ type: "income", amount: 4_500_000, note: "Bố mẹ gửi", date: "2026-10-01T09:00" }),
    ],
    [g],
  );
  const lines = csv.slice(1).split("\r\n");

  it("starts with a BOM and uses CRLF for Excel", () => {
    assert.equal(csv.charCodeAt(0), 0xfeff);
    assert.ok(csv.includes("\r\n"));
  });

  it("quotes commas, quotes and newlines; keeps Vietnamese text", () => {
    assert.ok(csv.includes('"Ăn trưa, ""Minh""\nlúc 12h"'));
    assert.ok(csv.includes('"Quỹ, ""dự phòng"""'));
  });

  it("neutralises spreadsheet formulas (CSV injection)", () => {
    assert.ok(csv.includes(`"'=HYPERLINK(""http://evil"")"`));
    assert.ok(csv.includes(",'+1-2,"));
  });

  it("writes signed whole-đồng amounts", () => {
    assert.ok(lines[0].startsWith("Ngày,Giờ,Loại"));
    assert.ok(csv.includes(",-35000"));
    assert.ok(csv.includes(",4500000"));
    assert.ok(csv.includes(",-500000"));
  });
});

describe("dates (local, deterministic)", () => {
  it("parses only real local dates and times", () => {
    assert.equal(parseLocal("2026-02-29"), null);
    assert.ok(parseLocal("2028-02-29"));
    assert.equal(parseLocal("2026-10-05T24:00"), null);
    assert.equal(parseLocal("2026-10-05T10:60"), null);
    assert.equal(parseLocal("0050-01-01"), null);
    assert.equal(parseLocal(undefined), null);
    assert.equal(toDateKey(parseLocal("2026-10-05T23:59") ?? new Date(0)), "2026-10-05");
  });

  it("adds months without overflowing short months", () => {
    assert.equal(toDateKey(addMonths(new Date(2026, 0, 31), 1)), "2026-02-28");
    assert.equal(toDateKey(addMonths(new Date(2026, 2, 31), -1)), "2026-02-28");
  });

  it("labels days relative to today in Vietnamese", () => {
    assert.equal(formatDayHeading(new Date(2026, 9, 5, 0, 0), NOW), "Hôm nay");
    assert.equal(formatDayHeading(new Date(2026, 9, 4, 23, 59), NOW), "Hôm qua");
    assert.equal(formatDayHeading(new Date(2026, 9, 3), NOW), "Thứ bảy, 3 tháng 10");
    assert.equal(formatDayHeading(new Date(2025, 9, 3), NOW), "Thứ sáu, 3 tháng 10, 2025");
  });
});

describe("money formatting (presentation only)", () => {
  it("formats đồng with Vietnamese grouping and a real minus sign", () => {
    assert.equal(formatMoney(2_840_000), "₫2.840.000");
    assert.equal(formatMoney(-35_000), "−₫35.000");
    assert.equal(formatMoney(35_000, { signed: true }), "+₫35.000");
    assert.equal(formatMoney(Number.NaN), "₫—");
  });
  it("compacts amounts", () => {
    assert.equal(formatCompactMoney(438_000), "₫438K");
    assert.equal(formatCompactMoney(2_840_000), "₫2,84M");
    assert.equal(formatCompactMoney(9_500), "₫9,5K");
    assert.equal(formatCompactMoney(10_000_000), "₫10M");
  });
  it("formats percentages", () => {
    assert.equal(formatPercent(0.338, 1), "33,8%");
    assert.equal(formatPercent(-0.27, 0, true), "−27%");
    assert.equal(formatPercent(0.1, 0), "10%");
    assert.equal(formatPercent(Number.POSITIVE_INFINITY), "—");
  });
  it("reads typed amounts as whole đồng", () => {
    assert.equal(parseAmountInput("35.000"), 35_000);
    assert.equal(parseAmountInput("-1"), 1);
    assert.equal(parseAmountInput("abc"), 0);
    assert.equal(parseAmountInput("0035"), 35);
    assert.ok(Number.isSafeInteger(parseAmountInput("9".repeat(40))));
  });
});
