import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { computeAllGoalProgress, computeMonth, computeSummary, simulatePurchase } from "../src/services/financialEngine";
import { createReducer, type StoreState } from "../src/state/financeReducer";
import { createDefaultState } from "../src/services/storageService";
import type { WorkspaceData } from "../src/types/state";
import { goal, NOW, tx, workspace } from "./helpers";

/** Fixed clock: date rules in the reducer never depend on the machine's real time. */
const reducer = createReducer(() => NOW);

const summarize = (data: WorkspaceData, now = NOW) => computeSummary(data, now, computeAllGoalProgress(data, now));

function storeWith(data: WorkspaceData): StoreState {
  const persisted = createDefaultState();
  return {
    status: "ready",
    issue: null,
    persisted: { ...persisted, activeWorkspace: "personal", workspaces: { demo: null, personal: data } },
  };
}
const personal = (state: StoreState) => state.persisted.workspaces.personal;

describe("balance", () => {
  it("is income − expenses − savings, in whole đồng", () => {
    const g = goal();
    const data = workspace(
      [
        tx({ type: "income", amount: 5_000_000 }),
        tx({ type: "expense", amount: 35_000 }),
        tx({ type: "saving", amount: 1_000_000, goalId: g.id }),
      ],
      [g],
    );
    const summary = summarize(data);
    assert.equal(summary.balance, 3_965_000);
    assert.ok(Number.isInteger(summary.balance));
  });

  it("conserves money: balance + goal savings = income − expenses", () => {
    const g = goal({ targetAmount: 15_000_000 });
    const data = workspace(
      [
        tx({ type: "income", amount: 5_000_000 }),
        tx({ type: "saving", amount: 3_000_000, goalId: g.id, opening: true }),
        tx({ type: "expense", amount: 200_000 }),
      ],
      [g],
    );
    const summary = summarize(data);
    const [progress] = computeAllGoalProgress(data, NOW);
    assert.equal(summary.balance, 1_800_000);
    assert.equal(progress.savedAmount, 3_000_000);
    assert.equal(summary.balance + progress.savedAmount, 5_000_000 - 200_000);
  });

  it("may be negative when spending exceeds what was recorded; safe-to-spend never is", () => {
    const summary = summarize(workspace([tx({ type: "income", amount: 100_000 }), tx({ type: "expense", amount: 300_000 })]));
    assert.equal(summary.balance, -200_000);
    assert.equal(summary.safeToSpend, 0);
    assert.equal(summary.dailyAllowance, 0);
  });

  it("does not drift through edit → edit → delete (always re-derived)", () => {
    const income = tx({ type: "income", amount: 100_000 });
    const expense = tx({ type: "expense", amount: 100_000 });
    let state = storeWith(workspace([income, expense]));
    state = reducer(state, { type: "updateTransaction", tx: { ...income, amount: 500_000 } });
    assert.equal(summarize(personal(state)).balance, 400_000);
    state = reducer(state, { type: "updateTransaction", tx: { ...expense, amount: 5_000_000 } });
    assert.equal(summarize(personal(state)).balance, -4_500_000);
    state = reducer(state, { type: "updateTransaction", tx: { ...expense, type: "income", category: "income", amount: 5_000_000 } });
    assert.equal(summarize(personal(state)).balance, 5_500_000);
    state = reducer(state, { type: "deleteTransaction", id: expense.id });
    assert.equal(summarize(personal(state)).balance, 500_000);
    state = reducer(state, { type: "deleteTransaction", id: expense.id });
    assert.equal(summarize(personal(state)).balance, 500_000, "deleting twice changes nothing");
  });

  it("edits of a saving move money between balance and goal without creating any", () => {
    const g = goal({ targetAmount: 10_000_000 });
    const saving = tx({ type: "saving", amount: 500_000, goalId: g.id });
    let state = storeWith(workspace([tx({ type: "income", amount: 3_000_000 }), saving], [g]));
    state = reducer(state, { type: "updateTransaction", tx: { ...saving, amount: 2_000_000 } });
    const summary = summarize(personal(state));
    const [progress] = computeAllGoalProgress(personal(state), NOW);
    assert.equal(summary.balance, 1_000_000);
    assert.equal(progress.savedAmount, 2_000_000);
  });
});

describe("opening balances", () => {
  it("count toward the balance but not toward income statistics", () => {
    const summary = summarize(
      workspace([tx({ type: "income", amount: 7_000_000, opening: true }), tx({ type: "income", amount: 1_000_000 })]),
    );
    assert.equal(summary.balance, 8_000_000);
    assert.equal(summary.monthIncome, 1_000_000);
    assert.equal(summary.monthCount, 1);
    assert.equal(computeMonth(workspace([tx({ type: "income", amount: 7_000_000, opening: true })]), NOW, NOW).income, 0);
  });
});

describe("period statistics", () => {
  it("totals categories for the current month only, with shares that sum to 1", () => {
    const data = workspace([
      tx({ type: "expense", amount: 60_000, category: "food" }),
      tx({ type: "expense", amount: 40_000, category: "transport" }),
      tx({ type: "expense", amount: 999_000, category: "food", date: "2026-09-30T23:59" }),
    ]);
    const summary = summarize(data);
    assert.equal(summary.monthExpense, 100_000);
    const food = summary.categories.find((c) => c.id === "food");
    assert.equal(food?.amount, 60_000);
    assert.equal(food?.lastMonthAmount, 999_000);
    const shareSum = summary.categories.reduce((sum, c) => sum + c.share, 0);
    assert.ok(Math.abs(shareSum - 1) < 1e-9);
  });

  it("compares the last 7 days with the 7 before and never divides by zero", () => {
    const noBaseline = summarize(workspace([tx({ type: "expense", amount: 50_000 })]));
    assert.equal(noBaseline.weekChange, null);
    const data = workspace([
      tx({ type: "expense", amount: 50_000, date: "2026-10-05T09:00" }),
      tx({ type: "expense", amount: 100_000, date: "2026-09-26T09:00" }),
    ]);
    const summary = summarize(data);
    assert.equal(summary.last7Total, 50_000);
    assert.equal(summary.prev7Total, 100_000);
    assert.equal(summary.weekChange, -0.5);
  });

  it("uses local calendar days at month boundaries", () => {
    const lastDay = new Date(2026, 9, 31, 23, 59);
    const firstDay = new Date(2026, 10, 1, 0, 1);
    const data = workspace([tx({ type: "expense", amount: 10_000, date: "2026-10-31T23:58" })]);
    assert.equal(summarize(data, lastDay).todayExpense, 10_000);
    assert.equal(summarize(data, lastDay).daysLeftInMonth, 1);
    assert.equal(summarize(data, firstDay).todayExpense, 0);
    assert.equal(summarize(data, firstDay).monthExpense, 0);
    assert.equal(summarize(data, firstDay).daysLeftInMonth, 30);
  });

  it("reserves this month's planned goal contribution before suggesting a daily amount", () => {
    const g = goal({ monthlyContribution: 1_000_000 });
    const data = workspace([tx({ type: "income", amount: 2_000_000 })], [g]);
    const summary = summarize(data);
    assert.equal(summary.goalCommitmentRemaining, 1_000_000);
    assert.equal(summary.safeToSpend, 1_000_000);
    assert.equal(summary.daysLeftInMonth, 27);
    assert.equal(summary.dailyAllowance, Math.floor(1_000_000 / 27 / 1000) * 1000);
  });

  it("simulates a purchase from the same numbers the dashboard shows", () => {
    const summary = summarize(workspace([tx({ type: "income", amount: 1_000_000 })]));
    const sim = simulatePurchase(summary, 300_000);
    assert.equal(sim.balanceAfter, 700_000);
    assert.equal(sim.exceedsBalance, false);
    assert.equal(simulatePurchase(summary, 2_000_000).exceedsBalance, true);
  });
});

describe("calendar boundaries", () => {
  it("year boundary: 31/12 23:59 vs 01/01 00:00", () => {
    const data = workspace([
      tx({ type: "expense", amount: 70_000, category: "food", date: "2026-12-31T23:59" }),
      tx({ type: "expense", amount: 30_000, category: "food", date: "2027-01-01T00:00" }),
    ]);
    const newYear = summarize(data, new Date(2027, 0, 1, 0, 5));
    assert.equal(newYear.todayExpense, 30_000);
    assert.equal(newYear.monthExpense, 30_000);
    assert.equal(newYear.categories.find((c) => c.id === "food")?.lastMonthAmount, 70_000);
    assert.equal(newYear.last7Total, 100_000);
    assert.equal(newYear.daysLeftInMonth, 31);
    const eve = summarize(data, new Date(2026, 11, 31, 23, 59));
    assert.equal(eve.todayExpense, 70_000);
  });

  it("a transaction's day never shifts with time zone: dates are local wall-clock strings", () => {
    const data = workspace([tx({ type: "expense", amount: 10_000, date: "2026-10-05T00:00" })]);
    assert.equal(summarize(data, new Date(2026, 9, 5, 0, 0)).todayExpense, 10_000);
    assert.equal(summarize(data, new Date(2026, 9, 4, 23, 59)).todayExpense, 0);
  });
});

describe("large histories", () => {
  it("5,000 transactions: correct totals, no duplicates, fast enough to recompute on every change", () => {
    const txs = [];
    let expected = 0;
    for (let i = 0; i < 5_000; i += 1) {
      const day = new Date(2026, 9, 5 - (i % 400));
      const date = `${day.getFullYear()}-${String(day.getMonth() + 1).padStart(2, "0")}-${String(day.getDate()).padStart(2, "0")}T12:00`;
      const isIncome = i % 10 === 0;
      txs.push(tx({ type: isIncome ? "income" : "expense", amount: isIncome ? 500_000 : 37_000, date }));
      expected += isIncome ? 500_000 : -37_000;
    }
    const data = workspace(txs);
    const started = performance.now();
    for (let run = 0; run < 20; run += 1) summarize(data);
    const perRun = (performance.now() - started) / 20;
    const summary = summarize(data);
    assert.equal(summary.balance, expected);
    assert.equal(new Set(txs.map((t) => t.id)).size, 5_000);
    assert.ok(perRun < 50, `recompute took ${perRun.toFixed(1)}ms`);
  });
});
