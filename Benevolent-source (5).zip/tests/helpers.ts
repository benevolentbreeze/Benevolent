import type { Goal } from "../src/types/goal";
import type { WorkspaceData } from "../src/types/state";
import type { Transaction } from "../src/types/transaction";

let counter = 0;

/** Fixed "now" for deterministic tests: Monday 5 Oct 2026, 15:00 local time. */
export const NOW = new Date(2026, 9, 5, 15, 0);

export function tx(partial: Partial<Transaction> & Pick<Transaction, "type" | "amount">): Transaction {
  counter += 1;
  const category = partial.type === "income" ? "income" : partial.type === "saving" ? "saving" : "food";
  return {
    id: `t${counter}`,
    category,
    note: "",
    date: "2026-10-05T10:00",
    createdAt: new Date(2026, 9, 5, 10, counter % 60).toISOString(),
    ...partial,
  } as Transaction;
}

export function goal(partial: Partial<Goal> = {}): Goal {
  counter += 1;
  return {
    id: `g${counter}`,
    name: "Laptop",
    targetAmount: 15_000_000,
    deadline: "2027-06-15",
    monthlyContribution: null,
    createdAt: new Date(2026, 6, 1).toISOString(),
    ...partial,
  };
}

export function workspace(transactions: Transaction[] = [], goals: Goal[] = []): WorkspaceData {
  return { transactions, goals };
}
