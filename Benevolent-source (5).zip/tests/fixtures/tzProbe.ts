/**
 * Run by hardening.test.ts in a child process under different TZ values.
 * Restores one fixed backup and prints what the user would see.
 */
import { computeAllGoalProgress, computeSummary } from "../../src/services/financialEngine";
import { parseBackup } from "../../src/services/storageService";

const backup = JSON.stringify({
  app: "benevolent",
  kind: "backup",
  exportedAt: "2026-10-05T08:00:00.000Z",
  state: {
    version: 1,
    activeWorkspace: "personal",
    workspaces: {
      demo: null,
      personal: {
        transactions: [
          { id: "a", amount: 5_000_000, type: "income", category: "income", note: "", date: "2026-10-01T00:30", createdAt: "2026-09-30T17:30:00.000Z" },
          { id: "b", amount: 45_000, type: "expense", category: "food", note: "", date: "2026-10-05T23:59", createdAt: "2026-10-05T16:59:00.000Z" },
          { id: "c", amount: 70_000, type: "expense", category: "transport", note: "", date: "2026-09-30T23:59", createdAt: "2026-09-30T16:59:00.000Z" },
          { id: "d", amount: 300_000, type: "saving", category: "saving", note: "", goalId: "g", date: "2026-10-02T12:00", createdAt: "2026-10-02T05:00:00.000Z" },
        ],
        goals: [{ id: "g", name: "Laptop", targetAmount: 15_000_000, deadline: "2027-02-28", monthlyContribution: 500_000, createdAt: "2026-06-30T23:30:00.000Z", startingAmount: 1_000_000 }],
      },
    },
    settings: {},
  },
});

const result = parseBackup(backup);
if (!result.ok) throw new Error(result.reason);
const data = result.state.workspaces.personal;
const now = new Date(2026, 9, 5, 15, 0);
const goals = computeAllGoalProgress(data, now);
const s = computeSummary(data, now, goals);
process.stdout.write(
  JSON.stringify({
    balance: s.balance,
    todayExpense: s.todayExpense,
    monthIncome: s.monthIncome,
    monthExpense: s.monthExpense,
    monthSaved: s.monthSaved,
    last7: s.last7.map((d) => [d.key, d.expense]),
    goal: goals.map((p) => [p.savedAmount, p.contributedThisMonth, p.monthsLeft, p.requiredMonthly, p.isOverdue]),
    days: data.transactions.filter((t) => !t.opening).map((t) => t.date),
  }),
);
