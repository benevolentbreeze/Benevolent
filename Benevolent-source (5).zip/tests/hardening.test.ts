/**
 * Red-team tests for the release: every reducer action is treated as hostile input,
 * accounting invariants are checked after long random action sequences, and storage,
 * dates, parsing and performance are pushed to their edges.
 */
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { describe, it } from "node:test";
import { fileURLToPath } from "node:url";
import { parseQuestion } from "../src/services/brainService";
import { computeAllGoalProgress, computeSummary } from "../src/services/financialEngine";
import { buildOpeningEntry, computeGoalProgress, openingFor } from "../src/services/goalService";
import { createDefaultState, localStorageAdapter, parseBackup, readPersistedState, serializeBackup } from "../src/services/storageService";
import { balanceOf, workspaceIsConsistent } from "../src/services/validation";
import { createReducer, type Action, type StoreState } from "../src/state/financeReducer";
import type { Goal } from "../src/types/goal";
import type { PersistedState, WorkspaceData } from "../src/types/state";
import type { Transaction } from "../src/types/transaction";
import { addMonths, parseLocal } from "../src/utils/date";
import { MAX_AMOUNT, parseAmountInput } from "../src/utils/money";
import { goal, NOW, tx, workspace } from "./helpers";

/** Fixed clock: date rules in the reducer never depend on the machine's real time. */
const reducer = createReducer(() => NOW);

function store(data: WorkspaceData): StoreState {
  const base = createDefaultState();
  return { status: "ready", issue: null, persisted: { ...base, activeWorkspace: "personal", workspaces: { demo: null, personal: data } } };
}
const personal = (state: StoreState) => state.persisted.workspaces.personal;
const run = (state: StoreState, action: unknown) => reducer(state, action as Action);
const totals = (data: WorkspaceData, now = NOW) => {
  const goals = computeAllGoalProgress(data, now);
  return { summary: computeSummary(data, now, goals), goals };
};

function deepFreeze<T>(value: T): T {
  if (value && typeof value === "object" && !Object.isFrozen(value)) {
    Object.freeze(value);
    for (const key of Object.keys(value)) deepFreeze((value as Record<string, unknown>)[key]);
  }
  return value;
}

/** Deterministic PRNG so random sequences are reproducible. */
function prng(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/* ------------------------------------------------------------------ */

describe("reducer boundary: hostile transactions are rejected without touching state", () => {
  const g = goal({ id: "goal_safe", targetAmount: 10_000_000 });
  const base = () => store(workspace([tx({ id: "seed_income", type: "income", amount: 5_000_000 })], [g]));
  const good = { id: "tx_ok", amount: 35_000, type: "expense", category: "food", note: "", date: "2026-10-05T12:00", createdAt: "2026-10-05T05:00:00.000Z" };

  const hostile: [string, unknown][] = [
    ["amount NaN", { ...good, amount: Number.NaN }],
    ["amount Infinity", { ...good, amount: Number.POSITIVE_INFINITY }],
    ["amount -Infinity", { ...good, amount: Number.NEGATIVE_INFINITY }],
    ["amount negative", { ...good, amount: -35_000 }],
    ["amount zero", { ...good, amount: 0 }],
    ["amount fraction", { ...good, amount: 35_000.5 }],
    ["amount string", { ...good, amount: "35000" }],
    ["amount over MAX", { ...good, amount: MAX_AMOUNT + 1 }],
    ["amount 2^53", { ...good, amount: 2 ** 53 }],
    ["type unknown", { ...good, type: "gift" }],
    ["expense with system category", { ...good, category: "income" }],
    ["expense with unknown category", { ...good, category: "rent" }],
    ["income with expense category", { ...good, type: "income", category: "food" }],
    ["saving without goal", { ...good, type: "saving", category: "saving" }],
    ["saving to missing goal", { ...good, type: "saving", category: "saving", goalId: "ghost" }],
    ["impossible date 30/02", { ...good, date: "2026-02-30T12:00" }],
    ["29/02 in a non-leap year", { ...good, date: "2027-02-29T12:00" }],
    ["hour 24", { ...good, date: "2026-10-05T24:00" }],
    ["date without time", { ...good, date: "2026-10-05" }],
    ["date garbage", { ...good, date: "yesterday" }],
    ["year 1900", { ...good, date: "1900-01-01T00:00" }],
    ["createdAt garbage", { ...good, createdAt: "not-a-time" }],
    ["createdAt huge string", { ...good, createdAt: "2026".repeat(1_000) }],
    ["id empty", { ...good, id: "" }],
    ["id path traversal", { ...good, id: "../../etc" }],
    ["id with spaces", { ...good, id: "tx 1" }],
    ["id 81 chars", { ...good, id: "a".repeat(81) }],
    ["id number", { ...good, id: 42 }],
    ["note not a string", { ...good, note: { toString: () => "x" } }],
    ["null", null],
    ["number", 42],
    ["array", [good]],
  ];

  for (const [label, payload] of hostile) {
    it(`addTransaction: ${label}`, () => {
      const state = base();
      assert.equal(run(state, { type: "addTransaction", tx: payload }), state);
    });
  }

  it("updateTransaction with each hostile payload is ignored", () => {
    const state = base();
    for (const [label, payload] of hostile) {
      // Point each payload at the existing record, except the ones whose id is the attack.
      const target = label.startsWith("id ") ? {} : { id: "seed_income" };
      const patched = payload && typeof payload === "object" && !Array.isArray(payload) ? { ...payload, ...target } : payload;
      assert.equal(run(state, { type: "updateTransaction", tx: patched }), state);
    }
  });

  it("an absurdly long note is accepted but bounded (never stored unbounded)", () => {
    const state = run(base(), { type: "addTransaction", tx: { ...good, note: "x".repeat(1_000_000) } });
    assert.equal(personal(state).transactions.find((t) => t.id === "tx_ok")?.note.length, 140);
  });

  it("unknown extra fields are stripped, prototype pollution is impossible", () => {
    const payload = JSON.parse(`{"id":"tx_p","amount":1000,"type":"expense","category":"food","note":"","date":"2026-10-05T12:00","createdAt":"2026-10-05T05:00:00.000Z","__proto__":{"polluted":true},"isAdmin":true}`);
    const state = run(base(), { type: "addTransaction", tx: payload });
    const stored = personal(state).transactions.find((t) => t.id === "tx_p");
    assert.ok(stored);
    assert.equal("isAdmin" in stored, false);
    assert.equal(({} as Record<string, unknown>).polluted, undefined);
  });

  it("a fabricated duplicate id never overwrites an existing record", () => {
    const state = base();
    const forged = { ...good, id: "seed_income", type: "income", category: "income", amount: 999_000_000 };
    assert.equal(run(state, { type: "addTransaction", tx: forged }), state);
  });

  it("an expense can be added (money was spent) even if the balance goes negative", () => {
    const state = run(base(), { type: "addTransaction", tx: { ...good, amount: 9_000_000 } });
    assert.equal(balanceOf(personal(state).transactions), -4_000_000);
  });

  it("an edit can never promote an ordinary record to an opening entry", () => {
    const contribution = tx({ id: "c1", type: "saving", amount: 100_000, goalId: g.id });
    const state = store(workspace([tx({ type: "income", amount: 5_000_000 }), contribution], [g]));
    assert.equal(run(state, { type: "updateTransaction", tx: { ...contribution, opening: true } }), state);
  });

  it("malformed action shapes and unknown action types are ignored", () => {
    const state = base();
    for (const action of [null, undefined, 1, "addTransaction", [], {}, { type: "dropTables" }, { type: "addTransaction" }, { type: "saveGoal" }, { type: "updateSettings" }, { type: "updateSettings", patch: null }]) {
      assert.equal(run(state, action), state);
    }
  });

  it("an unknown workspace target never creates a new workspace key", () => {
    const state = base();
    for (const workspaceId of ["evil", "__proto__", "constructor", 1, null]) {
      assert.equal(run(state, { type: "addTransaction", tx: good, workspace: workspaceId }), state);
      assert.equal(run(state, { type: "switchWorkspace", workspace: workspaceId }), state);
      assert.equal(run(state, { type: "resetWorkspace", workspace: workspaceId }), state);
    }
    assert.deepEqual(Object.keys(state.persisted.workspaces).sort(), ["demo", "personal"]);
  });
});

describe("reducer boundary: goals", () => {
  const start = () => store(workspace([tx({ id: "inc", type: "income", amount: 5_000_000 })]));
  const g = goal({ id: "goal_x", targetAmount: 10_000_000 });

  const badGoals: [string, Partial<Goal> | Record<string, unknown>][] = [
    ["target 0", { targetAmount: 0 }],
    ["target negative", { targetAmount: -1 }],
    ["target NaN", { targetAmount: Number.NaN }],
    ["target Infinity", { targetAmount: Number.POSITIVE_INFINITY }],
    ["target over MAX", { targetAmount: MAX_AMOUNT + 1 }],
    ["empty name", { name: "   " }],
    ["deadline impossible", { deadline: "2027-02-29" }],
    ["deadline garbage", { deadline: "soon" }],
    ["monthly negative", { monthlyContribution: -5 }],
    ["monthly NaN", { monthlyContribution: Number.NaN }],
    ["bad id", { id: "x y" }],
    ["createdAt garbage", { createdAt: "??" }],
  ];
  for (const [label, patch] of badGoals) {
    it(`saveGoal rejects ${label}`, () => {
      const state = start();
      assert.equal(run(state, { type: "saveGoal", goal: { ...g, ...patch }, opening: null }), state);
    });
  }

  it("goal names are bounded", () => {
    const state = run(start(), { type: "saveGoal", goal: { ...g, name: "M".repeat(10_000) }, opening: null });
    assert.equal(personal(state).goals[0].name.length, 40);
  });

  const opening = (amount: unknown, over: Record<string, unknown> = {}) => ({
    id: "open_x",
    amount,
    type: "saving",
    category: "saving",
    note: "",
    date: "2026-10-05T10:00",
    createdAt: "2026-10-05T03:00:00.000Z",
    goalId: g.id,
    opening: true,
    ...over,
  });

  const badOpenings: [string, unknown][] = [
    ["negative", opening(-1_000)],
    ["NaN", opening(Number.NaN)],
    ["Infinity", opening(Number.POSITIVE_INFINITY)],
    ["string", opening("1000000")],
    ["fraction", opening(1_000.5)],
    ["for another goal", opening(1_000_000, { goalId: "other" })],
    ["not marked as opening", opening(1_000_000, { opening: undefined })],
    ["typed as income", opening(1_000_000, { type: "income", category: "income" })],
    ["larger than the balance", opening(5_000_001)],
    ["larger than the target", opening(10_000_001)],
    ["id colliding with another record", opening(1_000_000, { id: "inc" })],
  ];
  for (const [label, payload] of badOpenings) {
    it(`saveGoal rejects an opening entry that is ${label}`, () => {
      const state = start();
      assert.equal(run(state, { type: "saveGoal", goal: g, opening: payload }), state);
    });
  }

  it("startingAmount 0 / = balance / = target", () => {
    let state = run(start(), { type: "saveGoal", goal: g, opening: null });
    assert.equal(totals(personal(state)).summary.balance, 5_000_000);
    state = run(start(), { type: "saveGoal", goal: g, opening: opening(5_000_000) });
    assert.equal(totals(personal(state)).summary.balance, 0);
    const small = { ...g, targetAmount: 2_000_000 };
    state = run(start(), { type: "saveGoal", goal: small, opening: opening(2_000_000) });
    const progress = totals(personal(state)).goals[0];
    assert.equal(progress.isComplete, true);
    assert.equal(progress.percent, 100);
    assert.equal(totals(personal(state)).summary.balance, 3_000_000);
  });

  it("lowering a target below what is already saved is rejected; raising it is allowed", () => {
    let state = run(start(), { type: "saveGoal", goal: g, opening: opening(3_000_000) });
    const existing = openingFor(g.id, personal(state).transactions) ?? null;
    assert.equal(run(state, { type: "saveGoal", goal: { ...g, targetAmount: 2_000_000 }, opening: existing }), state);
    state = run(state, { type: "saveGoal", goal: { ...g, targetAmount: 20_000_000 }, opening: existing });
    assert.equal(personal(state).goals[0].targetAmount, 20_000_000);
  });

  it("deleting a goal that does not exist (or with a hostile id) is a no-op", () => {
    const state = start();
    for (const id of ["ghost", "", "../x", 7, null]) assert.equal(run(state, { type: "deleteGoal", id }), state);
    assert.equal(run(state, { type: "setPrimaryGoal", id: "ghost" }), state);
  });
});

describe("contribution spam", () => {
  const setup = (income: number, target: number) => {
    const g = goal({ id: "goal_spam", targetAmount: target, deadline: "2027-06-01" });
    return { g, state: store(workspace([tx({ type: "income", amount: income })], [g])) };
  };
  let n = 0;
  const contribution = (goalId: string, amount: number, id = `spam_${(n += 1)}`) =>
    ({ id, amount, type: "saving", category: "saving", note: "", date: "2026-10-05T12:00", createdAt: new Date(2026, 9, 5, 12, 0, n % 60).toISOString(), goalId }) as Transaction;

  it("100 rapid clicks each worth the whole remaining amount: only the first lands", () => {
    let { g, state } = setup(50_000_000, 3_000_000);
    for (let i = 0; i < 100; i += 1) state = run(state, { type: "addTransaction", tx: contribution(g.id, 3_000_000) });
    const { goals, summary } = totals(personal(state));
    assert.equal(goals[0].savedAmount, 3_000_000);
    assert.equal(summary.balance, 47_000_000);
  });

  it("100 rapid 100k clicks with a 1M balance: stops exactly at the balance", () => {
    let { g, state } = setup(1_000_000, 50_000_000);
    for (let i = 0; i < 100; i += 1) state = run(state, { type: "addTransaction", tx: contribution(g.id, 100_000) });
    const { goals, summary } = totals(personal(state));
    assert.equal(goals[0].savedAmount, 1_000_000);
    assert.equal(summary.balance, 0);
  });

  it("10 clicks / keyboard resubmission of the same record: applied once", () => {
    let { g, state } = setup(1_000_000, 50_000_000);
    const same = contribution(g.id, 200_000, "kbd_1");
    for (let i = 0; i < 10; i += 1) state = run(state, { type: "addTransaction", tx: same });
    assert.equal(totals(personal(state)).goals[0].savedAmount, 200_000);
  });

  it("contribution equal to the balance is allowed; one more đồng is not", () => {
    let { g, state } = setup(1_000_000, 50_000_000);
    const over = run(state, { type: "addTransaction", tx: contribution(g.id, 1_000_001) });
    assert.equal(over, state);
    state = run(state, { type: "addTransaction", tx: contribution(g.id, 1_000_000) });
    assert.equal(totals(personal(state)).summary.balance, 0);
  });

  it("after completion nothing more can be added; after the deadline contributions still work", () => {
    let { g, state } = setup(10_000_000, 1_000_000);
    state = run(state, { type: "addTransaction", tx: contribution(g.id, 1_000_000) });
    const done = state;
    state = run(state, { type: "addTransaction", tx: contribution(g.id, 1) });
    assert.equal(state, done);

    const overdue = goal({ id: "goal_late", targetAmount: 5_000_000, deadline: "2026-09-01" });
    let late = store(workspace([tx({ type: "income", amount: 1_000_000 })], [overdue]));
    late = run(late, { type: "addTransaction", tx: contribution(overdue.id, 300_000) });
    const progress = totals(personal(late)).goals[0];
    assert.equal(progress.savedAmount, 300_000);
    assert.equal(progress.isOverdue, true);
  });

  it("0, negative, NaN and Infinity contributions are rejected", () => {
    const { g, state } = setup(1_000_000, 50_000_000);
    for (const amount of [0, -100_000, Number.NaN, Number.POSITIVE_INFINITY]) {
      assert.equal(run(state, { type: "addTransaction", tx: { ...contribution(g.id, 1), amount } }), state);
    }
  });

  it("editing a contribution upward is limited by balance and target, downward always works", () => {
    let { g, state } = setup(1_000_000, 2_000_000);
    const c = contribution(g.id, 500_000);
    state = run(state, { type: "addTransaction", tx: c });
    assert.equal(run(state, { type: "updateTransaction", tx: { ...c, amount: 1_000_001 } }), state);
    state = run(state, { type: "updateTransaction", tx: { ...c, amount: 1_000_000 } });
    assert.equal(totals(personal(state)).summary.balance, 0);
    state = run(state, { type: "updateTransaction", tx: { ...c, amount: 100_000 } });
    assert.equal(totals(personal(state)).summary.balance, 900_000);
  });

  it("with an already negative balance, savings can shrink but never grow", () => {
    const g = goal({ id: "goal_neg", targetAmount: 50_000_000 });
    const c = tx({ id: "neg_c", type: "saving", amount: 500_000, goalId: g.id });
    let state = store(workspace([tx({ type: "income", amount: 1_000_000 }), c, tx({ type: "expense", amount: 2_000_000 })], [g]));
    assert.equal(balanceOf(personal(state).transactions), -1_500_000);
    assert.equal(run(state, { type: "addTransaction", tx: contribution(g.id, 1_000) }), state);
    assert.equal(run(state, { type: "updateTransaction", tx: { ...c, amount: 500_001 } }), state);
    state = run(state, { type: "updateTransaction", tx: { ...c, amount: 400_000 } });
    assert.equal(balanceOf(personal(state).transactions), -1_400_000);
  });
});

describe("settings, workspaces and whole-state replacement", () => {
  it("settings patches are type-checked and bounded", () => {
    const state = store(workspace());
    const next = run(state, { type: "updateSettings", patch: { displayName: "A".repeat(5_000), motion: "warp", hideAmounts: "yes", nudges: 0, isAdmin: true } });
    assert.equal(next.persisted.settings.displayName.length, 40);
    assert.equal(next.persisted.settings.motion, state.persisted.settings.motion);
    assert.equal(next.persisted.settings.hideAmounts, state.persisted.settings.hideAmounts);
    assert.equal(next.persisted.settings.nudges, state.persisted.settings.nudges);
    assert.equal("isAdmin" in next.persisted.settings, false);
  });

  it("replaceAll / external with garbage are ignored; hydrate with garbage starts clean and says so", () => {
    const state = store(workspace([tx({ type: "income", amount: 1_000 })]));
    for (const garbage of [null, 1, "x", {}, { version: 99 }, { version: 2, workspaces: { personal: "no" } }]) {
      assert.equal(run(state, { type: "replaceAll", persisted: garbage }), state);
      assert.equal(run(state, { type: "external", persisted: garbage }), state);
    }
    const hydrated = run({ ...state, status: "loading" }, { type: "hydrate", persisted: { version: 2 }, issue: null });
    assert.equal(hydrated.status, "ready");
    assert.equal(hydrated.issue, "corrupted");
    assert.equal(personal(hydrated).transactions.length, 0);
  });

  it("replaceAll filters hostile records inside an otherwise valid state", () => {
    const state = store(workspace());
    const g = goal({ id: "g_ok" });
    const persisted = {
      ...state.persisted,
      workspaces: {
        demo: null,
        personal: { goals: [g], transactions: [tx({ type: "income", amount: 1_000 }), { ...tx({ type: "expense", amount: 1 }), amount: Number.NaN }, tx({ type: "saving", amount: 10, goalId: "ghost" })] },
      },
    };
    const next = run(state, { type: "replaceAll", persisted });
    assert.equal(personal(next).transactions.length, 1);
    assert.ok(workspaceIsConsistent(personal(next)));
  });
});

/* ------------------------------------------------------------------ */

describe("determinism", () => {
  it("calculate(state) === calculate(state), and calculation never mutates its input", () => {
    const g = goal({ id: "g_det", targetAmount: 20_000_000, monthlyContribution: 1_000_000 });
    const data = deepFreeze(
      workspace(
        [
          tx({ type: "income", amount: 8_000_000, date: "2026-10-01T09:00" }),
          tx({ type: "expense", amount: 45_000, date: "2026-10-04T12:00" }),
          tx({ type: "saving", amount: 2_000_000, goalId: g.id, opening: true, date: "2026-08-01T09:00" }),
          tx({ type: "saving", amount: 500_000, goalId: g.id, date: "2026-10-02T09:00" }),
        ],
        [g],
      ),
    );
    const now = deepFreeze(new Date(NOW));
    const first = JSON.stringify(totals(data, now));
    const second = JSON.stringify(totals(data, now));
    assert.equal(first, second);
  });

  it("the reducer never mutates the state it receives", () => {
    const g = goal({ id: "g_frozen" });
    const state = deepFreeze(store(workspace([tx({ type: "income", amount: 5_000_000 })], [g])));
    const snapshot = JSON.stringify(state);
    const actions: Action[] = [
      { type: "addTransaction", tx: tx({ type: "expense", amount: 1_000 }) },
      { type: "addTransaction", tx: tx({ type: "saving", amount: 1_000, goalId: g.id }) },
      { type: "saveGoal", goal: { ...g, name: "Đổi tên" }, opening: buildOpeningEntry(g.id, 1_000, undefined, NOW) },
      { type: "deleteGoal", id: g.id },
      { type: "updateSettings", patch: { hideAmounts: true } },
      { type: "switchWorkspace", workspace: "personal" },
    ];
    let current: StoreState = state;
    for (const action of actions) current = reducer(current, action);
    assert.equal(JSON.stringify(state), snapshot);
  });

  it("the same action sequence from the same start gives the same state", () => {
    const sequence = (seed: number) => {
      const random = prng(seed);
      const g = goal({ id: "g_seq", targetAmount: 30_000_000 });
      let state = store(workspace([tx({ id: "seq_inc", type: "income", amount: 10_000_000, createdAt: "2026-10-05T01:00:00.000Z" })], [g]));
      for (let i = 0; i < 300; i += 1) {
        const amount = Math.floor(random() * 500_000) + 1;
        const kind = random();
        const id = `seq_${seed}_${i}`;
        const createdAt = new Date(2026, 9, 5, 10, 0, i % 60).toISOString();
        const base = { id, amount, note: "", date: "2026-10-05T10:00", createdAt };
        state = run(state, { type: "addTransaction", tx: kind < 0.3 ? { ...base, type: "income", category: "income" } : kind < 0.7 ? { ...base, type: "expense", category: "food" } : { ...base, type: "saving", category: "saving", goalId: g.id } });
      }
      return JSON.stringify(state.persisted.workspaces.personal);
    };
    assert.equal(sequence(7), sequence(7));
  });
});

describe("invariants under 3,000 random (partly hostile) actions", () => {
  it("unique ids, no orphans, ≤1 opening per goal, saved ≤ target, balance = income − expense − savings", () => {
    const random = prng(20261221);
    const pick = <T>(items: readonly T[]): T => items[Math.floor(random() * items.length)];
    let state = store(workspace());
    const goalIds = ["ga", "gb", "gc"];
    const evilAmounts = [0, -1, Number.NaN, Number.POSITIVE_INFINITY, 1.5, MAX_AMOUNT + 1];

    for (let i = 0; i < 3_000; i += 1) {
      const data = personal(state);
      const before = balanceOf(data.transactions);
      const roll = random();
      const amount = random() < 0.08 ? pick(evilAmounts) : Math.floor(random() * 3_000_000) + 1;
      const id = random() < 0.05 && data.transactions.length ? pick(data.transactions).id : `r${i}`;
      const base = { id, amount, note: "", date: `2026-${String(1 + Math.floor(random() * 10)).padStart(2, "0")}-15T12:00`, createdAt: new Date(2026, 0, 1, 0, 0, i).toISOString() };
      let action: unknown;
      if (roll < 0.25) action = { type: "addTransaction", tx: { ...base, type: "income", category: "income" } };
      else if (roll < 0.5) action = { type: "addTransaction", tx: { ...base, type: "expense", category: pick(["food", "study", "rent"]) } };
      else if (roll < 0.7) action = { type: "addTransaction", tx: { ...base, type: "saving", category: "saving", goalId: pick([...goalIds, "ghost"]) } };
      else if (roll < 0.78 && data.transactions.length) action = { type: "updateTransaction", tx: { ...pick(data.transactions), amount } };
      else if (roll < 0.84 && data.transactions.length) action = { type: "deleteTransaction", id: pick(data.transactions).id };
      else if (roll < 0.94) {
        const gid = pick(goalIds);
        const existing = data.goals.find((item) => item.id === gid);
        const g = { ...(existing ?? goal({ id: gid })), targetAmount: Math.floor(random() * 20_000_000) + 1 };
        const openingAmount = Math.floor(random() * 4_000_000);
        action = { type: "saveGoal", goal: g, opening: buildOpeningEntry(gid, openingAmount, openingFor(gid, data.transactions), NOW) };
      } else action = { type: "deleteGoal", id: pick([...goalIds, "ghost"]) };

      const next = run(state, action);
      const after = personal(next);
      assert.ok(workspaceIsConsistent(after), `structure broken at step ${i}`);

      const savedBefore = data.transactions.filter((t) => t.type === "saving").reduce((s, t) => s + t.amount, 0);
      const savedAfter = after.transactions.filter((t) => t.type === "saving").reduce((s, t) => s + t.amount, 0);
      const balanceAfter = balanceOf(after.transactions);
      if (savedAfter > savedBefore) assert.ok(balanceAfter >= Math.min(0, before), `saving pushed balance negative at step ${i}`);

      const { summary, goals } = totals(after);
      const income = after.transactions.filter((t) => t.type === "income").reduce((s, t) => s + t.amount, 0);
      const expense = after.transactions.filter((t) => t.type === "expense").reduce((s, t) => s + t.amount, 0);
      assert.equal(summary.balance, income - expense - savedAfter, `balance identity at step ${i}`);
      assert.equal(goals.reduce((s, p) => s + p.savedAmount, 0), savedAfter, `every saving belongs to a goal at step ${i}`);
      for (const progress of goals) {
        assert.ok(Number.isFinite(progress.percent) && progress.percent >= 0 && progress.percent <= 100, `percent at step ${i}`);
        assert.ok(progress.savedAmount <= progress.goal.targetAmount, `goal over target at step ${i}`);
      }
      for (const value of [summary.balance, summary.dailyAllowance, summary.safeToSpend, summary.monthExpense]) assert.ok(Number.isFinite(value));
      state = next;
    }
  });
});

/* ------------------------------------------------------------------ */

describe("startingAmount (v1) red team: migration, edit, delete, backup", () => {
  const v1 = (startingAmount: unknown, targetAmount = 10_000_000) => ({
    version: 1,
    activeWorkspace: "personal",
    workspaces: {
      demo: null,
      personal: {
        transactions: [{ id: "inc1", amount: 4_000_000, type: "income", category: "income", note: "", date: "2026-09-01T09:00", createdAt: "2026-09-01T02:00:00.000Z" }],
        goals: [{ id: "g1", name: "Xe", targetAmount, deadline: "2027-06-01", monthlyContribution: null, createdAt: "2026-06-01T03:00:00.000Z", startingAmount }],
      },
    },
    settings: {},
  });
  const migrate = (value: unknown) => {
    const result = readPersistedState(value);
    assert.ok(result.ok);
    return result.state.workspaces.personal;
  };

  it("0, malformed, negative, fractional, huge: no opening entries, balance untouched", () => {
    for (const bad of [0, "abc", null, -5, 1.5, 1e20, Number.NaN, {}, [1]]) {
      const data = migrate(v1(bad));
      assert.equal(data.transactions.length, 1, String(bad));
      assert.equal(totals(data).summary.balance, 4_000_000);
    }
  });

  it("> 0: balance unchanged, goal shows it as saved, opening excluded from income statistics", () => {
    const data = migrate(v1(3_000_000));
    const { summary, goals } = totals(data);
    assert.equal(summary.balance, 4_000_000);
    assert.equal(goals[0].savedAmount, 3_000_000);
    assert.equal(goals[0].openingAmount, 3_000_000);
    assert.equal(summary.transactionCount, 1);
  });

  it("= target and > target: complete, percent capped at 100, still readable", () => {
    for (const [starting, target] of [[10_000_000, 10_000_000], [12_000_000, 10_000_000]]) {
      const progress = totals(migrate(v1(starting, target))).goals[0];
      assert.equal(progress.isComplete, true);
      assert.equal(progress.percent, 100);
      assert.equal(progress.remaining, 0);
    }
  });

  it("> target legacy goal: can be reduced or renamed with a higher target, never grown", () => {
    let state = store(migrate(v1(12_000_000, 10_000_000)));
    const g = personal(state).goals[0];
    const existing = openingFor(g.id, personal(state).transactions);
    assert.ok(existing);
    assert.equal(run(state, { type: "addTransaction", tx: tx({ type: "saving", amount: 1_000, goalId: g.id }) }), state);
    state = run(state, { type: "saveGoal", goal: g, opening: { ...existing, amount: 9_000_000 } });
    assert.equal(totals(personal(state)).goals[0].savedAmount, 9_000_000);
  });

  it("migrated goal deleted: its saved money returns to the balance, nothing orphaned", () => {
    let state = store(migrate(v1(3_000_000)));
    state = run(state, { type: "deleteGoal", id: "g1" });
    assert.ok(workspaceIsConsistent(personal(state)));
    assert.equal(totals(personal(state)).summary.balance, 7_000_000);
  });

  it("reading is idempotent: re-reading a migrated state never duplicates opening entries", () => {
    const once = readPersistedState(v1(3_000_000));
    assert.ok(once.ok);
    const twice = readPersistedState(JSON.parse(JSON.stringify(once.state)));
    assert.ok(twice.ok);
    assert.deepEqual(twice.state, once.state);
    assert.equal(twice.dropped, 0);
  });

  it("backup → restore round trip keeps opening entries exactly once", () => {
    const state = readPersistedState(v1(3_000_000));
    assert.ok(state.ok);
    const restored = parseBackup(serializeBackup(state.state));
    assert.ok(restored.ok);
    assert.deepEqual(restored.state, state.state);
    const again = parseBackup(serializeBackup(restored.state));
    assert.ok(again.ok);
    assert.deepEqual(again.state, state.state);
  });

  it("corrupted v1 states: broken goals and transactions are dropped, the rest survives", () => {
    const broken = v1(3_000_000) as { workspaces: { personal: { transactions: unknown[]; goals: unknown[] } } };
    broken.workspaces.personal.goals.push({ id: "g2", name: "", targetAmount: -1 }, null, "goal", { id: "g1", name: "dup", targetAmount: 5, deadline: "2027-01-01", createdAt: "2026-01-01T00:00:00Z", startingAmount: 1 });
    broken.workspaces.personal.transactions.push(null, 5, { id: "x" }, { id: "inc1", amount: 1, type: "income", category: "income", note: "", date: "2026-09-01T09:00", createdAt: "2026-09-01T02:00:00.000Z" });
    const result = readPersistedState(broken);
    assert.ok(result.ok);
    const data = result.state.workspaces.personal;
    assert.ok(workspaceIsConsistent(data));
    assert.equal(data.goals.length, 1);
    assert.equal(totals(data).summary.balance, 4_000_000);
    assert.ok(result.dropped >= 6);
  });

  it("totally corrupted v1 shapes are reported invalid, never thrown", () => {
    for (const value of [{ version: 1 }, { version: 1, workspaces: null }, { version: 1, workspaces: { personal: { transactions: "x", goals: [] } } }, { version: 1.5, workspaces: {} }, { version: -1, workspaces: {} }]) {
      assert.equal(readPersistedState(value).ok, false);
    }
  });
});

/* ------------------------------------------------------------------ */

describe("dates: leap years, February, month ends", () => {
  it("29 February exists only in leap years", () => {
    assert.ok(parseLocal("2028-02-29"));
    assert.ok(parseLocal("2000-02-29"));
    assert.equal(parseLocal("2027-02-29"), null);
    assert.equal(parseLocal("2100-02-29"), null);
    assert.equal(parseLocal("2026-04-31"), null);
  });

  it("adding months clamps to the month's last day (31/01 → 28 or 29/02)", () => {
    assert.equal(addMonths(new Date(2027, 0, 31), 1).getDate(), 28);
    assert.equal(addMonths(new Date(2028, 0, 31), 1).getDate(), 29);
    assert.equal(addMonths(new Date(2028, 1, 29), 12).getDate(), 28);
  });

  it("summary on 29/02 of a leap year and at month ends stays finite and correct", () => {
    const data = workspace([
      tx({ type: "income", amount: 3_000_000, date: "2028-02-01T09:00" }),
      tx({ type: "expense", amount: 100_000, date: "2028-02-29T08:00" }),
      tx({ type: "expense", amount: 50_000, date: "2028-02-28T08:00" }),
    ]);
    const leap = totals(data, new Date(2028, 1, 29, 20, 0)).summary;
    assert.equal(leap.todayExpense, 100_000);
    assert.equal(leap.monthExpense, 150_000);
    assert.equal(leap.daysLeftInMonth, 1);
    assert.ok(Number.isFinite(leap.dailyAllowance) && leap.dailyAllowance >= 0);
    const march = totals(data, new Date(2028, 2, 1, 0, 1)).summary;
    assert.equal(march.monthExpense, 0);
    assert.equal(march.todayExpense, 0);
  });

  it("a goal due on 29/02 has a sensible months-left and required monthly amount", () => {
    const g = goal({ targetAmount: 12_000_000, deadline: "2028-02-29" });
    const progress = computeGoalProgress(g, [], NOW);
    assert.ok(progress.monthsLeft > 16 && progress.monthsLeft < 18);
    assert.ok(Number.isFinite(progress.requiredMonthly) && progress.requiredMonthly > 0);
  });
});

describe("restore across time zones", () => {
  it("the same backup gives the same balance, goals and calendar days in Hanoi, Los Angeles and UTC", () => {
    const script = fileURLToPath(new URL("./fixtures/tzProbe.ts", import.meta.url));
    const outputs = ["Asia/Ho_Chi_Minh", "America/Los_Angeles", "UTC", "Pacific/Kiritimati"].map((zone) => {
      const result = spawnSync(process.execPath, [...process.execArgv, script], { env: { ...process.env, TZ: zone }, encoding: "utf8" });
      assert.equal(result.status, 0, result.stderr);
      return result.stdout.trim();
    });
    for (const output of outputs.slice(1)) assert.equal(output, outputs[0]);
  });
});

/* ------------------------------------------------------------------ */

describe("storage adapter: quota, read failure, write failure", () => {
  type FakeStore = Map<string, string>;
  function installWindow(options: { getFails?: boolean; setFails?: boolean; initial?: Record<string, string> }) {
    const store: FakeStore = new Map(Object.entries(options.initial ?? {}));
    const quota = () => {
      const error = new Error("QuotaExceededError");
      error.name = "QuotaExceededError";
      return error;
    };
    const localStorage = {
      getItem: (key: string) => {
        if (options.getFails) throw new Error("SecurityError");
        return store.get(key) ?? null;
      },
      setItem: (key: string, value: string) => {
        if (options.setFails) throw quota();
        store.set(key, value);
      },
      removeItem: (key: string) => void store.delete(key),
    };
    (globalThis as { window?: unknown }).window = { localStorage, addEventListener() {}, removeEventListener() {} };
    return store;
  }
  const KEY = "benevolent:state:v1";

  it("blocked storage (private mode) loads as unavailable, never throws", async () => {
    installWindow({ getFails: true });
    assert.deepEqual(await localStorageAdapter.load(), { status: "unavailable" });
  });

  it("a full quota makes save reject (so the app can warn), it does not throw synchronously", async () => {
    installWindow({ setFails: true });
    const saving = localStorageAdapter.save(createDefaultState());
    await assert.rejects(saving, /Quota/);
  });

  it("corrupted data is set aside before anything else is written", async () => {
    const store = installWindow({ initial: { [KEY]: "{not json" } });
    const result = await localStorageAdapter.load();
    assert.equal(result.status, "corrupted");
    assert.ok(result.status === "corrupted" && result.preservedKey);
    assert.equal(store.get(result.status === "corrupted" ? (result.preservedKey ?? "") : ""), "{not json");
    assert.equal(store.has(KEY), false);
  });

  it("if it cannot be set aside (quota full), the original is left exactly where it was", async () => {
    const store = installWindow({ setFails: true, initial: { [KEY]: "{not json" } });
    const result = await localStorageAdapter.load();
    assert.deepEqual(result, { status: "corrupted", preservedKey: null });
    assert.equal(store.get(KEY), "{not json");
  });

  it("state from a newer app version is preserved, not overwritten", async () => {
    const newer = JSON.stringify({ ...createDefaultState(), version: 99 });
    const store = installWindow({ initial: { [KEY]: newer } });
    const result = await localStorageAdapter.load();
    assert.equal(result.status, "corrupted");
    assert.ok([...store.keys()].some((key) => key.startsWith("benevolent:newer:") && store.get(key) === newer));
  });

  it("valid state round-trips through the adapter unchanged", async () => {
    installWindow({});
    const state: PersistedState = { ...createDefaultState(), activeWorkspace: "personal" };
    state.workspaces.personal = workspace([tx({ type: "income", amount: 1_000 })]);
    await localStorageAdapter.save(state);
    const loaded = await localStorageAdapter.load();
    assert.equal(loaded.status, "ok");
    assert.deepEqual(loaded.status === "ok" && loaded.state, state);
    delete (globalThis as { window?: unknown }).window;
  });
});

/* ------------------------------------------------------------------ */

describe("performance: 10,000 transactions", () => {
  const build = () => {
    const g = goal({ id: "g_perf", targetAmount: MAX_AMOUNT });
    const txs: Transaction[] = [];
    for (let i = 0; i < 10_000; i += 1) {
      const day = new Date(2026, 9, 5 - (i % 700));
      const date = `${day.getFullYear()}-${String(day.getMonth() + 1).padStart(2, "0")}-${String(day.getDate()).padStart(2, "0")}T${String(i % 24).padStart(2, "0")}:00`;
      const type = i % 10 === 0 ? "income" : i % 25 === 0 ? "saving" : "expense";
      txs.push({ id: `p${i}`, amount: type === "income" ? 2_000_000 : 37_000, type, category: type === "expense" ? "food" : type, note: "", date, createdAt: new Date(2026, 0, 1, 0, 0, i).toISOString(), ...(type === "saving" ? { goalId: g.id } : {}) } as Transaction);
    }
    return workspace(txs, [g]);
  };

  it("summary + goals, storage read, backup round trip and one reducer step stay fast", () => {
    const data = build();
    let started = performance.now();
    for (let i = 0; i < 5; i += 1) totals(data);
    const calc = (performance.now() - started) / 5;

    const persisted = { ...createDefaultState(), activeWorkspace: "personal" as const, workspaces: { demo: null, personal: data } };
    const json = JSON.stringify(persisted);
    started = performance.now();
    const read = readPersistedState(JSON.parse(json));
    const load = performance.now() - started;
    assert.ok(read.ok);
    assert.equal(read.state.workspaces.personal.transactions.length, 10_000);

    started = performance.now();
    const restored = parseBackup(serializeBackup(persisted));
    const backup = performance.now() - started;
    assert.ok(restored.ok);

    const state = store(read.state.workspaces.personal);
    started = performance.now();
    const next = reducer(state, { type: "addTransaction", tx: tx({ type: "expense", amount: 1_000 }) });
    const step = performance.now() - started;
    assert.equal(personal(next).transactions.length, 10_001);

    assert.ok(calc < 150, `calculation ${calc.toFixed(1)}ms`);
    assert.ok(load < 500, `load ${load.toFixed(1)}ms`);
    assert.ok(backup < 1_000, `backup ${backup.toFixed(1)}ms`);
    assert.ok(step < 100, `reducer step ${step.toFixed(1)}ms`);
    assert.equal(totals(data).summary.balance, balanceOf(data.transactions));
  });
});

/* ------------------------------------------------------------------ */

describe("amount parsing: where it is used and how it handles ambiguity", () => {
  it("money entry fields are digits-only (AmountField): separators and letters are ignored, never interpreted", () => {
    assert.equal(parseAmountInput("300,000"), 300_000);
    assert.equal(parseAmountInput("300.000"), 300_000);
    assert.equal(parseAmountInput("-50000"), 50_000);
    assert.equal(parseAmountInput(""), 0);
    assert.ok(parseAmountInput("9".repeat(40)) <= 9_999_999_999_999);
  });

  it("Brain questions: Vietnamese shorthand", () => {
    const cases: [string, number | undefined][] = [
      ["mua 300,000 được không", 300_000],
      ["mua 300.000 được không", 300_000],
      ["mua 300000 được không", 300_000],
      ["mua 1tr2 được không", 1_200_000],
      ["mua 1 tr 2 được không", 1_200_000],
      ["mua 1tr25 được không", 1_250_000],
      ["mua 1.2 triệu được không", 1_200_000],
      ["mua 1,5tr được không", 1_500_000],
      ["mua 1.5tr được không", 1_500_000],
      ["mua 1.500 được không", 1_500],
      ["mua 1.500.000 được không", 1_500_000],
      ["mua 1,500,000 được không", 1_500_000],
      ["mua 12.5k được không", 12_500],
    ];
    for (const [question, expected] of cases) assert.equal(parseQuestion(question).amount, expected, question);
  });

  it("1.500 (dot = thousands) and 1.5tr (decimal before a unit) are never confused", () => {
    assert.equal(parseQuestion("mua 1.500 được không").amount, 1_500);
    assert.equal(parseQuestion("mua 1.5tr được không").amount, 1_500_000);
  });

  it("unreadable or unsafe amounts are left out (Brain then asks), never guessed", () => {
    for (const question of ["mua 999999999999999999999 được không", "mua 1e9 được không", "mua 0đ được không", "mua 1,234,567.89 được không"]) {
      assert.equal(parseQuestion(question).amount, undefined, question);
    }
  });
});

describe("demo workspace is internally consistent on any day", () => {
  it("leap day, year end and today all produce a valid workspace", async () => {
    const { createDemoWorkspace } = await import("../src/data/demoSeed");
    for (const day of [new Date(2028, 1, 29, 9), new Date(2026, 11, 31, 23, 59), new Date(2027, 0, 1, 0, 1), NOW]) {
      const data = createDemoWorkspace(day);
      assert.ok(workspaceIsConsistent(data));
      const { summary, goals } = totals(data, day);
      assert.ok(summary.balance >= 0);
      for (const progress of goals) assert.ok(progress.savedAmount <= progress.goal.targetAmount);
      const round = readPersistedState({ ...createDefaultState(), workspaces: { demo: data, personal: workspace() } });
      assert.ok(round.ok);
      assert.equal(round.dropped, 0);
    }
  });
});
