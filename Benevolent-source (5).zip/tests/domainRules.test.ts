/**
 * Regression tests for two domain rules enforced below the UI:
 * 1. An opening entry's accounting identity (opening, type, category, goal) is immutable.
 * 2. No mutation may record money on a day that hasn't happened yet.
 * The clock is always injected, so nothing here depends on the machine's real time.
 */
import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { buildContext } from "../src/services/brainService";
import { computeAllGoalProgress, computeSummary } from "../src/services/financialEngine";
import { createDefaultState, parseBackup, readPersistedState, serializeBackup } from "../src/services/storageService";
import { validateDraft } from "../src/services/transactionService";
import { workspaceIsConsistent } from "../src/services/validation";
import { createReducer, type Action, type StoreState } from "../src/state/financeReducer";
import type { WorkspaceData } from "../src/types/state";
import type { Transaction } from "../src/types/transaction";
import { goal, NOW, tx, workspace } from "./helpers";

/** NOW is Monday 5 Oct 2026, 15:00 local time. */
const reducer = createReducer(() => NOW);
const run = (state: StoreState, action: unknown, reduce = reducer) => reduce(state, action as Action);

function store(data: WorkspaceData): StoreState {
  const base = createDefaultState();
  return { status: "ready", issue: null, persisted: { ...base, activeWorkspace: "personal", workspaces: { demo: null, personal: data } } };
}
const personal = (state: StoreState) => state.persisted.workspaces.personal;

/** Every figure a user (or Brain) can see, so an attack can't hide in one of them. */
function figures(data: WorkspaceData) {
  const goals = computeAllGoalProgress(data, NOW);
  const summary = computeSummary(data, NOW, goals);
  const brain = buildContext(summary, goals, false);
  return {
    balance: summary.balance,
    totalIncome: summary.totalIncome,
    totalExpense: summary.totalExpense,
    totalSaved: summary.totalSaved,
    monthIncome: summary.monthIncome,
    safeToSpend: summary.safeToSpend,
    dailyAllowance: summary.dailyAllowance,
    goals: goals.map((p) => ({ id: p.goal.id, saved: p.savedAmount, opening: p.openingAmount, contributed: p.contributedAmount, percent: p.percent })),
    brain: Object.fromEntries(Object.entries(brain.facts).map(([key, value]) => [key, value.value])),
  };
}

/* A workspace with every kind of record:
   ordinary income 5M, opening income ("Số dư ban đầu") 2M, opening saving 1M → goal A,
   contribution 200k → goal A, expense 150k, and an empty goal B. */
const goalA = goal({ id: "goal_a", targetAmount: 10_000_000 });
const goalB = goal({ id: "goal_b", targetAmount: 10_000_000 });
const income = tx({ id: "inc", type: "income", amount: 5_000_000, date: "2026-09-01T09:00" });
const openingIncome = tx({ id: "open_in", type: "income", amount: 2_000_000, opening: true, date: "2026-07-01T09:00" });
const openingSaving = tx({ id: "open_sv", type: "saving", amount: 1_000_000, goalId: goalA.id, opening: true, date: "2026-07-01T09:00" });
const contribution = tx({ id: "contrib", type: "saving", amount: 200_000, goalId: goalA.id, date: "2026-10-02T09:00" });
const expense = tx({ id: "exp", type: "expense", amount: 150_000, category: "food", date: "2026-10-04T12:00" });
const start = () => store(workspace([income, openingIncome, openingSaving, contribution, expense], [goalA, goalB]));

describe("opening entries keep their accounting identity", () => {
  const strip = (record: Transaction): Record<string, unknown> => {
    const copy: Record<string, unknown> = { ...record };
    delete copy.goalId;
    delete copy.opening;
    return copy;
  };

  const attacks: [string, Record<string, unknown>][] = [
    ["1. opening saving → income (opening kept)", { ...strip(openingSaving), type: "income", category: "income", opening: true }],
    ["1b. opening saving → income (opening dropped)", { ...strip(openingSaving), type: "income", category: "income" }],
    ["2. opening saving → expense", { ...strip(openingSaving), type: "expense", category: "food" }],
    ["2b. opening saving → expense (opening flag forced)", { ...strip(openingSaving), type: "expense", category: "food", opening: true }],
    ["3. opening saving → normal saving", { ...strip(openingSaving), type: "saving", category: "saving", goalId: goalA.id }],
    ["4. opening saving → another goal", { ...openingSaving, goalId: goalB.id }],
    ["4b. opening saving → a goal that doesn't exist", { ...openingSaving, goalId: "ghost" }],
    ["4c. opening saving with its goal removed", { ...strip(openingSaving), opening: true }],
    ["5. opening income → saving (as opening)", { ...strip(openingIncome), type: "saving", category: "saving", goalId: goalB.id, opening: true }],
    ["5b. opening income → normal saving", { ...strip(openingIncome), type: "saving", category: "saving", goalId: goalB.id }],
    ["6. opening income → expense", { ...strip(openingIncome), type: "expense", category: "food" }],
    ["6b. opening income → normal income", { ...strip(openingIncome) }],
    ["6c. opening income with a saving category", { ...openingIncome, category: "saving" }],
    ["normal income → opening income", { ...income, opening: true }],
    ["normal saving → opening saving", { ...contribution, opening: true }],
    ["normal expense → opening income", { ...strip(expense), type: "income", category: "income", opening: true }],
    ["opening flag as a truthy non-boolean", { ...contribution, opening: "true" }],
  ];

  for (const [label, payload] of attacks) {
    it(`${label}: rejected, every figure (balance, totals, goals, safe-to-spend, Brain facts) unchanged`, () => {
      const state = start();
      const before = figures(personal(state));
      const next = run(state, { type: "updateTransaction", tx: payload });
      if (label.startsWith("opening flag as a truthy")) {
        // A non-boolean flag is not an opening flag: the record stays an ordinary contribution.
        assert.equal(personal(next).transactions.find((t) => t.id === contribution.id)?.opening, undefined);
        assert.deepEqual(figures(personal(next)), before);
        return;
      }
      assert.equal(next, state, "state must be returned untouched");
      assert.deepEqual(figures(personal(next)), before);
    });
  }

  it("the saving → income attack would have created money: 2M appears in the balance while the goal keeps nothing", () => {
    // What the attack is worth if it got through, computed on a hand-built workspace (never via the reducer).
    const forged = { ...strip(openingSaving), type: "income", category: "income", opening: true } as Transaction;
    const tampered = workspace([income, openingIncome, forged, contribution, expense], [goalA, goalB]);
    const honest = figures(personal(start()));
    assert.equal(figures(tampered).balance - honest.balance, 2_000_000);
    assert.deepEqual(figures(tampered).goals[0], { ...honest.goals[0], saved: 200_000, opening: 0, percent: figures(tampered).goals[0].percent });
    // …and the reducer refuses exactly that change.
    const state = start();
    assert.equal(run(state, { type: "updateTransaction", tx: forged }), state);
  });

  it("7. legitimate edits to an opening saving (amount, note, past date) apply and stay consistent", () => {
    let state = start();
    state = run(state, { type: "updateTransaction", tx: { ...openingSaving, amount: 1_500_000, note: "Tiền mừng tuổi", date: "2026-06-15T10:00" } });
    const updated = personal(state).transactions.find((t) => t.id === openingSaving.id);
    assert.deepEqual([updated?.amount, updated?.note, updated?.date, updated?.opening, updated?.type, updated?.goalId], [1_500_000, "Tiền mừng tuổi", "2026-06-15T10:00", true, "saving", goalA.id]);
    const after = figures(personal(state));
    assert.equal(after.balance, 5_000_000 + 2_000_000 - 1_500_000 - 200_000 - 150_000);
    assert.deepEqual(after.goals[0], { id: goalA.id, saved: 1_700_000, opening: 1_500_000, contributed: 200_000, percent: after.goals[0].percent });
    assert.equal(after.totalIncome, 7_000_000, "all-time income (balance basis) is unchanged by a saving edit");
    assert.ok(workspaceIsConsistent(personal(state)));
  });

  it("7b. legitimate edits to an opening income (amount, note) apply; it stays out of monthly income statistics", () => {
    let state = start();
    state = run(state, { type: "updateTransaction", tx: { ...openingIncome, amount: 3_000_000, note: "Số dư ví" } });
    const after = figures(personal(state));
    assert.equal(after.balance, 5_000_000 + 3_000_000 - 1_000_000 - 200_000 - 150_000);
    assert.equal(after.totalIncome, 8_000_000);
    assert.equal(after.monthIncome, figures(personal(start())).monthIncome);
    assert.equal(personal(state).transactions.find((t) => t.id === openingIncome.id)?.opening, true);
  });

  it("7c. an opening saving edit is still bound by the balance and the goal target", () => {
    const state = start();
    // Balance is 5.65M: growing the opening by more than that is refused; exactly that is allowed.
    assert.equal(figures(personal(state)).balance, 5_650_000);
    assert.equal(run(state, { type: "updateTransaction", tx: { ...openingSaving, amount: 1_000_000 + 5_650_001 } }), state);
    assert.equal(figures(personal(run(state, { type: "updateTransaction", tx: { ...openingSaving, amount: 1_000_000 + 5_650_000 } }))).balance, 0);
    // A goal target of 10M with 200k contributed: opening can't exceed 9.8M.
    const rich = run(state, { type: "addTransaction", tx: tx({ id: "big", type: "income", amount: 20_000_000, date: "2026-10-05T08:00" }) });
    assert.equal(run(rich, { type: "updateTransaction", tx: { ...openingSaving, amount: 9_800_001 } }), rich);
    const ok = run(rich, { type: "updateTransaction", tx: { ...openingSaving, amount: 9_800_000 } });
    assert.equal(figures(personal(ok)).goals[0].saved, 10_000_000);
  });

  it("8. ordinary records still update normally (type, category, amount, date)", () => {
    let state = start();
    state = run(state, { type: "updateTransaction", tx: { ...expense, type: "income", category: "income", amount: 300_000 } });
    assert.equal(personal(state).transactions.find((t) => t.id === expense.id)?.type, "income");
    state = run(state, { type: "updateTransaction", tx: { ...income, type: "expense", category: "study" } });
    assert.equal(personal(state).transactions.find((t) => t.id === income.id)?.category, "study");
    state = run(state, { type: "updateTransaction", tx: { ...contribution, amount: 100_000, date: "2026-10-01T09:00" } });
    assert.equal(figures(personal(state)).goals[0].contributed, 100_000);
    assert.ok(workspaceIsConsistent(personal(state)));
  });

  it("deleting an opening entry is still allowed (its money simply returns), and its goal stays valid", () => {
    const state = run(start(), { type: "deleteTransaction", id: openingSaving.id });
    const after = figures(personal(state));
    assert.equal(after.goals[0].opening, 0);
    assert.equal(after.balance, figures(personal(start())).balance + 1_000_000);
  });

  it("saveGoal can only attach an opening saving of that goal", () => {
    const state = start();
    const forged = [
      { ...openingSaving, goalId: goalB.id },
      { ...strip(openingSaving), type: "income", category: "income", opening: true },
      { ...strip(openingSaving), type: "saving", category: "saving", goalId: goalA.id },
    ];
    for (const opening of forged) assert.equal(run(state, { type: "saveGoal", goal: goalA, opening }), state);
  });
});

/* ------------------------------------------------------------------ */

describe("no money on days that haven't happened yet", () => {
  const record = (date: string, over: Record<string, unknown> = {}) => ({
    id: `f_${date.replace(/\D/g, "")}_${String(over.type ?? "expense")}`,
    amount: 100_000,
    type: "expense",
    category: "food",
    note: "",
    date,
    createdAt: "2026-10-05T08:00:00.000Z",
    ...over,
  });
  const asIncome = { type: "income", category: "income" };
  const asSaving = { type: "saving", category: "saving", goalId: goalA.id };

  it("9. future income, expense and saving are rejected (tomorrow 00:00 and far future)", () => {
    const state = start();
    for (const date of ["2026-10-06T00:00", "2026-10-31T12:00", "2027-01-01T12:00", "2200-12-31T23:59"]) {
      for (const kind of [{}, asIncome, asSaving]) {
        assert.equal(run(state, { type: "addTransaction", tx: record(date, kind) }), state, `${date} ${JSON.stringify(kind)}`);
      }
    }
  });

  it("9b. a future opening income/saving is rejected too (undo path, saveGoal path)", () => {
    const state = start();
    assert.equal(run(state, { type: "addTransaction", tx: record("2026-10-06T09:00", { ...asIncome, opening: true }) }), state);
    const opening = { ...openingSaving, id: "open_future", date: "2026-10-06T09:00" };
    const withoutOpening = run(state, { type: "deleteTransaction", id: openingSaving.id });
    assert.equal(run(withoutOpening, { type: "saveGoal", goal: goalA, opening }), withoutOpening);
  });

  it("10. moving an existing record into the future is rejected (also for opening entries)", () => {
    const state = start();
    assert.equal(run(state, { type: "updateTransaction", tx: { ...expense, date: "2026-10-06T00:00" } }), state);
    assert.equal(run(state, { type: "updateTransaction", tx: { ...income, date: "2027-01-01T12:00" } }), state);
    assert.equal(run(state, { type: "updateTransaction", tx: { ...openingSaving, date: "2026-10-06T09:00" } }), state);
    assert.equal(run(state, { type: "updateTransaction", tx: { ...openingIncome, date: "2026-12-01T09:00" } }), state);
  });

  it("11. today is accepted — including a later time today", () => {
    let state = start();
    state = run(state, { type: "addTransaction", tx: record("2026-10-05T00:00") });
    state = run(state, { type: "addTransaction", tx: record("2026-10-05T23:59", asIncome) });
    state = run(state, { type: "addTransaction", tx: record("2026-10-05T15:00", { ...asSaving, amount: 50_000 }) });
    const ids = personal(state).transactions.map((t) => t.id);
    assert.ok(ids.includes("f_202610050000_expense") && ids.includes("f_202610052359_income") && ids.includes("f_202610051500_saving"));
  });

  it("12. past records are accepted, and past → past edits work", () => {
    let state = start();
    state = run(state, { type: "addTransaction", tx: record("2025-12-31T23:59") });
    state = run(state, { type: "addTransaction", tx: record("1970-01-01T00:00", asIncome) });
    state = run(state, { type: "updateTransaction", tx: { ...expense, date: "2026-10-04T23:59" } });
    assert.equal(personal(state).transactions.length, 7);
  });

  it("the rule follows the injected clock, not the machine (midnight boundary)", () => {
    const lateEvening = createReducer(() => new Date(2026, 9, 5, 23, 59, 59));
    const justAfterMidnight = createReducer(() => new Date(2026, 9, 6, 0, 0, 0));
    const action = { type: "addTransaction", tx: record("2026-10-06T00:00") };
    const state = start();
    assert.equal(run(state, action, lateEvening), state);
    assert.equal(personal(run(state, action, justAfterMidnight)).transactions.length, 6);
  });

  it("reducer and form validation agree on what 'future' means", () => {
    for (const [date, future] of [["2026-10-05T23:59", false], ["2026-10-06T00:00", true], ["2026-10-04T00:00", false]] as const) {
      const formRejects = validateDraft({ amount: 1_000, type: "expense", category: "food", note: "", date }, NOW).date !== undefined;
      const reducerRejects = personal(run(start(), { type: "addTransaction", tx: record(date) })).transactions.length === 5;
      assert.equal(formRejects, future, `form ${date}`);
      assert.equal(reducerRejects, future, `reducer ${date}`);
    }
  });

  describe("13. restored history is not touched by the rule", () => {
    // A backup made in a time zone ahead of this device can legitimately hold "tomorrow".
    const restoredState = () => {
      const data = workspace([income, expense, { ...expense, id: "ahead", date: "2026-10-06T06:00" }], [goalA]);
      return { ...createDefaultState(), activeWorkspace: "personal" as const, workspaces: { demo: null, personal: data } };
    };

    it("backup files, storage hydration, cross-tab updates and replaceAll keep such records", () => {
      const parsed = parseBackup(serializeBackup(restoredState()));
      assert.ok(parsed.ok);
      assert.equal(parsed.state.workspaces.personal.transactions.length, 3);
      const read = readPersistedState(restoredState());
      assert.ok(read.ok && read.dropped === 0);

      const base = start();
      for (const action of [
        { type: "hydrate", persisted: restoredState(), issue: null },
        { type: "external", persisted: restoredState() },
        { type: "replaceAll", persisted: restoredState() },
      ]) {
        const next = run(base, action);
        assert.equal(personal(next).transactions.length, 3, action.type);
        assert.ok(personal(next).transactions.some((t) => t.id === "ahead"));
      }
    });

    it("such a record can still have its note or amount edited (its date isn't being changed) and can be deleted", () => {
      let state = run(start(), { type: "replaceAll", persisted: restoredState() });
      const ahead = personal(state).transactions.find((t) => t.id === "ahead");
      assert.ok(ahead);
      state = run(state, { type: "updateTransaction", tx: { ...ahead, note: "Bữa sáng", amount: 120_000 } });
      assert.equal(personal(state).transactions.find((t) => t.id === "ahead")?.note, "Bữa sáng");
      // …but it can't be pushed further into the future.
      assert.equal(run(state, { type: "updateTransaction", tx: { ...ahead, date: "2026-10-09T06:00" } }), state);
      state = run(state, { type: "deleteTransaction", id: "ahead" });
      assert.equal(personal(state).transactions.length, 2);
    });

    it("v1 migration of a goal created 'tomorrow' (clock skew) still restores its saved amount", () => {
      const v1 = {
        version: 1,
        activeWorkspace: "personal",
        workspaces: { demo: null, personal: { transactions: [], goals: [{ id: "g1", name: "Xe", targetAmount: 5_000_000, deadline: "2027-06-01", monthlyContribution: null, createdAt: "2026-10-07T03:00:00.000Z", startingAmount: 1_000_000 }] } },
        settings: {},
      };
      const read = readPersistedState(v1);
      assert.ok(read.ok);
      const next = run(start(), { type: "replaceAll", persisted: read.state });
      assert.equal(figures(personal(next)).goals[0].saved, 1_000_000);
    });
  });
});
